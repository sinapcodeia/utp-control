SELECT id, email, role, full_name FROM users;
