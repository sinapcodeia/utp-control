SELECT id, name FROM regions LIMIT 5;
SELECT id, name FROM municipalities LIMIT 5;
