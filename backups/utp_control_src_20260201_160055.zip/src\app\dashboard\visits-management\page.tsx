'use client';

import { useEffect, useState } from 'react';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { LoadingState } from '@/components/dashboard/LoadingState';
import { ProfileError } from '@/components/dashboard/ProfileError';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    MapPin,
    Users,
    CheckCircle2,
    Clock,
    TrendingUp,
    AlertCircle,
    Download,
    Filter,
    ChevronDown,
    BarChart3
} from 'lucide-react';
import { toast } from 'sonner';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

interface VisitStats {
    region: string;
    total: number;
    completed: number;
    pending: number;
    cancelled: number;
    completionRate: number;
    coordinator?: string;
    gestores?: any[];
}

export default function NationalVisitsManagementPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();
    const [stats, setStats] = useState<VisitStats[]>([]);
    const [loading, setLoading] = useState(true);
    const [viewMode, setViewMode] = useState<'regions' | 'coordinators' | 'gestores'>('regions');

    useEffect(() => {
        const fetchVisitsStats = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();

                // Fetch all visits
                const visitsRes = await fetch(`${API_URL}/territory/visits`, {
                    headers: { 'Authorization': `Bearer ${session?.access_token}` }
                });

                if (!visitsRes.ok) throw new Error('Failed to fetch visits');

                const visits = await visitsRes.json();

                // Group by region
                const regionMap = new Map<string, any>();

                visits.forEach((visit: any) => {
                    const regionName = visit.region?.name || 'Sin Región';

                    if (!regionMap.has(regionName)) {
                        regionMap.set(regionName, {
                            region: regionName,
                            total: 0,
                            completed: 0,
                            pending: 0,
                            cancelled: 0,
                            gestores: new Set()
                        });
                    }

                    const regionStats = regionMap.get(regionName)!;
                    regionStats.total++;

                    if (visit.status === 'COMPLETED' || visit.status === 'VERIFIED') {
                        regionStats.completed++;
                    } else if (visit.status === 'CANCELLED') {
                        regionStats.cancelled++;
                    } else {
                        regionStats.pending++;
                    }

                    if (visit.assignedTo?.fullName) {
                        regionStats.gestores.add(visit.assignedTo.fullName);
                    }
                });

                // Convert to array with completion rates
                const statsArray: VisitStats[] = Array.from(regionMap.values()).map(stat => ({
                    ...stat,
                    completionRate: stat.total > 0 ? (stat.completed / stat.total) * 100 : 0,
                    gestores: Array.from(stat.gestores)
                }));

                // Sort by total visits descending
                statsArray.sort((a, b) => b.total - a.total);

                setStats(statsArray);
            } catch (error) {
                console.error('Error fetching visit stats:', error);
                toast.error('Error al cargar estadísticas de visitas');
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchVisitsStats();
        }
    }, [currentUser, supabase.auth]);

    if (userLoading || profileLoading) return <LoadingState />;
    if (!currentUser) return <ProfileError />;
    if (currentUser.role !== 'ADMIN') {
        return <div className="p-8 text-center">Acceso restringido a administradores</div>;
    }

    const totalVisits = stats.reduce((sum, s) => sum + s.total, 0);
    const totalCompleted = stats.reduce((sum, s) => sum + s.completed, 0);
    const totalPending = stats.reduce((sum, s) => sum + s.pending, 0);
    const globalCompletionRate = totalVisits > 0 ? (totalCompleted / totalVisits) * 100 : 0;

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20">
            {/* Header */}
            <div className="relative">
                <Badge variant="outline" className="mb-2 rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em]">
                    Gestión Nacional de Campo
                </Badge>
                <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                    Visitas <span className="text-blue-600">Nacionales</span>
                </h1>
                <p className="text-slate-500 font-medium max-w-2xl text-lg mt-2">
                    Tablero de comando centralizado. Monitoreo en tiempo real de operaciones territoriales.
                </p>
            </div>

            {/* Top KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="rounded-[2rem] border-none shadow-xl bg-gradient-to-br from-blue-600 to-blue-700 text-white overflow-hidden">
                    <CardContent className="p-6 relative">
                        <div className="absolute -right-8 -bottom-8 opacity-10">
                            <BarChart3 className="h-32 w-32" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-widest opacity-80 mb-2">Total Visitas</p>
                        <h3 className="text-5xl font-black mb-2">{totalVisits}</h3>
                        <p className="text-xs font-bold opacity-70">En {stats.length} regiones</p>
                    </CardContent>
                </Card>

                <Card className="rounded-[2rem] border-none shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center gap-2 mb-2">
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Completadas</p>
                        </div>
                        <h3 className="text-4xl font-black text-slate-900 dark:text-white mb-1">{totalCompleted}</h3>
                        <p className="text-sm font-bold text-green-600">{globalCompletionRate.toFixed(1)}% del total</p>
                    </CardContent>
                </Card>

                <Card className="rounded-[2rem] border-none shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center gap-2 mb-2">
                            <Clock className="h-4 w-4 text-amber-600" />
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Pendientes</p>
                        </div>
                        <h3 className="text-4xl font-black text-slate-900 dark:text-white mb-1">{totalPending}</h3>
                        <p className="text-sm font-bold text-amber-600">Requieren atención</p>
                    </CardContent>
                </Card>

                <Card className="rounded-[2rem] border-none shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center gap-2 mb-2">
                            <TrendingUp className="h-4 w-4 text-blue-600" />
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Cobertura</p>
                        </div>
                        <h3 className="text-4xl font-black text-slate-900 dark:text-white mb-1">{globalCompletionRate.toFixed(0)}%</h3>
                        <p className="text-sm font-bold text-blue-600">Índice nacional</p>
                    </CardContent>
                </Card>
            </div>

            {/* Toolbar */}
            <div className="flex items-center justify-between">
                <div className="flex gap-2">
                    <Button
                        variant={viewMode === 'regions' ? 'default' : 'outline'}
                        className="rounded-xl"
                        onClick={() => setViewMode('regions')}
                    >
                        Por Región
                    </Button>
                    <Button
                        variant={viewMode === 'coordinators' ? 'default' : 'outline'}
                        className="rounded-xl"
                        onClick={() => setViewMode('coordinators')}
                    >
                        Por Coordinador
                    </Button>
                    <Button
                        variant={viewMode === 'gestores' ? 'default' : 'outline'}
                        className="rounded-xl"
                        onClick={() => setViewMode('gestores')}
                    >
                        Por Gestor
                    </Button>
                </div>

                <Button variant="outline" className="gap-2 rounded-xl">
                    <Download className="h-4 w-4" />
                    Exportar Informe
                </Button>
            </div>

            {/* Regional Breakdown */}
            <div className="space-y-4">
                <h2 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white uppercase">
                    Desglose por Región
                </h2>

                {loading ? (
                    <div className="space-y-4">
                        {Array.from({ length: 5 }).map((_, i) => (
                            <div key={i} className="h-32 rounded-[2rem] bg-slate-100 dark:bg-slate-800 animate-pulse" />
                        ))}
                    </div>
                ) : stats.length === 0 ? (
                    <Card className="rounded-[2rem] border-none shadow-xl">
                        <CardContent className="p-12 text-center">
                            <AlertCircle className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                            <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">
                                No hay datos de visitas disponibles
                            </p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="space-y-4">
                        {stats.map((stat, index) => {
                            const performanceColor =
                                stat.completionRate >= 80 ? 'green' :
                                    stat.completionRate >= 50 ? 'amber' : 'red';

                            return (
                                <Card key={stat.region} className="rounded-[2rem] border-none shadow-xl hover:shadow-2xl transition-all duration-300">
                                    <CardContent className="p-8">
                                        <div className="flex items-start justify-between mb-6">
                                            <div className="flex items-center gap-4">
                                                <div className={`h-16 w-16 rounded-2xl bg-${performanceColor}-100 flex items-center justify-center`}>
                                                    <MapPin className={`h-8 w-8 text-${performanceColor}-600`} />
                                                </div>
                                                <div>
                                                    <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">
                                                        {stat.region}
                                                    </h3>
                                                    <p className="text-sm font-bold text-slate-500 mt-1">
                                                        {stat.gestores?.length || 0} gestores activos
                                                    </p>
                                                </div>
                                            </div>
                                            <Badge className={`rounded-full px-4 py-2 bg-${performanceColor}-100 text-${performanceColor}-700 font-black text-xs`}>
                                                #{index + 1} NACIONAL
                                            </Badge>
                                        </div>

                                        <div className="grid grid-cols-4 gap-4 mb-6">
                                            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Total</p>
                                                <p className="text-3xl font-black text-slate-900 dark:text-white">{stat.total}</p>
                                            </div>
                                            <div className="p-4 rounded-2xl bg-green-50 dark:bg-green-900/20">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-green-600 mb-1">Completadas</p>
                                                <p className="text-3xl font-black text-green-700">{stat.completed}</p>
                                            </div>
                                            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-900/20">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-amber-600 mb-1">Pendientes</p>
                                                <p className="text-3xl font-black text-amber-700">{stat.pending}</p>
                                            </div>
                                            <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-900/20">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-red-600 mb-1">Canceladas</p>
                                                <p className="text-3xl font-black text-red-700">{stat.cancelled}</p>
                                            </div>
                                        </div>

                                        {/* Progress Bar */}
                                        <div className="space-y-2">
                                            <div className="flex items-center justify-between text-xs font-bold">
                                                <span className="text-slate-500">Cumplimiento</span>
                                                <span className={`text-${performanceColor}-600`}>{stat.completionRate.toFixed(1)}%</span>
                                            </div>
                                            <div className="h-3 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                                                <div
                                                    className={`h-full bg-gradient-to-r from-${performanceColor}-500 to-${performanceColor}-600 transition-all duration-1000`}
                                                    style={{ width: `${stat.completionRate}%` }}
                                                />
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
}
