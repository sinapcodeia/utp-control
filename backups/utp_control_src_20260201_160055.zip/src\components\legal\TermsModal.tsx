
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Shield, FileText, Lock, Eye, Server, MapPin, Scale } from "lucide-react";
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

export interface TermsModalProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onAccept?: () => void;
    defaultTab?: 'terms' | 'privacy' | 'security';
    readOnly?: boolean;
}

export function TermsModal({ open, onOpenChange, onAccept, defaultTab = 'terms', readOnly = false }: TermsModalProps) {
    const [hasRead, setHasRead] = useState(false);
    const [activeTab, setActiveTab] = useState<string>(defaultTab);

    // Sync active tab when defaultTab changes or modal opens
    useEffect(() => {
        if (open) {
            setActiveTab(defaultTab);
        }
    }, [defaultTab, open]);

    const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
        if (readOnly || hasRead) return;
        const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;

        // Tolerance of 50px for different browsers
        if (scrollHeight - scrollTop <= clientHeight + 50) {
            setHasRead(true);
        }
    };

    // Auto-detect if content is short enough that it doesn't need scrolling
    useEffect(() => {
        if (open && !readOnly) {
            const timer = setTimeout(() => {
                const scrollArea = document.querySelector('[data-legal-scroll]');
                if (scrollArea) {
                    const { scrollHeight, clientHeight } = scrollArea;
                    if (scrollHeight <= clientHeight) {
                        setHasRead(true);
                    }
                }
            }, 500);
            return () => clearTimeout(timer);
        }
    }, [open, readOnly, activeTab]);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-5xl h-[90vh] flex flex-col p-0 bg-white shadow-2xl border-0 rounded-xl overflow-y-auto sm:overflow-hidden">
                <div className="flex flex-col h-full font-sans">
                    {/* Header */}
                    <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
                        <div className="flex items-center gap-3">
                            <div className="bg-blue-600 p-2 rounded-lg shadow-lg shadow-blue-200">
                                <Shield className="h-6 w-6 text-white" />
                            </div>
                            <div>
                                <DialogTitle className="text-xl font-bold text-gray-900 tracking-tight">
                                    Centro Legal y de Cumplimiento
                                </DialogTitle>
                                <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">
                                    UTP CONTROL • Corporativo
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-gray-50 rounded-full border border-gray-200">
                                <MapPin className="h-3.5 w-3.5 text-gray-500" />
                                <span className="text-[10px] font-black text-gray-600 uppercase tracking-widest">Jurisdicción: Colombia</span>
                            </div>
                        </div>
                    </div>

                    <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
                        <div className="px-8 border-b border-gray-100 bg-gray-50/30 shrink-0">
                            <TabsList className="bg-transparent border-b-0 h-14 p-0 space-x-6 w-full justify-start">
                                <TabsTrigger
                                    value="terms"
                                    className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-14 px-0 font-medium text-gray-500 hover:text-gray-900 transition-colors"
                                >
                                    Términos de Servicio
                                </TabsTrigger>
                                <TabsTrigger
                                    value="privacy"
                                    className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-14 px-0 font-medium text-gray-500 hover:text-gray-900 transition-colors"
                                >
                                    Política de Privacidad
                                </TabsTrigger>
                                <TabsTrigger
                                    value="security"
                                    className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-14 px-0 font-medium text-gray-500 hover:text-gray-900 transition-colors"
                                >
                                    Seguridad (ISO 27001)
                                </TabsTrigger>
                            </TabsList>
                        </div>

                        {/* Content Scroll Area */}
                        <div
                            className="flex-1 overflow-y-auto p-8 md:p-10 bg-white text-gray-600 leading-relaxed text-sm md:text-base scroll-smooth overscroll-contain"
                            onScroll={handleScroll}
                            data-legal-scroll="true"
                        >
                            <TabsContent value="terms" className="mt-0 space-y-8 animate-in fade-in duration-300 focus-visible:ring-0">
                                <div className="max-w-4xl mx-auto space-y-8">
                                    <div className="border-b border-gray-100 pb-5">
                                        <h3 className="text-2xl font-bold text-gray-900 mb-2">Términos y Condiciones de Uso</h3>
                                        <p className="text-sm text-gray-500">Última actualización: 23 de Enero de 2026</p>
                                    </div>

                                    <div className="prose prose-sm md:prose-base max-w-none text-gray-600 space-y-6">
                                        <p>
                                            Bienvenido a <strong>UTP CONTROL</strong>. Estos Términos de Servicio constituyen un acuerdo legal vinculante entre usted ("el Usuario") y UTP CONTROL S.A.S ("nosotros", "nuestro"). Al acceder a nuestra plataforma de gestión regional, usted acepta someterse a estos términos, que rigen el uso de nuestros servicios de infraestructura crítica.
                                        </p>

                                        <div className="bg-slate-50 p-6 rounded-xl border border-slate-100">
                                            <h4 className="text-slate-900 font-bold text-lg mb-3 flex items-center gap-2">
                                                <Scale className="h-5 w-5 text-slate-600" />
                                                1. Uso Aceptable y Restricciones
                                            </h4>
                                            <p className="text-sm mb-0">
                                                El acceso a la plataforma está estrictamente limitado a personal autorizado. Usted acuerda no: (a) realizar ingeniería inversa; (b) utilizar credenciales de terceros; (c) cargar contenido malicioso o que vulnere derechos de propiedad intelectual. Cualquier violación resultará en la terminación inmediata de la cuenta y acciones legales bajo la <strong>Ley 1273 de 2009 (Delitos Informáticos en Colombia)</strong>.
                                            </p>
                                        </div>

                                        <h4 className="text-gray-900 font-semibold text-lg mt-6">2. Disponibilidad del Servicio (SLA)</h4>
                                        <p>
                                            Garantizamos una disponibilidad del 99.9% para servicios críticos. Sin embargo, nos reservamos el derecho de interrumpir el servicio para mantenimiento programado o actualizaciones de seguridad urgentes ("Ventanas de Mantenimiento").
                                        </p>

                                        <h4 className="text-gray-900 font-semibold text-lg mt-6">3. Propiedad Intelectual</h4>
                                        <p>
                                            Todo el software, algoritmos, diseños e interfaces son propiedad exclusiva de UTP CONTROL. Se otorga al usuario una licencia limitada, no exclusiva e intransferible para uso operativo interno.
                                        </p>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="privacy" className="mt-0 space-y-8 animate-in fade-in duration-300 focus-visible:ring-0">
                                <div className="max-w-4xl mx-auto space-y-8">
                                    <div className="flex items-center justify-between border-b border-gray-100 pb-5">
                                        <div>
                                            <h3 className="text-2xl font-bold text-gray-900 mb-2">Política de Privacidad Integral</h3>
                                            <p className="text-sm text-gray-500">Conforme a Ley 1581 de 2012</p>
                                        </div>
                                        <div className="flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-100 rounded-full text-blue-700 text-xs font-semibold">
                                            <FileText className="h-3 w-3" />
                                            Habeas Data Certificado
                                        </div>
                                    </div>

                                    <div className="prose prose-sm md:prose-base max-w-none text-gray-600 space-y-6">
                                        <p>
                                            UTP CONTROL se compromete a proteger su privacidad. Esta política describe exhaustivamente cómo recolectamos, usamos, almacenamos y protegemos sus datos personales.
                                        </p>

                                        <div className="grid md:grid-cols-2 gap-6 my-8">
                                            <div className="p-5 border border-gray-100 rounded-xl bg-gray-50/50 hover:bg-white transition-colors hover:shadow-sm">
                                                <h5 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                                                    <Eye className="h-4 w-4 text-blue-600" /> Recolección de Datos
                                                </h5>
                                                <p className="text-sm">Recopilamos datos de identificación, logs de acceso, dirección IP y metadatos operativos necesarios para la auditoría y seguridad del sistema, bajo el principio de minimización de datos.</p>
                                            </div>
                                            <div className="p-5 border border-gray-100 rounded-xl bg-gray-50/50 hover:bg-white transition-colors hover:shadow-sm">
                                                <h5 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                                                    <Lock className="h-4 w-4 text-blue-600" /> Tratamiento Seguro
                                                </h5>
                                                <p className="text-sm">Sus datos se almacenan en servidores cifrados (AES-256) y no se comparten con terceros salvo mandato legal o judicial explícito.</p>
                                            </div>
                                        </div>

                                        <h4 className="text-gray-900 font-semibold text-lg mt-6">Derechos ARCO del Titular</h4>
                                        <p>Usted tiene derecho pleno a conocer, actualizar, rectificar y suprimir su información personal. Para ejercer estos derechos, contacte a nuestro Oficial de Privacidad en <span className="text-blue-600 font-medium">sinapcodeia@gmail.com</span>.</p>

                                        <h4 className="text-gray-900 font-semibold text-lg mt-6">Política de Cookies</h4>
                                        <p>Utilizamos cookies estrictamente técnicas necesarias para la autenticación (Auth Tokens) y seguridad de la sesión (CSRF Protection). No utilizamos cookies de rastreo publicitario ni vendemos datos de navegación.</p>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="security" className="mt-0 space-y-8 animate-in fade-in duration-300 focus-visible:ring-0">
                                <div className="max-w-4xl mx-auto space-y-8">
                                    <div className="border-b border-gray-100 pb-5">
                                        <h3 className="text-2xl font-bold text-gray-900 mb-2">Estándares de Seguridad</h3>
                                        <p className="text-sm text-gray-500">Arquitectura de Defensa en Profundidad</p>
                                    </div>

                                    <div className="grid gap-4">
                                        <div className="flex items-start gap-4 p-6 border border-gray-100 rounded-xl bg-white hover:border-green-200 transition-colors shadow-sm">
                                            <div className="bg-green-100 p-3 rounded-lg mt-1">
                                                <Shield className="h-6 w-6 text-green-700" />
                                            </div>
                                            <div>
                                                <h5 className="font-bold text-gray-900 text-lg">ISO/IEC 27001:2022</h5>
                                                <p className="text-sm mt-2 text-gray-600">Nuestros sistemas de gestión de seguridad de la información están alineados con los estándares internacionales más rigurosos, garantizando confidencialidad, integridad y disponibilidad.</p>
                                            </div>
                                        </div>

                                        <div className="flex items-start gap-4 p-6 border border-gray-100 rounded-xl bg-white hover:border-purple-200 transition-colors shadow-sm">
                                            <div className="bg-purple-100 p-3 rounded-lg mt-1">
                                                <Server className="h-6 w-6 text-purple-700" />
                                            </div>
                                            <div>
                                                <h5 className="font-bold text-gray-900 text-lg">Cifrado Militar (End-to-End)</h5>
                                                <p className="text-sm mt-2 text-gray-600">Datos en reposo cifrados con AES-256 GCM. Datos en tránsito protegidos mediante TLS 1.3 con Perfect Forward Secrecy. Gestión de llaves mediante HSM (Hardware Security Module) en la nube.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <h4 className="text-gray-900 font-semibold text-lg mt-6">Reporte de Vulnerabilidades</h4>
                                    <p className="text-gray-600">
                                        Mantenemos un programa de divulgación responsable. Si identifica una vulnerabilidad, repórtela inmediatamente a <span className="text-blue-600 font-family-mono text-sm">sinapcodeia@gmail.com</span>. Recompensamos reportes críticos verificados.
                                    </p>
                                </div>
                            </TabsContent>

                            {/* Scroll Sentinel */}
                            <div className="h-20" />
                        </div>
                    </Tabs>

                    {/* Footer for Action */}
                    {!readOnly && (
                        <div className="p-6 border-t border-gray-100 bg-gray-50/80 backdrop-blur-sm flex flex-col sm:flex-row items-center justify-between gap-4 z-20 shrink-0">
                            <div className="text-sm text-gray-500 font-medium">
                                {!hasRead ? (
                                    <div className="flex items-center gap-2 text-amber-600">
                                        <span className="relative flex h-2 w-2">
                                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                                            <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                                        </span>
                                        Desliza hasta el final para aceptar
                                    </div>
                                ) : (
                                    <div className="flex items-center gap-2 text-emerald-600">
                                        <span className="h-2 w-2 rounded-full bg-emerald-500" />
                                        Documento leído correctamente
                                    </div>
                                )}
                            </div>

                            <div className="flex items-center gap-3 w-full sm:w-auto">
                                <Button
                                    variant="ghost"
                                    onClick={() => onOpenChange(false)}
                                    className="text-gray-500 hover:text-gray-900 hover:bg-gray-100 font-medium"
                                >
                                    Cancelar
                                </Button>
                                <Button
                                    onClick={() => onAccept && onAccept()}
                                    disabled={!hasRead}
                                    className={`pl-6 pr-6 font-semibold transition-all duration-300 ${hasRead
                                        ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-xl shadow-blue-600/20 translate-y-0 opacity-100'
                                        : 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                                        }`}
                                >
                                    Aceptar y Continuar
                                </Button>
                            </div>
                        </div>
                    )}

                    {readOnly && (
                        <div className="p-4 border-t border-gray-100 bg-gray-50 flex justify-end shrink-0">
                            <Button variant="outline" onClick={() => onOpenChange(false)} className="px-6">Cerrar</Button>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}
