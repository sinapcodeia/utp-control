'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Bell, BellOff, Check } from 'lucide-react';
import { toast } from 'sonner';

export function NotificationPermission() {
    const [permission, setPermission] = useState<NotificationPermission>('default');
    const [subscription, setSubscription] = useState<PushSubscription | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if ('Notification' in window) {
            setPermission(Notification.permission);
        }

        // Verificar si ya hay una suscripción
        if ('serviceWorker' in navigator && 'PushManager' in window) {
            navigator.serviceWorker.ready.then(async (registration) => {
                const sub = await registration.pushManager.getSubscription();
                setSubscription(sub);
            });
        }
    }, []);

    const requestPermission = async () => {
        if (!('Notification' in window)) {
            toast.error('Tu navegador no soporta notificaciones');
            return;
        }

        setLoading(true);

        try {
            const result = await Notification.requestPermission();
            setPermission(result);

            if (result === 'granted') {
                await subscribeToPush();
                toast.success('Notificaciones activadas', {
                    description: 'Recibirás alertas importantes'
                });
            } else {
                toast.error('Permiso denegado', {
                    description: 'No podrás recibir notificaciones'
                });
            }
        } catch (error) {
            console.error('Error requesting permission:', error);
            toast.error('Error al solicitar permisos');
        } finally {
            setLoading(false);
        }
    };

    const subscribeToPush = async () => {
        if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
            return;
        }

        try {
            const registration = await navigator.serviceWorker.ready;

            // VAPID public key (debes generar una en producción)
            const vapidPublicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY ||
                'BEl62iUYgUivxIkv69yViEuiBIa-Ib37J8xYjEB6hvqRxYmjfIAjXbLNilO5Oy4Fj3qvnB2hhEAJmRYjqXhqE8s';

            const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(vapidPublicKey) as BufferSource
            });

            setSubscription(subscription);

            // Enviar suscripción al backend
            await saveSubscription(subscription);
        } catch (error) {
            console.error('Error subscribing to push:', error);
            toast.error('Error al activar notificaciones push');
        }
    };

    const saveSubscription = async (subscription: PushSubscription) => {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/notifications/subscribe`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(subscription)
            });

            if (!response.ok) {
                throw new Error('Failed to save subscription');
            }
        } catch (error) {
            console.error('Error saving subscription:', error);
        }
    };

    const unsubscribe = async () => {
        if (!subscription) return;

        setLoading(true);

        try {
            await subscription.unsubscribe();
            setSubscription(null);
            toast.success('Notificaciones desactivadas');
        } catch (error) {
            console.error('Error unsubscribing:', error);
            toast.error('Error al desactivar notificaciones');
        } finally {
            setLoading(false);
        }
    };

    // No mostrar si ya está instalada como PWA y tiene permisos
    if (permission === 'granted' && subscription) {
        return null;
    }

    return (
        <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/50 dark:to-orange-950/50">
            <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-2xl bg-amber-600 flex items-center justify-center">
                            <Bell className="h-6 w-6 text-white" />
                        </div>
                        <div>
                            <CardTitle className="text-lg font-black text-amber-900 dark:text-amber-100">
                                Notificaciones
                            </CardTitle>
                            <CardDescription className="text-xs font-bold text-amber-700 dark:text-amber-300">
                                Recibe alertas importantes en tiempo real
                            </CardDescription>
                        </div>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="space-y-3">
                <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-amber-800 dark:text-amber-200">
                        <div className="h-1.5 w-1.5 rounded-full bg-amber-600" />
                        <span className="font-bold">Alertas críticas territoriales</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-amber-800 dark:text-amber-200">
                        <div className="h-1.5 w-1.5 rounded-full bg-amber-600" />
                        <span className="font-bold">Novedades importantes</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-amber-800 dark:text-amber-200">
                        <div className="h-1.5 w-1.5 rounded-full bg-amber-600" />
                        <span className="font-bold">Recordatorios de visitas</span>
                    </div>
                </div>

                {permission === 'default' && (
                    <Button
                        onClick={requestPermission}
                        disabled={loading}
                        className="w-full bg-amber-600 hover:bg-amber-700 text-white font-black uppercase text-xs rounded-xl"
                    >
                        <Bell className="h-4 w-4 mr-2" />
                        {loading ? 'Activando...' : 'Activar Notificaciones'}
                    </Button>
                )}

                {permission === 'granted' && !subscription && (
                    <Button
                        onClick={subscribeToPush}
                        disabled={loading}
                        className="w-full bg-green-600 hover:bg-green-700 text-white font-black uppercase text-xs rounded-xl"
                    >
                        <Check className="h-4 w-4 mr-2" />
                        {loading ? 'Configurando...' : 'Configurar Push'}
                    </Button>
                )}

                {permission === 'granted' && subscription && (
                    <Button
                        onClick={unsubscribe}
                        variant="outline"
                        disabled={loading}
                        className="w-full border-amber-200 text-amber-700 hover:bg-amber-100 dark:border-amber-800 dark:text-amber-300 font-bold text-xs rounded-xl"
                    >
                        <BellOff className="h-4 w-4 mr-2" />
                        Desactivar
                    </Button>
                )}

                {permission === 'denied' && (
                    <div className="p-3 bg-red-50 dark:bg-red-950/50 rounded-xl border border-red-200 dark:border-red-800">
                        <p className="text-xs font-bold text-red-700 dark:text-red-300">
                            Permisos bloqueados. Habilítalos en la configuración del navegador.
                        </p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}

// Helper function
function urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
        .replace(/\-/g, '+')
        .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
}
