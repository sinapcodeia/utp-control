'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldAlert, CheckCircle2, FileText } from "lucide-react";
import { useCurrentUser } from "@/hooks/useCurrentUser";

import { apiClient } from "@/lib/api-client";

interface NationalNewsPopupProps {
    userId: string;
}

export function NationalNewsPopup({ userId }: NationalNewsPopupProps) {
    const { supabase } = useCurrentUser();
    const [unreadNews, setUnreadNews] = useState<any[]>([]);
    const [isOpen, setIsOpen] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [hasRead, setHasRead] = useState(false);

    useEffect(() => {
        const fetchUnread = async () => {
            try {
                const data = await apiClient.get<any[]>(`/regional-reports/unread?userId=${userId}`);
                if (data && data.length > 0) {
                    setUnreadNews(data);
                    setIsOpen(true);
                }
            } catch (error) {
                console.error("Error fetching unread news:", error);
            }
        };

        if (userId) fetchUnread();
    }, [userId]);

    const handleAcknowledge = async () => {
        const report = unreadNews[currentIndex];
        try {
            await apiClient.post(`/regional-reports/${report.id}/read`, { userId });

            if (currentIndex < unreadNews.length - 1) {
                setCurrentIndex(currentIndex + 1);
                setHasRead(false);
            } else {
                setIsOpen(false);
            }
        } catch (error) {
            console.error("Error marking news as read:", error);
        }
    };

    if (unreadNews.length === 0) return null;

    const currentItem = unreadNews[currentIndex];

    return (
        <Dialog open={isOpen} onOpenChange={() => { }}>
            <DialogContent className="max-w-2xl rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-2xl p-0 overflow-hidden">
                <div className="bg-blue-600 p-8 text-white flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                            <ShieldAlert className="h-6 w-6 text-white" />
                        </div>
                        <div>
                            <DialogTitle className="text-2xl font-black uppercase tracking-tighter">Comunicado Nacional</DialogTitle>
                            <DialogDescription className="text-blue-100 text-xs font-bold uppercase tracking-widest">Información de cumplimiento obligatorio</DialogDescription>
                        </div>
                    </div>
                    <Badge variant="outline" className="border-white/30 bg-white/10 text-white font-black">
                        {currentIndex + 1} / {unreadNews.length}
                    </Badge>
                </div>

                <div className="p-10 space-y-8">
                    <div className="space-y-4">
                        <div className="flex items-center gap-2">
                            <Badge className={`${currentItem.priority === 'HIGH' ? 'bg-red-500' : 'bg-blue-500'} text-white font-black text-[10px] rounded-full px-3 uppercase tracking-widest`}>
                                Prioridad {currentItem.priority}
                            </Badge>
                            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                                Publicado el {new Date(currentItem.createdAt).toLocaleDateString()}
                            </span>
                        </div>
                        <h3 className="text-3xl font-black text-slate-900 dark:text-white leading-tight">
                            {currentItem.title || currentItem.content.split(': ')[0]}
                        </h3>
                        <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800">
                            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-sm">
                                {currentItem.title ? currentItem.content : (currentItem.content.includes(': ') ? currentItem.content.split(': ').slice(1).join(': ') : currentItem.content)}
                            </p>
                        </div>
                    </div>

                    {/* Documento Anexo */}
                    {currentItem.attachmentUrl && (
                        <div className="p-1 shadow-sm rounded-[2rem] bg-gradient-to-r from-blue-600 to-indigo-600">
                            <div className="bg-white dark:bg-slate-900 p-6 rounded-[1.9rem] flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <div className="h-14 w-14 rounded-2xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center text-blue-600">
                                        <FileText className="h-7 w-7" />
                                    </div>
                                    <div>
                                        <p className="text-xs font-black text-blue-600 uppercase tracking-widest mb-1">Documento adjunto</p>
                                        <p className="text-sm font-bold text-slate-900 dark:text-white italic">Documento_Oficial.pdf</p>
                                    </div>
                                </div>
                                <Button
                                    variant="outline"
                                    className="rounded-xl border-blue-200 text-blue-600 hover:bg-blue-50 font-black uppercase text-[10px] tracking-widest px-6"
                                    onClick={() => window.open(currentItem.attachmentUrl, '_blank')}
                                >
                                    Ver Documento
                                </Button>
                            </div>
                        </div>
                    )}

                    <div className="flex items-center gap-4 p-6 rounded-3xl bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800 transition-all hover:border-blue-200">
                        <div className="h-10 w-10 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                            <CheckCircle2 className="h-5 w-5" />
                        </div>
                        <div className="flex-1 flex items-center justify-between">
                            <span className="text-[12px] font-black uppercase tracking-tight text-slate-700 dark:text-slate-300">Confirmo que he leído y comprendo este comunicado.</span>
                            <input
                                type="checkbox"
                                checked={hasRead}
                                onChange={(e) => setHasRead(e.target.checked)}
                                className="h-6 w-6 rounded-lg border-slate-300 text-blue-600 focus:ring-blue-500 transition-all cursor-pointer shadow-sm"
                            />
                        </div>
                    </div>
                </div>

                <DialogFooter className="p-8 bg-slate-50 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3">
                    <Button
                        disabled={!hasRead}
                        onClick={handleAcknowledge}
                        className="rounded-2xl px-8 h-12 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-blue-500/20 disabled:opacity-50"
                    >
                        {currentIndex < unreadNews.length - 1 ? 'Siguiente comunicado' : 'Aceptar y continuar'}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
