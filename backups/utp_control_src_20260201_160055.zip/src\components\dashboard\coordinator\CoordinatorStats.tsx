'use client';

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Users, ShieldAlert, Activity } from "lucide-react";
import { DashboardStats } from "@/types";

interface CoordinatorStatsProps {
    stats: DashboardStats | null;
    regionName: string;
    onStatClick?: (section: string) => void;
}

export function CoordinatorStats({ stats, regionName, onStatClick }: CoordinatorStatsProps) {
    const coverageValue = typeof stats?.coverage === 'string'
        ? parseInt(stats.coverage.replace('%', ''), 10)
        : stats?.coverage || 0;
    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* 1. Gestores Activos */}
            <Card
                className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => onStatClick?.('team')}
            >
                <CardHeader className="p-6 pb-2">
                    <div className="flex justify-between items-start">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Gestores Activos</p>
                        <div className="h-8 w-8 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 dark:bg-blue-900/20">
                            <Users className="h-4 w-4" />
                        </div>
                    </div>
                    <div className="flex items-end gap-2 mt-2">
                        <h3 className="text-4xl font-black tracking-tighter text-slate-900 dark:text-white">
                            {stats?.activePersonnel || 128}
                        </h3>
                        <span className="mb-1 text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-lg">
                            +12% hoy
                        </span>
                    </div>
                </CardHeader>
                <CardContent className="px-6 pb-6">
                    <p className="text-[10px] font-bold text-slate-400">
                        De {stats?.personnelTotal || 150} programados
                    </p>
                    <Progress value={((stats?.activePersonnel || 128) / (stats?.personnelTotal || 150)) * 100} className="h-1.5 mt-3 bg-slate-100" indicatorClassName="bg-blue-600" />
                </CardContent>
            </Card>

            {/* 2. Cumplimiento Operativo */}
            <Card
                className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => onStatClick?.('calendar')}
            >
                <CardHeader className="p-6 pb-2">
                    <div className="flex justify-between items-start">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Cumplimiento</p>
                        <div className="h-8 w-8 rounded-xl bg-green-50 flex items-center justify-center text-green-600 dark:bg-green-900/20">
                            <Activity className="h-4 w-4" />
                        </div>
                    </div>
                    <div className="flex items-end gap-2 mt-2">
                        <h3 className="text-4xl font-black tracking-tighter text-slate-900 dark:text-white">
                            92<span className="text-2xl text-slate-400">%</span>
                        </h3>
                        <span className="mb-1 text-[10px] font-bold text-slate-400">
                            Meta: 90%
                        </span>
                    </div>
                </CardHeader>
                <CardContent className="px-6 pb-6">
                    <div className="flex justify-between text-[9px] font-bold text-slate-400 mb-1 uppercase tracking-wider">
                        <span>Visitas: 840 / 915</span>
                    </div>
                    <Progress value={92} className="h-1.5 bg-slate-100" indicatorClassName="bg-green-500" />
                </CardContent>
            </Card>

            {/* 3. ICOE - North Star KPI */}
            <Card
                className="rounded-[2rem] border-none bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer relative overflow-hidden"
                onClick={() => onStatClick?.('coverage')}
            >
                {/* Decorative background */}
                <div className="absolute inset-0 opacity-10">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full -translate-y-16 translate-x-16" />
                    <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full translate-y-12 -translate-x-12" />
                </div>

                <CardHeader className="p-6 pb-2 relative z-10">
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/80">Estrella Polar</p>
                            <p className="text-xs font-bold text-white/90 mt-0.5">ICOE - Cobertura Efectiva</p>
                        </div>
                        <div className="h-8 w-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                            <TrendingUp className="h-4 w-4 text-white" />
                        </div>
                    </div>
                    <div className="flex items-end gap-3 mt-3">
                        <h3 className="text-5xl font-black tracking-tighter text-white drop-shadow-lg">
                            {(stats as any)?.icoeRaw || coverageValue}<span className="text-2xl text-white/70">%</span>
                        </h3>
                        <div className={`mb-2 px-2.5 py-1 rounded-lg font-black text-[9px] uppercase tracking-widest ${((stats as any)?.riskLevel || 'BAJO') === 'CRÍTICO' ? 'bg-red-500' :
                            ((stats as any)?.riskLevel || 'BAJO') === 'MEDIO' ? 'bg-amber-500' :
                                'bg-green-500'
                            }`}>
                            {(stats as any)?.riskLevel || 'BAJO'}
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="px-6 pb-6 relative z-10">
                    <div className="space-y-2">
                        <div className="flex justify-between text-[9px] font-bold text-white/80 uppercase tracking-wider">
                            <span>Calidad: {(stats as any)?.qualityScore || 85}%</span>
                            <span>Alertas: {stats?.criticalAlerts || 0} 🔴</span>
                        </div>
                        <div className="h-1.5 bg-white/20 rounded-full overflow-hidden backdrop-blur-sm">
                            <div
                                className="h-full bg-white rounded-full transition-all duration-1000"
                                style={{ width: `${(stats as any)?.icoeRaw || coverageValue}%` }}
                            />
                        </div>
                        <p className="text-[8px] text-white/60 uppercase tracking-widest mt-2">
                            Fórmula: (Visitas Válidas × Calidad × Sin Riesgo) / Total UP
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
