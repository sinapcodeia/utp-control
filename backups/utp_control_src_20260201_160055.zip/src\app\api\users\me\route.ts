import { createClient } from '@/utils/supabase/server';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

export async function GET() {
    try {
        const cookieStore = await cookies();
        const supabase = await createClient();

        // Obtener usuario actual (validado con el servidor de Supabase)
        const { data: { user: authUser }, error: authError } = await supabase.auth.getUser();

        if (authError || !authUser) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Obtener datos completos del usuario con relaciones
        const { data: user, error: userError } = await supabase
            .from('users')
            .select(`
                id,
                email,
                full_name,
                role,
                region_id,
                municipality_id,
                is_active,
                region:regions(id, name, code),
                municipality:municipalities(id, name)
            `)
            .eq('email', authUser.email)
            .maybeSingle();

        if (userError) {
            console.error('Error fetching user:', userError);
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        if (!user) {
            // Auto-register user if not found in public.users
            const { data: newUser, error: createError } = await supabase
                .from('users')
                .insert({
                    id: authUser.id,
                    email: authUser.email,
                    full_name: authUser.user_metadata?.full_name || authUser.email?.split('@')[0] || 'Nuevo Usuario',
                    role: 'USER',
                    password_hash: 'SUPABASE_AUTH', // Placeholder since auth is handled by Supabase
                    dni: `REG-${Math.floor(Math.random() * 1000000)}`, // Temporary DNI
                    is_active: true,
                    accepted_terms: authUser.user_metadata?.accepted_terms || false,
                    accepted_at: authUser.user_metadata?.accepted_at || new Date().toISOString()
                })
                .select(`
                    id,
                    email,
                    full_name,
                    role,
                    region_id,
                    municipality_id,
                    is_active,
                    region:regions(id, name, code),
                    municipality:municipalities(id, name)
                `)
                .maybeSingle();

            if (createError) {
                console.error('Error auto-registering user:', createError);
                // If it's a unique constraint error on DNI, we might want to retry or handle it
                return NextResponse.json({ error: 'Failed to create user profile' }, { status: 500 });
            }

            return NextResponse.json(newUser);
        }

        return NextResponse.json(user);
    } catch (error) {
        console.error('Error in /api/users/me:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
