'use client';

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Download, FileText, TrendingUp } from "lucide-react";
import { toast } from "sonner";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

const MONTHS = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export function AutomatedReportGenerator() {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth();

    const [selectedMonth, setSelectedMonth] = useState(currentMonth.toString());
    const [selectedYear, setSelectedYear] = useState(currentYear.toString());
    const [generating, setGenerating] = useState(false);

    const handleGenerateReport = async () => {
        setGenerating(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(
                `${API_URL}/reports/automated/monthly?month=${selectedMonth}&year=${selectedYear}`,
                {
                    headers: { 'Authorization': `Bearer ${token}` }
                }
            );

            if (!res.ok) throw new Error('Error generando informe');

            const blob = await res.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Informe_Mensual_${MONTHS[parseInt(selectedMonth)]}_${selectedYear}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);

            toast.success("Informe generado exitosamente", {
                description: `${MONTHS[parseInt(selectedMonth)]} ${selectedYear} - Descarga iniciada`
            });
        } catch (e) {
            console.error(e);
            toast.error('Error al generar el informe automático');
        } finally {
            setGenerating(false);
        }
    };

    return (
        <Card className="premium-card border-none bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20">
            <CardHeader className="border-b border-blue-100 dark:border-blue-900/30">
                <CardTitle className="flex items-center gap-3 text-lg">
                    <div className="h-10 w-10 rounded-2xl bg-blue-600 flex items-center justify-center">
                        <TrendingUp className="h-5 w-5 text-white" />
                    </div>
                    <div>
                        <p className="text-base font-black uppercase tracking-tight">Generador Automático</p>
                        <p className="text-[10px] font-medium text-slate-500 uppercase tracking-widest mt-0.5">Informes Mensuales Consolidados</p>
                    </div>
                </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-blue-600">Mes</label>
                        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                            <SelectTrigger className="h-12 rounded-2xl border-blue-200 bg-white shadow-sm">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="rounded-2xl border-blue-200 bg-white shadow-2xl z-[100]">
                                {MONTHS.map((month, idx) => (
                                    <SelectItem key={idx} value={idx.toString()} className="rounded-xl py-3 font-bold">
                                        {month}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-blue-600">Año</label>
                        <Select value={selectedYear} onValueChange={setSelectedYear}>
                            <SelectTrigger className="h-12 rounded-2xl border-blue-200 bg-white shadow-sm">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="rounded-2xl border-blue-200 bg-white shadow-2xl z-[100]">
                                {[currentYear, currentYear - 1, currentYear - 2].map(year => (
                                    <SelectItem key={year} value={year.toString()} className="rounded-xl py-3 font-bold">
                                        {year}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="bg-white/60 dark:bg-slate-900/40 rounded-2xl p-4 border border-blue-100 dark:border-blue-900/30">
                    <div className="flex items-start gap-3">
                        <FileText className="h-5 w-5 text-blue-600 mt-0.5" />
                        <div className="flex-1">
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Vista Previa del Informe</p>
                            <p className="text-xs text-slate-500 mt-1">
                                Informe Mensual: <span className="font-bold text-blue-600">{MONTHS[parseInt(selectedMonth)]} {selectedYear}</span>
                            </p>
                            <ul className="mt-3 space-y-1 text-[10px] text-slate-600">
                                <li className="flex items-center gap-2">
                                    <div className="h-1 w-1 rounded-full bg-blue-600" />
                                    KPIs de Cobertura y Cumplimiento
                                </li>
                                <li className="flex items-center gap-2">
                                    <div className="h-1 w-1 rounded-full bg-blue-600" />
                                    Análisis de Alertas Críticas y Preventivas
                                </li>
                                <li className="flex items-center gap-2">
                                    <div className="h-1 w-1 rounded-full bg-blue-600" />
                                    Recomendaciones Estratégicas
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <Button
                    onClick={handleGenerateReport}
                    disabled={generating}
                    className="w-full h-14 rounded-2xl font-black uppercase tracking-widest text-xs shadow-[0_12px_24px_-8px_rgba(37,99,235,0.4)] hover:shadow-[0_16px_32px_-8px_rgba(37,99,235,0.5)] transition-all bg-blue-600 hover:bg-blue-700"
                >
                    {generating ? (
                        <>
                            <Calendar className="h-4 w-4 mr-2 animate-spin" />
                            Generando Informe...
                        </>
                    ) : (
                        <>
                            <Download className="h-4 w-4 mr-2" />
                            Generar y Descargar PDF
                        </>
                    )}
                </Button>

                <p className="text-[9px] text-center text-slate-400 uppercase tracking-widest">
                    Generación automática con datos en tiempo real
                </p>
            </CardContent>
        </Card>
    );
}
