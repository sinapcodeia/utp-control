// TypeScript Type Definitions for UTP CONTROL System

export type UserRole = 'ADMIN' | 'COORDINATOR' | 'GESTOR' | 'SUPPORT' | 'USER';

export type Priority = 'LOW' | 'MEDIUM' | 'HIGH';

export type NewsCategory =
    | 'CLIMATE'
    | 'SECURITY'
    | 'PUBLIC_ORDER'
    | 'HEALTH'
    | 'INFRASTRUCTURE'
    | 'OTHER';

export type ReportType = 'GENERAL' | 'REGIONAL' | 'ALERT' | 'AUDIT';

export type ReportFormat = 'PDF' | 'XLSX' | 'DOCX';

export interface Region {
    id: string;
    name: string;
    code: string;
}

export interface Municipality {
    id: string;
    name: string;
    regionId: string;
}

export interface User {
    id: string;
    email: string;
    fullName: string;
    dni: string;
    phone?: string;
    role: UserRole;
    isActive: boolean;
    regionId?: string;
    municipalityId?: string;
    region?: Region;
    municipality?: Municipality;
    createdAt: string;
    lastLogin?: string;
    acceptedTerms: boolean;
}

export interface RegionalReport {
    id: string;
    userId: string;
    regionId?: string;
    municipalityId?: string;
    category: NewsCategory;
    priority: Priority;
    content: string;
    createdAt: string;
    user?: {
        id: string;
        fullName: string;
    };
    region?: Region;
    municipality?: Municipality;
    readReceipts?: NewsReadReceipt[];
}

export interface NewsReadReceipt {
    id: string;
    userId: string;
    reportId: string;
    readAt: string;
}

export interface Document {
    id: string;
    title: string;
    url: string;
    version: number;
    hash?: string;
    uploaderId: string;
    createdAt: string;
    uploader: {
        fullName: string;
    };
    _count: {
        comments: number;
    };
}

export interface DocumentComment {
    id: string;
    documentId: string;
    userId: string;
    content: string;
    createdAt: string;
    user: {
        fullName: string;
    };
}

export interface Report {
    id: string;
    code: string;
    type: ReportType;
    format: ReportFormat;
    url: string;
    hashSha256: string;
    generatedById: string;
    authorizedById?: string;
    regionId?: string;
    municipalityId?: string;
    metadata?: Record<string, any>;
    generatedAt: string;
    generatedBy?: User;
    region?: Region;
    municipality?: Municipality;
}

export interface DashboardStats {
    totalReports: number;
    activeNews: number;
    totalUsers: number;
    totalDocuments: number;
    recentNews: RegionalReport[];
    // Coordinator Stats
    activePersonnel?: number;
    coverage?: string;
    criticalAlerts?: number;
    preventiveAlerts?: number;
    personnelTotal?: number;
    // Gestor Stats
    tcSigned?: string;
    pendingDocs?: number;
    monthlyReports?: number;
    todayLogs?: string;
    visitCoordinates?: {
        id: string;
        latitude: number;
        longitude: number;
        priority: 'LOW' | 'MEDIUM' | 'HIGH';
    }[];
}

export interface Task {
    id: number;
    title: string;
    area: string;
    priority: 'High' | 'Medium' | 'Low';
    due: string;
}

export interface TCComplianceUser {
    id: string;
    fullName: string;
    email: string;
    acceptedTerms: boolean;
    acceptedAt?: string;
}

export interface AuditLog {
    id: string;
    userId: string;
    action: string;
    entity: string;
    entityId: string;
    ipAddress?: string;
    metadata?: Record<string, any>;
    timestamp: string;
    user?: User;
}

export interface Alert {
    id: string;
    reportId: string;
    priority: Priority;
    status: 'NEW' | 'READ' | 'RESOLVED' | 'MANAGED';
    createdAt: string;
    report?: RegionalReport;
}

// API Response Types
export interface ApiResponse<T> {
    data?: T;
    error?: string;
    message?: string;
}

// Hierarchy for Archive View
export interface TeamMember {
    id: string;
    name: string;
    role: string;
    status: 'active' | 'inactive' | 'break';
    municipality: string;
    lastActive: string;
    visitsCompleted: number;
    visitsAssigned: number;
}

export interface NewsHierarchy {
    [regionName: string]: {
        [municipalityName: string]: RegionalReport[];
    };
}
