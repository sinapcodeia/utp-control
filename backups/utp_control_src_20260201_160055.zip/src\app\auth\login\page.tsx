'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/utils/supabase/client';
import { useRouter } from 'next/navigation';
import { Loader2, Lock, Mail, ShieldAlert, AlertCircle, CheckCircle2, ChevronRight, X, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TermsModal } from '@/components/legal/TermsModal';

export default function LoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [isSignUp, setIsSignUp] = useState(false);
    const [acceptedTerms, setAcceptedTerms] = useState(false);
    const [showTermsModal, setShowTermsModal] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [message, setMessage] = useState<string | null>(null);
    const [showOneTap, setShowOneTap] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [hasReadTerms, setHasReadTerms] = useState(false);

    const router = useRouter();
    const supabase = createClient();

    const handleAuth = async (e: React.FormEvent) => {
        e.preventDefault();

        if (isSignUp && !hasReadTerms) {
            setError('Debe leer y aceptar los términos y condiciones para continuar.');
            return;
        }

        setLoading(true);
        setError(null);
        setMessage(null);

        if (isSignUp) {
            const { error } = await supabase.auth.signUp({
                email,
                password,
                options: {
                    emailRedirectTo: `${location.origin}/auth/callback`,
                    data: {
                        accepted_terms: true,
                        accepted_at: new Date().toISOString(),
                    }
                },
            });
            if (error) {
                setError(error.message);
            } else {
                setMessage('Cuenta creada con éxito. Revisa tu correo de confirmación.');
                setIsSignUp(false);
            }
        } else {
            const { error } = await supabase.auth.signInWithPassword({
                email,
                password,
            });
            if (error) {
                setError(error.message);
            } else {
                router.push('/dashboard');
                router.refresh();
            }
        }
        setLoading(false);
    };

    const handleGoogleLogin = async () => {
        const { error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: `${location.origin}/auth/callback`,
                queryParams: {
                    access_type: 'offline',
                    prompt: 'consent',
                }
            }
        });
        if (error) setError(error.message);
    };

    const handleForgotPassword = async () => {
        if (!email) {
            setError('Por favor ingrese su correo electrónico para restablecer la contraseña.');
            return;
        }
        setLoading(true);
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${location.origin}/auth/callback?type=recovery`,
        });
        setLoading(false);
        if (error) {
            setError(error.message);
        } else {
            setMessage('Se ha enviado un correo para restablecer su contraseña.');
        }
    };

    return (
        <div className="min-h-screen bg-[#030712] flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans text-slate-200">
            {/* Background Orbs (Apple Style) */}
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px]"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 rounded-full blur-[120px]"></div>

            {/* Terms Modal */}
            <TermsModal
                open={showTermsModal}
                onOpenChange={setShowTermsModal}
                onAccept={() => {
                    setHasReadTerms(true);
                    setAcceptedTerms(true);
                    setShowTermsModal(false);
                }}
            />


            {/* Main Card */}
            <div className="w-full max-w-[440px] relative z-10 animate-in fade-in zoom-in-95 duration-1000">
                <div className="bg-[#111827]/80 backdrop-blur-xl rounded-[32px] border border-white/10 p-10 shadow-2xl space-y-8">
                    {/* Header */}
                    <div className="text-center space-y-3">
                        <div className="inline-flex items-center gap-2.5 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full mb-4">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400/80">Sistema en Línea</span>
                        </div>

                        <h1 className="text-4xl font-black tracking-tighter">
                            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-slate-200">
                                UTP CONTROL
                            </span>
                        </h1>
                    </div>

                    {/* Auth Toggle */}
                    <div className="flex bg-slate-900/50 p-1 rounded-2xl border border-white/5">
                        <button
                            onClick={() => { setIsSignUp(false); setError(null); }}
                            className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${!isSignUp ? 'bg-white/10 text-white shadow-lg shadow-white/5' : 'text-slate-500 hover:text-slate-300'}`}
                        >
                            Ingresar
                        </button>
                        <button
                            onClick={() => { setIsSignUp(true); setError(null); }}
                            className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all ${isSignUp ? 'bg-white/10 text-white shadow-lg shadow-white/5' : 'text-slate-500 hover:text-slate-300'}`}
                        >
                            Registro
                        </button>
                    </div>

                    {/* Form */}
                    <form onSubmit={handleAuth} className="space-y-6">
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Correo Electrónico</label>
                                <div className="relative group">
                                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                                    <input
                                        type="email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        placeholder="nombre@empresa.com"
                                        autoComplete="off"
                                        name="email"
                                        className="w-full bg-slate-900/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm font-medium placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500/50 transition-all cursor-text"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <div className="flex justify-between items-center ml-1">
                                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Contraseña</label>
                                    {!isSignUp && (
                                        <button
                                            type="button"
                                            onClick={handleForgotPassword}
                                            className="text-[10px] font-bold text-blue-500 hover:text-blue-400"
                                        >
                                            ¿Olvidó su clave?
                                        </button>
                                    )}
                                </div>
                                <div className="relative group">
                                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                                    <input
                                        type={showPassword ? "text" : "password"}
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="••••••••••••"
                                        autoComplete="new-password"
                                        name="password"
                                        className="w-full bg-slate-900/50 border border-white/10 rounded-2xl py-4 pl-12 pr-12 text-sm font-medium placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500/50 transition-all cursor-text"
                                        required
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-400 transition-colors"
                                    >
                                        {showPassword ? (
                                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                            </svg>
                                        ) : (
                                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.046m4.51-4.51A9.959 9.959 0 0112 5c4.478 0 8.268 2.943 9.542 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21m-2.101-2.101L3 3m5.196 5.196a3 3 0 104.242 4.242" />
                                            </svg>
                                        )}
                                    </button>
                                </div>
                            </div>
                        </div>

                        {isSignUp && (
                            <div className="flex items-start gap-3 p-4 bg-white/5 rounded-2xl border border-white/5 group transition-all hover:bg-white/10">
                                <div className="pt-0.5">
                                    <div
                                        className={`h-5 w-5 rounded-md border-2 transition-all flex items-center justify-center ${hasReadTerms ? 'bg-blue-500 border-blue-500' : 'border-slate-700 bg-slate-900 cursor-not-allowed opacity-50'}`}
                                    >
                                        {hasReadTerms && <ShieldCheck className="h-3.5 w-3.5 text-white" />}
                                    </div>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <p className="text-[11px] text-slate-400 leading-tight">
                                        He leído y acepto los <button type="button" onClick={() => setShowTermsModal(true)} className="text-blue-400 font-bold hover:underline">Términos, Condiciones y Políticas de Privacidad</button> de la plataforma.
                                    </p>
                                </div>
                            </div>
                        )}

                        {error && (
                            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                                <AlertCircle className="h-4 w-4 text-red-400" />
                                <span className="text-xs font-bold text-red-400">{error}</span>
                            </div>
                        )}

                        {message && (
                            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                                <span className="text-xs font-bold text-emerald-400">{message}</span>
                            </div>
                        )}

                        <Button
                            disabled={loading}
                            className="w-full h-14 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-sm uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-blue-900/40 border-t border-white/20 transition-all flex items-center justify-center gap-2 group"
                        >
                            {loading ? (
                                <Loader2 className="h-5 w-5 animate-spin" />
                            ) : (
                                <>
                                    {isSignUp ? 'Crear Espacio de Trabajo' : 'Iniciar Sistema'}
                                    <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                                </>
                            )}
                        </Button>
                    </form>

                    {/* Social Authentication */}
                    <div className="pt-4 space-y-4">
                        <div className="relative flex items-center">
                            <div className="flex-grow border-t border-white/5"></div>
                            <span className="flex-shrink mx-4 text-[10px] font-black uppercase tracking-widest text-slate-600">Conexión Segura</span>
                            <div className="flex-grow border-t border-white/5"></div>
                        </div>

                        <div className="grid grid-cols-1 gap-3">
                            <button
                                onClick={handleGoogleLogin}
                                className="w-full h-12 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl flex items-center justify-center gap-3 transition-all group"
                            >
                                <svg className="h-5 w-5 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                    <path fill="#FBBC05" d="M5.84 16.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V9.06H2.18C1.43 10.55 1 12.22 1 14s.43 3.45 1.18 4.94l3.66-2.84z" />
                                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                                </svg>
                                <span className="text-xs font-bold text-slate-300 group-hover:text-white">Continuar con Google</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Professional Footer (SINAPCODE | Enterprise) */}
            <footer className="mt-12 text-center space-y-2 opacity-50 hover:opacity-100 transition-opacity duration-500 px-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/5 mb-2">
                    <ShieldAlert className="h-3 w-3 text-slate-500" />
                    <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">Cumplimiento de Estándares de Seguridad</span>
                </div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em]">
                    © 2026 <a href="https://sinap-code.vercel.app/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 transition-colors">SINAPCODE</a> | CONTROL UTP.
                </p>
                <p className="text-[9px] font-medium text-slate-600 uppercase tracking-widest">
                    Licenciado bajo términos corporativos. Todas las operaciones están auditadas.
                </p>
            </footer>
        </div>
    );
}
