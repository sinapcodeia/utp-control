'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, X, Smartphone } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
    prompt: () => Promise<void>;
    userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function InstallPWAPrompt() {
    const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
    const [showPrompt, setShowPrompt] = useState(false);
    const [isInstalled, setIsInstalled] = useState(false);

    useEffect(() => {
        // Verificar si ya está instalada
        if (window.matchMedia('(display-mode: standalone)').matches) {
            setIsInstalled(true);
            return;
        }

        // Capturar el evento beforeinstallprompt
        const handler = (e: Event) => {
            e.preventDefault();
            setDeferredPrompt(e as BeforeInstallPromptEvent);

            // Mostrar el prompt después de 10 segundos
            setTimeout(() => {
                const dismissed = localStorage.getItem('pwa-install-dismissed');
                if (!dismissed) {
                    setShowPrompt(true);
                }
            }, 10000);
        };

        window.addEventListener('beforeinstallprompt', handler);

        return () => {
            window.removeEventListener('beforeinstallprompt', handler);
        };
    }, []);

    const handleInstall = async () => {
        if (!deferredPrompt) return;

        // Mostrar el prompt de instalación
        deferredPrompt.prompt();

        // Esperar la respuesta del usuario
        const { outcome } = await deferredPrompt.userChoice;

        if (outcome === 'accepted') {
            console.log('PWA instalada');
        }

        // Limpiar el prompt
        setDeferredPrompt(null);
        setShowPrompt(false);
    };

    const handleDismiss = () => {
        setShowPrompt(false);
        localStorage.setItem('pwa-install-dismissed', 'true');
    };

    // No mostrar si ya está instalada o si no hay prompt
    if (isInstalled || !showPrompt || !deferredPrompt) {
        return null;
    }

    return (
        <div className="fixed bottom-4 left-4 right-4 z-50 animate-in slide-in-from-bottom duration-500 md:left-auto md:right-4 md:max-w-md">
            <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/50 dark:to-indigo-950/50 shadow-2xl">
                <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                            <div className="h-12 w-12 rounded-2xl bg-blue-600 flex items-center justify-center">
                                <Smartphone className="h-6 w-6 text-white" />
                            </div>
                            <div>
                                <CardTitle className="text-lg font-black text-blue-900 dark:text-blue-100">
                                    Instalar UTP CONTROL
                                </CardTitle>
                                <CardDescription className="text-xs font-bold text-blue-700 dark:text-blue-300">
                                    Acceso rápido desde tu pantalla de inicio
                                </CardDescription>
                            </div>
                        </div>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-blue-600 hover:bg-blue-100 dark:hover:bg-blue-900/50"
                            onClick={handleDismiss}
                        >
                            <X className="h-4 w-4" />
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="space-y-3">
                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-xs text-blue-800 dark:text-blue-200">
                            <div className="h-1.5 w-1.5 rounded-full bg-blue-600" />
                            <span className="font-bold">Funciona offline</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-blue-800 dark:text-blue-200">
                            <div className="h-1.5 w-1.5 rounded-full bg-blue-600" />
                            <span className="font-bold">Carga instantánea</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-blue-800 dark:text-blue-200">
                            <div className="h-1.5 w-1.5 rounded-full bg-blue-600" />
                            <span className="font-bold">Actualizaciones automáticas</span>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <Button
                            onClick={handleInstall}
                            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-xs rounded-xl"
                        >
                            <Download className="h-4 w-4 mr-2" />
                            Instalar Ahora
                        </Button>
                        <Button
                            variant="outline"
                            onClick={handleDismiss}
                            className="border-blue-200 text-blue-700 hover:bg-blue-100 dark:border-blue-800 dark:text-blue-300 font-bold text-xs rounded-xl"
                        >
                            Más tarde
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
