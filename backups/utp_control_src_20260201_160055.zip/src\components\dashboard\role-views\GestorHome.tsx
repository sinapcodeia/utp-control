'use client';

import { useState, useEffect } from "react";
import { DashboardStats, TCComplianceUser } from "@/types";
import { createClient } from "@/utils/supabase/client";
import { ManagerHome } from "../gestor/ManagerHome";
import { ManagerAgenda } from "../gestor/ManagerAgenda";
import { VisitWizard } from "../gestor/VisitWizard";
import { ReportsView } from "../gestor/ReportsView";
import { toast } from "sonner";
import { Home, Calendar, FileText } from "lucide-react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

interface GestorHomeProps {
    stats: DashboardStats | null;
    tcCompliance: TCComplianceUser[];
    user: {
        id: string;
        name: string;
        role: string;
        region?: string;
    };
}

type ViewState = 'HOME' | 'AGENDA' | 'WIZARD' | 'REPORTS';

export function GestorHome({ stats, user }: GestorHomeProps) {
    const [view, setView] = useState<ViewState>('HOME');
    const [agendaFilter, setAgendaFilter] = useState<'ALL' | 'PENDING' | 'HIGH'>('ALL');
    const [visits, setVisits] = useState<any[]>([]);
    const [activeVisit, setActiveVisit] = useState<any>(null);
    const [isOnline, setIsOnline] = useState(true);

    useEffect(() => {
        setIsOnline(navigator.onLine);
        const handleStatusChange = () => setIsOnline(navigator.onLine);
        window.addEventListener('online', handleStatusChange);
        window.addEventListener('offline', handleStatusChange);
        return () => {
            window.removeEventListener('online', handleStatusChange);
            window.removeEventListener('offline', handleStatusChange);
        };
    }, []);

    const supabase = createClient();

    const fetchVisits = async () => {
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const res = await fetch(`${API_URL}/territory/my-visits`, {
                headers: {
                    'Authorization': `Bearer ${session?.access_token}`
                }
            });
            if (res.ok) {
                const data = await res.json();
                const sorted = data.sort((a: any, b: any) =>
                    new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime()
                );
                setVisits(sorted);
            }
        } catch (e) {
            console.error("Failed to fetch visits");
        }
    };

    useEffect(() => {
        fetchVisits();
    }, []);

    const handleStartRoute = () => {
        const today = new Date().toLocaleDateString('en-CA');
        const nextVisit = visits.find(v =>
            v.status === 'PENDING' &&
            v.scheduledAt && v.scheduledAt.startsWith(today)
        );
        if (nextVisit) {
            setActiveVisit(nextVisit);
            setView('WIZARD');
        } else {
            toast.info("No hay visitas pendientes para hoy.");
        }
    };

    const handleSelectVisit = (visitId: string) => {
        const visit = visits.find(v => v.id === visitId);
        if (visit) {
            setActiveVisit(visit);
            setView('WIZARD');
        }
    };

    const handleCompleteVisit = async (data: any) => {
        const { syncStatus, ...visitData } = data;

        if (syncStatus === 'SYNCED') {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                await fetch(`${API_URL}/territory/visits/${activeVisit.id}/close`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${session?.access_token}`
                    },
                    body: JSON.stringify(visitData)
                });
                toast.success("Visita sincronizada con el servidor");
            } catch (error) {
                console.error("Error syncing visit", error);
                toast.error("Error al subir, guardando localmente");
                const pending = JSON.parse(localStorage.getItem('pending_visits') || '[]');
                pending.push({ id: activeVisit.id, data: visitData, timestamp: Date.now() });
                localStorage.setItem('pending_visits', JSON.stringify(pending));
            }
        } else {
            const pending = JSON.parse(localStorage.getItem('pending_visits') || '[]');
            pending.push({ id: activeVisit.id, data: visitData, timestamp: Date.now() });
            localStorage.setItem('pending_visits', JSON.stringify(pending));
            toast.warning("Visita guardada en dispositivo (offline)");
        }

        setVisits(prev => prev.map(v =>
            v.id === activeVisit?.id ? { ...v, status: 'COMPLETED' } : v
        ));
        setView('HOME');
    };

    const handleStatClick = (mode: string) => {
        setAgendaFilter(mode as any);
        setView('AGENDA');
    };

    return (
        <div className="min-h-[85vh] relative pb-24 bg-slate-50 dark:bg-slate-950">
            {view === 'HOME' && (
                <ManagerHome
                    visits={visits}
                    onStartRoute={handleStartRoute}
                    userName={user.name}
                    regionName={user.region}
                    onStatClick={handleStatClick}
                />
            )}

            {view === 'AGENDA' && (
                <ManagerAgenda
                    visits={visits}
                    onSelectVisit={(v) => handleSelectVisit(v.id)}
                    onBack={() => setView('HOME')}
                    filterMode={agendaFilter}
                />
            )}

            {view === 'REPORTS' && (
                <ReportsView />
            )}

            {view === 'WIZARD' && activeVisit && (
                <VisitWizard
                    visit={activeVisit}
                    onComplete={handleCompleteVisit}
                    onCancel={() => setView('HOME')}
                />
            )}

            {view !== 'WIZARD' && (
                <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur-md text-white px-6 py-4 rounded-full shadow-2xl flex items-center gap-10 z-40 border border-white/10">
                    <button
                        onClick={() => { setView('HOME'); setAgendaFilter('ALL'); }}
                        className={`transition-colors ${view === 'HOME' ? 'text-blue-400' : 'text-slate-400 hover:text-white'}`}
                    >
                        <Home className="h-7 w-7" />
                    </button>
                    <button
                        onClick={() => { setView('AGENDA'); setAgendaFilter('ALL'); }}
                        className={`transition-colors ${view === 'AGENDA' ? 'text-blue-400' : 'text-slate-400 hover:text-white'}`}
                    >
                        <Calendar className="h-7 w-7" />
                    </button>
                    <button
                        onClick={() => setView('REPORTS')}
                        className={`transition-colors ${view === 'REPORTS' ? 'text-blue-400' : 'text-slate-400 hover:text-white'}`}
                    >
                        <FileText className="h-7 w-7" />
                    </button>
                </div>
            )}
        </div>
    );
}
