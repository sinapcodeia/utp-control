'use client';

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from "lucide-react";
import { format, addDays, subDays, isSameDay, startOfWeek } from 'date-fns';
import { es } from 'date-fns/locale';

interface OperationsCalendarProps {
    selectedDate: Date;
    onDateSelect: (date: Date) => void;
}

export function OperationsCalendar({ selectedDate, onDateSelect }: OperationsCalendarProps) {
    const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));

    const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(currentWeekStart, i));

    const handlePrevWeek = () => setCurrentWeekStart(prev => subDays(prev, 7));
    const handleNextWeek = () => setCurrentWeekStart(prev => addDays(prev, 7));

    return (
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-xl border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-6 px-2">
                <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 dark:bg-blue-900/20">
                        <CalendarIcon className="h-5 w-5" />
                    </div>
                    <div>
                        <h3 className="text-lg font-black uppercase tracking-tight text-slate-900 dark:text-white">
                            Cronograma Operativo
                        </h3>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                            {format(currentWeekStart, "MMMM yyyy", { locale: es })}
                        </p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={handlePrevWeek} className="h-9 w-9 rounded-xl border-slate-200 hover:bg-slate-50 dark:border-slate-700">
                        <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={handleNextWeek} className="h-9 w-9 rounded-xl border-slate-200 hover:bg-slate-50 dark:border-slate-700">
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-7 gap-2">
                {weekDays.map((date) => {
                    const isSelected = isSameDay(date, selectedDate);
                    const isToday = isSameDay(date, new Date());

                    return (
                        <button
                            key={date.toISOString()}
                            onClick={() => onDateSelect(date)}
                            className={`
                                relative flex flex-col items-center justify-center h-24 rounded-2xl transition-all duration-300 group
                                ${isSelected
                                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30 scale-105 z-10'
                                    : 'bg-slate-50 text-slate-500 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-400'
                                }
                            `}
                        >
                            <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isSelected ? 'text-blue-200' : 'text-slate-400'}`}>
                                {format(date, 'EEE', { locale: es })}
                            </span>
                            <span className={`text-2xl font-black ${isSelected ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                                {format(date, 'd')}
                            </span>

                            {/* Indicadores de actividad (Simulados basados en el dı́a) */}
                            <div className="flex gap-1 mt-2">
                                {(() => {
                                    const dayVal = date.getDate();
                                    if (dayVal % 5 === 0) return (
                                        <Badge className="bg-red-500 scale-75 border-none h-2 w-2 rounded-full p-0 shadow-sm shadow-red-500/50" />
                                    );
                                    if (dayVal % 3 === 0) return (
                                        <Badge className="bg-amber-500 scale-75 border-none h-2 w-2 rounded-full p-0 shadow-sm shadow-amber-500/50" />
                                    );
                                    return (
                                        <Badge className="bg-green-500 scale-75 border-none h-2 w-2 rounded-full p-0 shadow-sm shadow-green-500/50" />
                                    );
                                })()}
                            </div>

                            {isToday && !isSelected && (
                                <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-blue-600" />
                            )}
                        </button>
                    );
                })}
            </div>
        </div>
    );
}
