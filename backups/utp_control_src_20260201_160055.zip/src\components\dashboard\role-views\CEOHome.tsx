'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardStats } from "@/types";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Activity, MapPin } from "lucide-react";

interface CEOHomeProps {
    stats: DashboardStats | null;
    user: any;
}

export function CEOHome({ stats, user }: CEOHomeProps) {
    // Calcular tendencias (mock - en producción vendría del backend)
    const icoeValue = (stats as any)?.icoeRaw || 82;
    const icoeTrend: 'up' | 'down' | 'stable' = 'down';
    const complianceValue = (stats as any)?.complianceRaw || 92;
    const complianceTrend: 'up' | 'down' | 'stable' = 'up';
    const riskLevel = (stats as any)?.riskLevel || 'MEDIO';

    // Helper functions
    const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
        if (trend === 'up') return <TrendingUp className="h-12 w-12 text-green-500" />;
        if (trend === 'down') return <TrendingDown className="h-12 w-12 text-red-500" />;
        return <Activity className="h-12 w-12 text-slate-400" />;
    };

    const getTrendColor = (trend: 'up' | 'down' | 'stable') => {
        if (trend === 'up') return 'text-green-500';
        if (trend === 'down') return 'text-red-500';
        return 'text-slate-400';
    };

    const getTrendValue = (trend: 'up' | 'down' | 'stable') => {
        if (trend === 'up') return '+3.2%';
        if (trend === 'down') return '-1.8%';
        return '0%';
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-700 pb-12">
            {/* Header Ejecutivo */}
            <div className="border-b border-slate-200 dark:border-slate-800 pb-6">
                <h1 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white uppercase">
                    Control Tower <span className="text-blue-600">Ejecutivo</span>
                </h1>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">
                    Vista Estratégica • {new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
            </div>

            {/* 5 Preguntas Clave - Hero Section */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                {/* 1. Salud Operativa */}
                <Card className="lg:col-span-2 rounded-[2rem] border-none bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-2xl relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full -translate-y-32 translate-x-32" />
                    </div>
                    <CardHeader className="p-8 relative z-10">
                        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-white/60 mb-2">Salud Operativa</p>
                        <div className="flex items-end gap-4">
                            <h2 className="text-6xl font-black tracking-tighter">
                                {icoeValue}<span className="text-3xl text-white/60">%</span>
                            </h2>
                            <div className={`mb-3 px-3 py-1.5 rounded-xl font-black text-xs uppercase tracking-widest ${icoeValue >= 85 ? 'bg-green-500' :
                                    icoeValue >= 70 ? 'bg-amber-500' :
                                        'bg-red-500'
                                }`}>
                                {icoeValue >= 85 ? 'ÓPTIMO' : icoeValue >= 70 ? 'ACEPTABLE' : 'CRÍTICO'}
                            </div>
                        </div>
                        <p className="text-xs font-bold text-white/80 mt-3">ICOE - Índice de Cobertura Operativa Efectiva</p>
                    </CardHeader>
                </Card>

                {/* 2. Tendencia */}
                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg">
                    <CardHeader className="p-6">
                        <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400 mb-3">Tendencia</p>
                        <div className="flex items-center gap-3">
                            {getTrendIcon(icoeTrend)}
                            <div>
                                <p className={`text-2xl font-black ${getTrendColor(icoeTrend)}`}>
                                    {getTrendValue(icoeTrend)}
                                </p>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">vs mes anterior</p>
                            </div>
                        </div>
                    </CardHeader>
                </Card>

                {/* 3. Riesgo Global */}
                <Card className={`lg:col-span-2 rounded-[2rem] border-none shadow-lg ${riskLevel === 'CRÍTICO' ? 'bg-gradient-to-br from-red-500 to-red-600' :
                    riskLevel === 'MEDIO' ? 'bg-gradient-to-br from-amber-500 to-amber-600' :
                        'bg-gradient-to-br from-green-500 to-green-600'
                    } text-white`}>
                    <CardHeader className="p-6">
                        <div className="flex items-start justify-between">
                            <div>
                                <p className="text-[9px] font-black uppercase tracking-[0.3em] text-white/80 mb-2">Nivel de Riesgo</p>
                                <h3 className="text-4xl font-black tracking-tight mb-2">{riskLevel}</h3>
                                <p className="text-xs font-bold text-white/90">
                                    {stats?.criticalAlerts || 0} alertas críticas • {stats?.preventiveAlerts || 0} preventivas
                                </p>
                            </div>
                            <AlertTriangle className="h-10 w-10 text-white/40" />
                        </div>
                    </CardHeader>
                </Card>
            </div>

            {/* KPIs Ejecutivos Comparativos */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Cumplimiento */}
                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg">
                    <CardHeader className="p-6">
                        <div className="flex justify-between items-start mb-4">
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Cumplimiento</p>
                            {complianceTrend === 'up' && <TrendingUp className="h-4 w-4 text-green-500" />}
                        </div>
                        <div className="flex items-end gap-2">
                            <h4 className="text-4xl font-black text-slate-900 dark:text-white">{complianceValue}%</h4>
                            <span className="mb-1 text-xs font-bold text-green-600">+2%</span>
                        </div>
                        <div className="mt-4 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-green-500 rounded-full transition-all duration-1000" style={{ width: `${complianceValue}%` }} />
                        </div>
                    </CardHeader>
                </Card>

                {/* Cobertura */}
                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg">
                    <CardHeader className="p-6">
                        <div className="flex justify-between items-start mb-4">
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Cobertura</p>
                            <Activity className="h-4 w-4 text-slate-400" />
                        </div>
                        <div className="flex items-end gap-2">
                            <h4 className="text-4xl font-black text-slate-900 dark:text-white">{(stats as any)?.coverageRaw || 76}%</h4>
                            <span className="mb-1 text-xs font-bold text-slate-400">→</span>
                        </div>
                        <div className="mt-4 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full transition-all duration-1000" style={{ width: `${(stats as any)?.coverageRaw || 76}%` }} />
                        </div>
                    </CardHeader>
                </Card>

                {/* Personal Activo */}
                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg">
                    <CardHeader className="p-6">
                        <div className="flex justify-between items-start mb-4">
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Fuerza Activa</p>
                            <CheckCircle2 className="h-4 w-4 text-blue-500" />
                        </div>
                        <div className="flex items-end gap-2">
                            <h4 className="text-4xl font-black text-slate-900 dark:text-white">{stats?.activePersonnel || 128}</h4>
                            <span className="mb-1 text-xs font-bold text-slate-400">/ {stats?.personnelTotal || 150}</span>
                        </div>
                        <div className="mt-4 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full transition-all duration-1000" style={{ width: `${((stats?.activePersonnel || 128) / (stats?.personnelTotal || 150)) * 100}%` }} />
                        </div>
                    </CardHeader>
                </Card>
            </div>

            {/* Análisis Regional - Heatmap Simplificado */}
            <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-lg">
                <CardHeader className="border-b border-slate-100 dark:border-slate-800 p-6">
                    <CardTitle className="text-lg font-black uppercase tracking-tight flex items-center gap-3">
                        <MapPin className="h-5 w-5 text-blue-600" />
                        Salud por Región
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {['Norte', 'Sur', 'Oriente', 'Occidente'].map((region, idx) => {
                            const score = [85, 72, 91, 68][idx];
                            const status = score >= 85 ? 'success' : score >= 70 ? 'warning' : 'danger';
                            return (
                                <div key={region} className="p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:shadow-md transition-all cursor-pointer">
                                    <div className="flex items-center justify-between mb-3">
                                        <p className="text-sm font-bold text-slate-900 dark:text-white">{region}</p>
                                        <div className={`h-3 w-3 rounded-full ${status === 'success' ? 'bg-green-500' :
                                            status === 'warning' ? 'bg-amber-500' :
                                                'bg-red-500'
                                            }`} />
                                    </div>
                                    <p className="text-3xl font-black text-slate-900 dark:text-white mb-2">{score}%</p>
                                    <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                        <div className={`h-full rounded-full transition-all duration-1000 ${status === 'success' ? 'bg-green-500' :
                                            status === 'warning' ? 'bg-amber-500' :
                                                'bg-red-500'
                                            }`} style={{ width: `${score}%` }} />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </CardContent>
            </Card>

            {/* Decisiones Sugeridas */}
            <Card className="rounded-[2rem] border-none bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 shadow-lg">
                <CardHeader className="p-6 border-b border-blue-100 dark:border-blue-900/30">
                    <CardTitle className="text-lg font-black uppercase tracking-tight text-blue-900 dark:text-blue-100">
                        Acciones Recomendadas
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                    <div className="space-y-4">
                        <div className="flex items-start gap-4 p-4 bg-white dark:bg-slate-900 rounded-2xl">
                            <div className="h-10 w-10 rounded-xl bg-red-100 dark:bg-red-900/20 flex items-center justify-center flex-shrink-0">
                                <AlertTriangle className="h-5 w-5 text-red-600" />
                            </div>
                            <div className="flex-1">
                                <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">Reforzar Región Occidente</p>
                                <p className="text-xs text-slate-500">ICOE bajo (68%). Considerar reasignación de 2-3 gestores desde región Norte.</p>
                            </div>
                            <span className="text-[10px] font-black uppercase tracking-widest text-red-600 bg-red-50 dark:bg-red-900/20 px-3 py-1 rounded-lg">Urgente</span>
                        </div>

                        <div className="flex items-start gap-4 p-4 bg-white dark:bg-slate-900 rounded-2xl">
                            <div className="h-10 w-10 rounded-xl bg-amber-100 dark:bg-amber-900/20 flex items-center justify-center flex-shrink-0">
                                <Activity className="h-5 w-5 text-amber-600" />
                            </div>
                            <div className="flex-1">
                                <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">Auditoría de Calidad</p>
                                <p className="text-xs text-slate-500">Score de calidad descendente. Programar capacitación en captura de evidencia.</p>
                            </div>
                            <span className="text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-3 py-1 rounded-lg">Media</span>
                        </div>

                        <div className="flex items-start gap-4 p-4 bg-white dark:bg-slate-900 rounded-2xl">
                            <div className="h-10 w-10 rounded-xl bg-green-100 dark:bg-green-900/20 flex items-center justify-center flex-shrink-0">
                                <CheckCircle2 className="h-5 w-5 text-green-600" />
                            </div>
                            <div className="flex-1">
                                <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">Reconocer Región Oriente</p>
                                <p className="text-xs text-slate-500">Desempeño excepcional (91%). Documentar mejores prácticas para replicar.</p>
                            </div>
                            <span className="text-[10px] font-black uppercase tracking-widest text-green-600 bg-green-50 dark:bg-green-900/20 px-3 py-1 rounded-lg">Baja</span>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
