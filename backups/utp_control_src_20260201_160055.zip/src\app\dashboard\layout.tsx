'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { BarChart3, FileText, Home, LogOut, ShieldAlert, Users, Activity, Contact, LayoutDashboard, Newspaper, BookOpen, FolderOpen, ShieldCheck, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';
import { createClient } from '@/utils/supabase/client';
import { useRouter } from 'next/navigation';
import { NationalNewsPopup } from '@/components/dashboard/national-news-popup';
import { DashboardFooter } from '@/components/dashboard/DashboardFooter';
import { useAuth } from '@/contexts/AuthContext';
import { PushNotificationManager } from '@/components/notifications/PushNotificationManager';

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const pathname = usePathname();
    const router = useRouter();
    const supabase = createClient();
    const { user: currentUser, authUser, loading: authLoading } = useAuth();

    useEffect(() => {
        if (!authLoading && !authUser) {
            router.push('/auth/login');
        }
    }, [authUser, authLoading, router]);

    const handleLogout = async () => {
        await supabase.auth.signOut();
        router.push('/auth/login');
        router.refresh();
    };

    const navigation = [
        { name: 'Panel de Control', href: '/dashboard', icon: LayoutDashboard, allowedRoles: ['ADMIN', 'COORDINATOR', 'GESTOR', 'USER'] },
        // Usuarios: Solo Admin (Global) y Coordinadores (Regional)
        { name: 'Usuarios', href: '/dashboard/users', icon: Users, allowedRoles: ['ADMIN', 'COORDINATOR'] },
        // Visitas: Gestores y Coordinadores
        { name: 'Visitas', href: '/dashboard/visits', icon: MapPin, allowedRoles: ['ADMIN', 'COORDINATOR', 'USER'] },
        // Reportes de Visitas
        { name: 'Reportes de Visitas', href: '/dashboard/visits/reports', icon: FileText, allowedRoles: ['ADMIN', 'COORDINATOR', 'GESTOR'] },
        // Novedades: Todos los operativos
        { name: 'Novedades', href: '/dashboard/news', icon: Newspaper, allowedRoles: ['ADMIN', 'COORDINATOR', 'GESTOR'] },
        // Informes: Todos los operativos
        { name: 'Informes', href: '/dashboard/reports', icon: FileText, allowedRoles: ['ADMIN', 'COORDINATOR', 'GESTOR'] },
        // Directorio y Documentos: Todos
        { name: 'Directorio', href: '/dashboard/directory', icon: BookOpen, allowedRoles: ['ADMIN', 'COORDINATOR', 'GESTOR', 'USER'] },
        { name: 'Documentos', href: '/dashboard/documents', icon: FolderOpen, allowedRoles: ['ADMIN', 'COORDINATOR', 'GESTOR', 'USER'] },
        // Auditoría: Exclusivo ADMIN
        { name: 'Auditoría', href: '/dashboard/audit', icon: ShieldCheck, allowedRoles: ['ADMIN'] },
    ];

    const filteredNavigation = navigation.filter(item =>
        currentUser?.role && item.allowedRoles.includes(currentUser.role as string)
    );

    return (
        <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
            {/* Sidebar */}
            <div className="hidden border-r border-slate-200/60 bg-white/80 backdrop-blur-xl dark:border-slate-800/60 dark:bg-slate-950/80 md:block md:w-64 lg:w-72 relative">
                <div className="flex h-20 items-center px-8">
                    <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-lg bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
                            <ShieldAlert className="h-5 w-5 text-white" />
                        </div>
                        <span className="text-xl font-black tracking-tighter text-slate-900 dark:text-slate-50 uppercase">
                            Control<span className="text-blue-600">.</span>
                        </span>
                    </div>
                </div>
                <div className="flex flex-col gap-1 px-4 py-6">
                    <nav className="space-y-1.5">
                        {filteredNavigation.map((item) => {
                            const isActive = pathname === item.href;
                            return (
                                <Link
                                    key={item.name}
                                    href={item.href}
                                    className={cn(
                                        "group flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm transition-all duration-200 relative",
                                        isActive
                                            ? "bg-blue-50/80 text-blue-700 font-bold dark:bg-blue-900/10 dark:text-blue-400"
                                            : "text-slate-500 font-semibold hover:bg-slate-50 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900/50 dark:hover:text-slate-50"
                                    )}
                                >
                                    {isActive && (
                                        <div className="absolute left-0 w-1 h-5 bg-blue-600 rounded-r-full" />
                                    )}
                                    <item.icon className={cn(
                                        "h-4 w-4 transition-transform group-hover:scale-110",
                                        isActive ? "text-blue-600 dark:text-blue-400" : "text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-50"
                                    )} />
                                    {item.name}
                                </Link>
                            );
                        })}
                    </nav>
                </div>
                <div className="absolute bottom-6 left-0 right-0 px-4">
                    <button
                        onClick={handleLogout}
                        className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-bold text-red-500 transition-all hover:bg-red-50 hover:text-red-700 dark:text-red-400/80 dark:hover:bg-red-900/10 dark:hover:text-red-400"
                    >
                        <LogOut className="h-4 w-4" />
                        Cerrar Sesión
                    </button>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex flex-1 flex-col overflow-hidden">
                <header className="flex h-16 items-center border-b border-slate-200 bg-white px-6 dark:border-slate-800 dark:bg-slate-950 md:hidden">
                    <span className="text-lg font-bold">Menú Móvil</span>
                </header>
                <main className="flex-1 overflow-y-auto p-6 md:p-8">
                    {children}
                    <DashboardFooter />
                </main>
                <NationalNewsPopup userId={currentUser?.id || ''} />
                <PushNotificationManager />
            </div>
        </div>
    );
}
