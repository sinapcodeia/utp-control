
export interface PermissionGroup {
    view: boolean;
    edit: boolean;
    delete: boolean;
}

export interface NewsPermissions extends PermissionGroup {
    create: boolean;
    edit_own: boolean;
    edit_all: boolean;
}

export interface StaffPermissions {
    invite: boolean;
    manage_perms: boolean;
    block: boolean;
}

export interface UserPermissions {
    dir: PermissionGroup;
    news: NewsPermissions;
    staff: StaffPermissions;
    territory?: {
        allRegions: boolean;
        regions: string[]; // IDs of assigned regions
    };
}

// Estructura de Permisos por Defecto por Rol
export const ROLE_DEFAULTS: Record<string, UserPermissions> = {
    ADMIN: {
        dir: { view: true, edit: true, delete: true },
        news: { view: true, edit: true, create: true, edit_own: true, edit_all: true, delete: true },
        staff: { invite: true, manage_perms: true, block: true },
        territory: { allRegions: true, regions: [] }
    },
    COORDINATOR: {
        dir: { view: true, edit: true, delete: false },
        news: { view: true, edit: true, create: true, edit_own: true, edit_all: false, delete: true },
        staff: { invite: true, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    },
    USER: { // This is actually GESTOR in the UI usually
        dir: { view: true, edit: false, delete: false },
        news: { view: true, edit: false, create: false, edit_own: false, edit_all: false, delete: false },
        staff: { invite: false, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    },
    GESTOR: {
        dir: { view: true, edit: false, delete: false },
        news: { view: true, edit: false, create: false, edit_own: false, edit_all: false, delete: false },
        staff: { invite: false, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    },
    SUPPORT: {
        dir: { view: true, edit: false, delete: false },
        news: { view: true, edit: false, create: false, edit_own: false, edit_all: false, delete: false },
        staff: { invite: false, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    }
};
