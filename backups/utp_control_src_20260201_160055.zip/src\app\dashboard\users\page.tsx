
'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";
import {
    UserPlus, Users, Shield, MapPin, Search,
    MoreVertical, Eye, Edit3, Trash2, ShieldCheck,
    Lock, CheckCircle2, AlertCircle, TrendingUp, X
} from "lucide-react";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";
import { apiClient } from "@/lib/api-client";

interface PermissionGroup {
    view: boolean;
    edit: boolean;
    delete: boolean;
}

interface NewsPermissions extends PermissionGroup {
    create: boolean;
    edit_own: boolean;
    edit_all: boolean;
}

interface StaffPermissions {
    invite: boolean;
    manage_perms: boolean;
    block: boolean;
}

interface UserPermissions {
    dir: PermissionGroup;
    news: NewsPermissions;
    staff: StaffPermissions;
    territory?: {
        allRegions: boolean;
        regions: string[]; // IDs of assigned regions
    };
}

interface UserRecord {
    id: string;
    name: string;
    role: 'ADMIN' | 'COORDINATOR' | 'USER' | 'SUPPORT';
    region: string;
    status: 'En línea' | 'En turno' | 'Ausente';
    email: string;
    permissions: UserPermissions;
    assignedRegions?: { id: string; name: string; code: string }[];
    assignedMunicipalities?: string[];
    assignedVeredas?: string[];
}

interface APIUserResponse {
    id: string;
    email: string;
    fullName: string;
    role: string;
    isActive: boolean;
    permissions: Partial<UserPermissions>;
    region: {
        name: string;
    } | null;
    assignedRegions?: { id: string; name: string; code: string }[];
}

// Estructura de Permisos por Defecto por Rol
const ROLE_DEFAULTS: Record<UserRecord['role'], UserPermissions> = {
    ADMIN: {
        dir: { view: true, edit: true, delete: true },
        news: { view: true, edit: true, create: true, edit_own: true, edit_all: true, delete: true },
        staff: { invite: true, manage_perms: true, block: true },
        territory: { allRegions: true, regions: [] }
    },
    COORDINATOR: {
        dir: { view: true, edit: true, delete: false },
        news: { view: true, edit: true, create: true, edit_own: true, edit_all: false, delete: true },
        staff: { invite: true, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    },
    USER: {
        dir: { view: true, edit: false, delete: false },
        news: { view: true, edit: false, create: false, edit_own: false, edit_all: false, delete: false },
        staff: { invite: false, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    },
    SUPPORT: {
        dir: { view: true, edit: false, delete: false },
        news: { view: true, edit: false, create: false, edit_own: false, edit_all: false, delete: false },
        staff: { invite: false, manage_perms: false, block: false },
        territory: { allRegions: false, regions: [] }
    }
};

// DATOS DE PRUEBA para Gestión de Personal
const INITIAL_USERS: UserRecord[] = [
    {
        id: 'U-001',
        name: 'Carlos Pérez',
        role: 'ADMIN',
        region: 'Nacional',
        status: 'En línea',
        email: 'carlos.perez@utp.gov',
        permissions: ROLE_DEFAULTS.ADMIN
    },
    {
        id: 'U-002',
        name: 'Ana García',
        role: 'COORDINATOR',
        region: 'Zona Sur',
        status: 'En turno',
        email: 'ana.garcia@utp.gov',
        permissions: ROLE_DEFAULTS.COORDINATOR
    },
    {
        id: 'U-003',
        name: 'David Silva',
        role: 'COORDINATOR',
        region: 'Central',
        status: 'Ausente',
        email: 'david.silva@utp.gov',
        permissions: ROLE_DEFAULTS.COORDINATOR
    },
    {
        id: 'U-004',
        name: 'Marta Ruiz',
        role: 'USER',
        region: 'Zona Norte',
        status: 'En línea',
        email: 'marta.ruiz@utp.gov',
        permissions: ROLE_DEFAULTS.USER
    },
];

const REGIONS = ['Todas', 'Bogotá D.C.', 'Antioquia', 'Valle del Cauca', 'Atlántico', 'Santander', 'Bolívar', 'Cundinamarca'];

export default function UsersPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase, authReady } = useCurrentUser();
    const [users, setUsers] = useState(INITIAL_USERS);
    const [activeRegion, setActiveRegion] = useState('Todas');
    const [searchTerm, setSearchTerm] = useState('');
    const [isInviteOpen, setIsInviteOpen] = useState(false);
    const [isRegionManageOpen, setIsRegionManageOpen] = useState(false);
    const [selectedUserForRegions, setSelectedUserForRegions] = useState<UserRecord | null>(null);
    const [newUser, setNewUser] = useState<{
        name: string;
        email: string;
        role: string;
        region: string;
        assignedRegions: string[];
        assignedMunicipalities: string[];
        assignedVeredas: string[];
    }>({ name: '', email: '', role: 'COORDINATOR', region: 'Bogotá D.C.', assignedRegions: [], assignedMunicipalities: [], assignedVeredas: [] });
    const [availableRegions, setAvailableRegions] = useState<{ id: string, name: string }[]>([]);
    const [availableMunicipalities, setAvailableMunicipalities] = useState<{ id: string, name: string }[]>([]);
    const [availableVeredas, setAvailableVeredas] = useState<{ id: string, name: string }[]>([]);

    // Cargar regiones disponibles
    useEffect(() => {
        const fetchRegions = async () => {
            try {
                const response = await apiClient.get<any[]>('/territory/regions');
                if (response) {
                    const data = response;
                    if (data && data.length > 0) {
                        setAvailableRegions(data);
                    } else {
                        // Fallback a regiones predefinidas si la base de datos está vacía
                        const fallback = REGIONS.filter(r => r !== 'Todas').map((name, i) => ({
                            id: `fallback-${i}`,
                            name: name
                        }));
                        setAvailableRegions(fallback);
                    }
                }
            } catch (error) { console.error("Error fetching regions:", error); }
        };
        if (currentUser && authReady) fetchRegions();
    }, [currentUser, authReady]);

    // Cargar Municipios cuando cambia la región seleccionada (Cascada)
    useEffect(() => {
        const fetchMunicipalities = async () => {
            if (!newUser.region) return;
            // Encontrar ID de la región seleccionada por nombre (UI usa nombres en el estado principal, pero necesitamos ID para API)
            const regionObj = availableRegions.find(r => r.name === newUser.region);
            const regionId = regionObj?.id;

            try {
                const url = `/territory/municipalities${regionId ? `?regionId=${regionId}` : ''}`;
                const data = await apiClient.get<any[]>(url);
                setAvailableMunicipalities(data);
            } catch (error) { console.error("Error fetching municipalities:", error); }
        };
        if (currentUser && authReady && availableRegions.length > 0) fetchMunicipalities();
    }, [currentUser, authReady, newUser.region, availableRegions]);

    // Cargar Veredas cuando cambian los municipios asignados (Cascada)
    useEffect(() => {
        const fetchVeredas = async () => {
            if (newUser.assignedMunicipalities.length === 0) {
                setAvailableVeredas([]);
                return;
            }

            // Cargar veredas de los municipios seleccionados
            try {
                const promises = newUser.assignedMunicipalities.map(munId =>
                    apiClient.get<any[]>(`/territory/veredas?municipalityId=${munId}`)
                );

                const results = await Promise.all(promises);
                const allVeredas = results.flat();
                setAvailableVeredas(allVeredas);

            } catch (error) { console.error("Error fetching veredas:", error); }
        };
        if (currentUser && authReady && newUser.assignedMunicipalities.length > 0) fetchVeredas();
    }, [currentUser, authReady, newUser.assignedMunicipalities]);

    // CARGAR DATOS PERSISTENTES (AHORA DESDE LA API)
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await apiClient.get<any[]>(`/users${activeRegion !== 'Todas' ? `?region=${activeRegion}` : ''}`);
                const data = response;

                // Normalización de datos para que coincidan con la interfaz
                const normalizedData: UserRecord[] = (data || []).map((u: APIUserResponse) => {
                    if (!u) return null;
                    const role = (u.role as UserRecord['role']) || 'USER';
                    return {
                        id: u.id || 'N/A',
                        email: u.email || 'N/A',
                        name: u.fullName || 'Sin nombre',
                        role: role,
                        region: u.region?.name || 'Nacional',
                        status: 'En línea' as const,
                        permissions: (u.permissions && typeof u.permissions === 'object' && Object.keys(u.permissions).length > 0)
                            ? (u.permissions as UserPermissions)
                            : ROLE_DEFAULTS[role] || ROLE_DEFAULTS.USER,
                        assignedRegions: u.assignedRegions || [],
                        assignedMunicipalities: (u as any).assignedMunicipalities || [],
                        assignedVeredas: (u as any).assignedVeredas || []
                    } as UserRecord;
                }).filter((u): u is UserRecord => u !== null);

                setUsers(normalizedData);
            } catch (error) {
                console.error(error);
                // Fallback a localStorage si la API falla
                const saved = localStorage.getItem('utp_users');
                if (saved) setUsers(JSON.parse(saved));
            }
        };

        if (currentUser && authReady) {
            fetchUsers();
        }
    }, [activeRegion, currentUser, authReady]);

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    const handleInvite = async () => {
        if (!newUser.name || !newUser.email) {
            toast.error("Datos incompletos", { description: "Nombre y correo son obligatorios." });
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(newUser.email)) {
            toast.error("Formato inválido", { description: "Por favor ingresa un correo electrónico válido." });
            return;
        }

        try {
            const createdUser = await apiClient.post<any>('/users', newUser);

            // Normalizar el usuario creado para la UI
            const normalizedUser = {
                ...createdUser,
                name: createdUser.fullName,
                region: newUser.region, // Usamos el valor del form para consistencia inmediata
                status: 'En línea',
                permissions: createdUser.permissions
            };

            setUsers([normalizedUser, ...users]);
            setIsInviteOpen(false);
            setNewUser({ name: '', email: '', role: 'COORDINATOR', region: 'Bogotá D.C.', assignedRegions: [], assignedMunicipalities: [], assignedVeredas: [] });
            toast.success("Agente Invitado", {
                description: "Se ha registrado en la base de datos oficial y se emitió la credencial."
            });
        } catch (error: any) {
            toast.error("Fallo operativa", { description: error.message || "No se pudo registrar el nuevo agente en el servidor." });
        }
    };

    const filteredUsers = users.filter(user => {
        // Lógica de Bloqueo Regional (RBAC)
        // 1. Si es Admin, ve todo.
        // 2. Si es Coord, solo ve su región.
        // 3. Si es User, ve todo (Directorio Nacional) pero en modo solo lectura.

        let canViewUser = true;
        if (currentUser.role === 'COORDINATOR') {
            canViewUser = user.region === currentUser.region?.name;
        }

        const matchesRegion = activeRegion === 'Todas' || user.region === activeRegion;
        const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.role.toLowerCase().includes(searchTerm.toLowerCase());

        // Búsqueda por Capacidades (Extra de Silicon Valley)
        const matchesPermission = Object.entries(user.permissions).some(([_, abilities]) => {
            return Object.entries(abilities as unknown as Record<string, boolean>).some(([ability, val]) => {
                if (!val) return false;
                const translatedAbility = ability === 'view' ? 'ver' : ability === 'edit' ? 'editar' : ability === 'delete' ? 'borrar' : ability;
                return translatedAbility.includes(searchTerm.toLowerCase());
            });
        });

        return canViewUser && matchesRegion && (matchesSearch || matchesPermission);
    });

    const handleTogglePermission = async (userId: string, module: string, ability: string) => {
        if (currentUser.role !== 'ADMIN') {
            toast.error("Acceso denegado", { description: "Solo un administrador puede modificar la matriz nuclear." });
            return;
        }

        const user = users.find(u => u.id === userId);
        if (!user) return;

        const updatedPermissions = { ...user.permissions };
        const moduleKey = module as keyof UserPermissions;

        if (!updatedPermissions[moduleKey]) {
            (updatedPermissions[moduleKey] as any) = {};
        }

        const currentModule = updatedPermissions[moduleKey] as unknown as Record<string, boolean>;
        (updatedPermissions[moduleKey] as any) = {
            ...currentModule,
            [ability]: !currentModule[ability]
        };

        try {
            await apiClient.patch(`/users/${userId}/permissions`, updatedPermissions);

            setUsers(prev => prev.map(u => {
                if (u.id === userId) {
                    return { ...u, permissions: updatedPermissions };
                }
                return u;
            }));

            toast.success("Núcleo de Seguridad Actualizado", {
                description: "Capacidad modificada en tiempo real en la base de datos."
            });
        } catch (error) {
            toast.error("Error de Sincronización", { description: "No se pudo actualizar el permiso en el servidor." });
        }
    };

    const handleUpdateUserRegions = async (userId: string, regionIds: string[]) => {
        try {
            await apiClient.patch(`/users/${userId}`, { assignedRegions: regionIds });

            setUsers(prev => prev.map(u => {
                if (u.id === userId) {
                    return {
                        ...u,
                        assignedRegions: availableRegions
                            .filter(r => regionIds.includes(r.id))
                            .map(r => ({ ...r, code: '' }))
                    };
                }
                return u;
            }));

            toast.success("Zonas Actualizadas", {
                description: "El agente ahora tiene acceso a las regiones seleccionadas."
            });
            setIsRegionManageOpen(false);
        } catch (error) {
            toast.error("Error de Sincronización", { description: "No se pudieron actualizar las regiones." });
        }
    };

    const handleResetToDefaults = async (userId: string, role: string) => {
        if (currentUser.role !== 'ADMIN') return;

        const defaultPermissions = ROLE_DEFAULTS[role as keyof typeof ROLE_DEFAULTS];

        try {
            await apiClient.patch(`/users/${userId}/permissions`, defaultPermissions);

            setUsers(prev => prev.map(user => {
                if (user.id === userId) {
                    return {
                        ...user,
                        permissions: defaultPermissions
                    };
                }
                return user;
            }));

            toast.info("Valores Reestablecidos", {
                description: `Se han aplicado los permisos estándar del rol ${role} en el servidor.`
            });
        } catch (error) {
            toast.error("Error de Sincronización", { description: "No se pudieron reestablecer los permisos." });
        }
    };

    return (
        <div className="space-y-10 animate-in fade-in duration-700 pb-20">
            {/* Resplandor de fondo ambiental */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-40">
                <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-blue-500/10 blur-[120px] rounded-full" />
                <div className="absolute top-[20%] -right-[10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full" />
            </div>

            {/* Sección de encabezado: Estilo Startup */}
            <div className="relative flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                    <Badge variant="outline" className="rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em] dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-400">
                        Admin Central Ops
                    </Badge>
                    <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                        Gestión de <br /> <span className="text-blue-600">Personal</span>
                    </h1>
                    <p className="text-slate-500 font-medium max-w-xl text-lg">
                        Control de identidades, roles regionales y matrices de permisos operativos.
                    </p>
                </div>

                <div className="flex flex-wrap gap-4">
                    <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-4 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-xl flex items-center gap-4">
                        <div className="h-12 w-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white">
                            <Users className="h-6 w-6" />
                        </div>
                        <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Total Usuarios</p>
                            <p className="text-2xl font-black text-slate-900 dark:text-white">{users.length}</p>
                        </div>
                    </div>

                    <Dialog open={isInviteOpen} onOpenChange={setIsInviteOpen}>
                        <DialogTrigger asChild>
                            {currentUser.role !== 'USER' && (
                                <Button className="h-20 rounded-[2.5rem] px-10 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs shadow-2xl shadow-blue-500/30 transition-all hover:scale-[1.02] active:scale-95 flex items-center gap-3">
                                    <UserPlus className="h-4 w-4" />
                                    Invitar Agente
                                </Button>
                            )}
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[500px] rounded-[3rem] border-none bg-white dark:bg-slate-950 p-0 overflow-hidden shadow-2xl">
                            <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-10 text-white relative">
                                <Shield className="absolute top-0 right-0 h-32 w-32 opacity-10 -mr-8 -mt-8" />
                                <DialogHeader>
                                    <DialogTitle className="text-3xl font-black uppercase tracking-tighter leading-none mb-2">
                                        Nueva <br /> <span className="opacity-70">Identidad</span>
                                    </DialogTitle>
                                    <DialogDescription className="text-blue-100 font-medium">
                                        Registra personal regional y asigna sus credenciales iniciales.
                                    </DialogDescription>
                                </DialogHeader>
                            </div>
                            <div className="p-10 space-y-6">
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nombre Completo</Label>
                                    <Input
                                        placeholder="Ej: Lucía Méndez"
                                        value={newUser.name}
                                        onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                                        className="h-14 rounded-2xl bg-slate-50 border-none font-bold px-6"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Correo Operacional</Label>
                                    <Input
                                        type="email"
                                        placeholder="lucia.m@utp.gov"
                                        value={newUser.email}
                                        onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                                        className="h-14 rounded-2xl bg-slate-50 border-none font-bold px-6"
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Rol</Label>
                                        <select
                                            value={newUser.role}
                                            onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                                            className="w-full h-14 rounded-2xl bg-slate-50 border-none font-bold px-4 appearance-none outline-none focus:ring-2 focus:ring-blue-500/20"
                                        >
                                            <option value="ADMIN">ADMIN</option>
                                            <option value="COORDINATOR">COORDINATOR</option>
                                            <option value="USER">GESTOR (USER)</option>
                                            <option value="SUPPORT">APOYO (SUPPORT)</option>
                                        </select>
                                    </div>
                                    <div className="space-y-2 col-span-2">
                                        <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                            {newUser.role === 'COORDINATOR' ? 'Regiones Asignadas' : 'Territorio Operativo'}
                                        </Label>

                                        {/* Selector de Regiones (Solo Coordinadores) */}
                                        {newUser.role === 'COORDINATOR' && (
                                            <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-2 bg-slate-50 rounded-2xl">
                                                {availableRegions.map(r => (
                                                    <div key={r.id} className="flex items-center gap-2">
                                                        <input
                                                            type="checkbox"
                                                            id={`region-${r.id}`}
                                                            checked={newUser.assignedRegions.includes(r.id)}
                                                            onChange={(e) => {
                                                                if (e.target.checked) {
                                                                    setNewUser({ ...newUser, assignedRegions: [...newUser.assignedRegions, r.id] });
                                                                } else {
                                                                    setNewUser({ ...newUser, assignedRegions: newUser.assignedRegions.filter(id => id !== r.id) });
                                                                }
                                                            }}
                                                            className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                                        />
                                                        <label htmlFor={`region-${r.id}`} className="text-xs font-bold text-slate-600 truncate">{r.name}</label>
                                                    </div>
                                                ))}
                                            </div>
                                        )}

                                        {/* Selector de Municipios (Gestores y Apoyo) */}
                                        {(newUser.role === 'USER' || newUser.role === 'SUPPORT') && (
                                            <div className="space-y-4">
                                                <div>
                                                    <p className="text-[9px] font-bold text-slate-400 uppercase mb-2">Municipios (De la región seleccionada)</p>
                                                    <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-2 bg-slate-50 rounded-2xl border border-slate-100">
                                                        {availableMunicipalities.map(m => (
                                                            <div key={m.id} className="flex items-center gap-2">
                                                                <input
                                                                    type="checkbox"
                                                                    id={`mun-${m.id}`}
                                                                    checked={newUser.assignedMunicipalities.includes(m.id)}
                                                                    onChange={(e) => {
                                                                        if (e.target.checked) {
                                                                            setNewUser({ ...newUser, assignedMunicipalities: [...newUser.assignedMunicipalities, m.id] });
                                                                        } else {
                                                                            setNewUser({ ...newUser, assignedMunicipalities: newUser.assignedMunicipalities.filter(id => id !== m.id) });
                                                                        }
                                                                    }}
                                                                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                                                />
                                                                <label htmlFor={`mun-${m.id}`} className="text-xs font-bold text-slate-600 truncate">{m.name}</label>
                                                            </div>
                                                        ))}
                                                        {availableMunicipalities.length === 0 && <p className="text-xs text-slate-400 col-span-2 text-center py-2">Selecciona una región principal arriba para ver municipios.</p>}
                                                    </div>
                                                </div>

                                                {/* Selector de Veredas (Depende de Municipios) */}
                                                {newUser.assignedMunicipalities.length > 0 && (
                                                    <div>
                                                        <p className="text-[9px] font-bold text-slate-400 uppercase mb-2">Veredas Específicas (Opcional)</p>
                                                        <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-2 bg-slate-50 rounded-2xl border border-slate-100">
                                                            {availableVeredas.map(v => (
                                                                <div key={v.id} className="flex items-center gap-2">
                                                                    <input
                                                                        type="checkbox"
                                                                        id={`ver-${v.id}`}
                                                                        checked={newUser.assignedVeredas.includes(v.id)}
                                                                        onChange={(e) => {
                                                                            if (e.target.checked) {
                                                                                setNewUser({ ...newUser, assignedVeredas: [...newUser.assignedVeredas, v.id] });
                                                                            } else {
                                                                                setNewUser({ ...newUser, assignedVeredas: newUser.assignedVeredas.filter(id => id !== v.id) });
                                                                            }
                                                                        }}
                                                                        className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                                                                    />
                                                                    <label htmlFor={`ver-${v.id}`} className="text-xs font-bold text-slate-600 truncate">{v.name}</label>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <Button
                                    onClick={handleInvite}
                                    className="w-full h-16 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20 mt-4"
                                >
                                    Emitir Credencial
                                </Button>
                            </div>
                        </DialogContent>
                    </Dialog>
                </div>
            </div>

            {/* Búsqueda y pestañas regionales */}
            <div className="relative flex flex-col gap-6 z-20">
                <div className="relative group">
                    <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-6 w-6 text-slate-400 group-focus-within:text-blue-600 transition-all duration-300" />
                    <Input
                        placeholder="Buscar por nombre, cargo o correo operacional..."
                        className="pl-16 h-18 rounded-[2rem] border-none bg-white/80 backdrop-blur-md shadow-2xl shadow-slate-200/50 focus:ring-[6px] focus:ring-blue-500/5 transition-all text-lg font-bold dark:bg-slate-900/80 dark:shadow-none dark:border dark:border-slate-800 placeholder:text-slate-300"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>

                <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
                    {REGIONS.filter(r => {
                        if (currentUser.role === 'COORDINATOR') return r === 'Todas' || r === currentUser.region?.name;
                        return true;
                    }).map(region => (
                        <Button
                            key={region}
                            variant={activeRegion === region ? "default" : "ghost"}
                            onClick={() => setActiveRegion(region)}
                            className={`rounded-2xl px-6 h-12 font-black uppercase tracking-widest text-[10px] transition-all duration-500 ${activeRegion === region
                                ? "bg-blue-600 text-white shadow-lg shadow-blue-500/20"
                                : "text-slate-400 hover:text-blue-600 hover:bg-blue-50"
                                }`}
                        >
                            {region}
                        </Button>
                    ))}
                </div>
            </div>

            {/* Cuadrícula de usuarios */}
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 relative z-10">
                {filteredUsers.map((user) => (
                    <UserCard
                        key={user.id}
                        user={user}
                        currentUser={currentUser}
                        handleTogglePermission={handleTogglePermission}
                        handleResetToDefaults={handleResetToDefaults}
                        onManageRegions={() => {
                            setSelectedUserForRegions(user);
                            setIsRegionManageOpen(true);
                        }}
                    />
                ))}
            </div>

            {/* Diálogo de Gestión de Regiones */}
            <Dialog open={isRegionManageOpen} onOpenChange={setIsRegionManageOpen}>
                <DialogContent className="sm:max-w-[500px] rounded-[3rem] border-none bg-white dark:bg-slate-950 p-0 overflow-hidden shadow-2xl">
                    <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-10 text-white relative">
                        <MapPin className="absolute top-0 right-0 h-32 w-32 opacity-10 -mr-8 -mt-8" />
                        <DialogHeader>
                            <DialogTitle className="text-3xl font-black uppercase tracking-tighter leading-none mb-2">
                                Asignar <br /> <span className="opacity-70">Territorios</span>
                            </DialogTitle>
                            <DialogDescription className="text-indigo-100 font-medium">
                                Gestiona las zonas a las que {selectedUserForRegions?.name} tiene acceso.
                            </DialogDescription>
                        </DialogHeader>
                    </div>
                    <div className="p-10 space-y-6">
                        <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto p-4 bg-slate-50 rounded-[2rem] dark:bg-slate-900">
                            {availableRegions.length > 0 ? (
                                availableRegions.map(r => (
                                    <div key={r.id} className="flex items-center gap-3 p-2 hover:bg-white rounded-xl transition-colors dark:hover:bg-slate-800">
                                        <input
                                            type="checkbox"
                                            id={`manage-region-${r.id}`}
                                            checked={selectedUserForRegions?.assignedRegions?.some(ar => ar.id === r.id)}
                                            onChange={(e) => {
                                                if (!selectedUserForRegions) return;
                                                const currentIds = selectedUserForRegions.assignedRegions?.map(ar => ar.id) || [];
                                                const newIds = e.target.checked
                                                    ? [...currentIds, r.id]
                                                    : currentIds.filter(id => id !== r.id);

                                                setSelectedUserForRegions({
                                                    ...selectedUserForRegions,
                                                    assignedRegions: availableRegions
                                                        .filter(ar => newIds.includes(ar.id))
                                                        .map(ar => ({ ...ar, code: '' }))
                                                });
                                            }}
                                            className="h-5 w-5 rounded-lg border-slate-300 text-indigo-600 focus:ring-indigo-500"
                                        />
                                        <label htmlFor={`manage-region-${r.id}`} className="text-sm font-bold text-slate-600 dark:text-slate-400 cursor-pointer">
                                            {r.name}
                                        </label>
                                    </div>
                                ))
                            ) : (
                                <div className="col-span-2 flex flex-col items-center justify-center py-10 opacity-30">
                                    <MapPin className="h-10 w-10 mb-2" />
                                    <p className="text-[10px] font-black uppercase tracking-widest">Sincronizando territorios...</p>
                                </div>
                            )}
                        </div>
                        <Button
                            onClick={() => selectedUserForRegions && handleUpdateUserRegions(selectedUserForRegions.id, selectedUserForRegions.assignedRegions?.map(r => r.id) || [])}
                            className="w-full h-16 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-500/20 mt-4"
                        >
                            Guardar Cambios Territoriales
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>

            {/* Estado vacío */}
            {filteredUsers.length === 0 && (
                <div className="flex flex-col items-center justify-center py-40 bg-white/50 backdrop-blur-md rounded-[4rem] border border-dashed border-slate-200">
                    <Search className="h-20 w-20 text-slate-200 mb-6" />
                    <h3 className="text-2xl font-black text-slate-400 uppercase tracking-tighter">Sin coincidencias detectadas</h3>
                    <p className="text-slate-400 font-medium mt-2">Ajusta los filtros de región o los parámetros de búsqueda.</p>
                </div>
            )}
        </div>
    );
}

import { ChevronDown } from "lucide-react";

function UserCard({ user, currentUser, handleTogglePermission, handleResetToDefaults, onManageRegions }: any) {
    const [isExpanded, setIsExpanded] = useState(false);

    return (
        <Card className="group relative overflow-hidden rounded-[2.5rem] border-none bg-white dark:bg-slate-900 transition-all duration-500 hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)]">
            <div className={`absolute top-0 left-0 right-0 h-1.5 ${user.status === 'En línea' ? 'bg-green-500' : user.status === 'En turno' ? 'bg-blue-500' : 'bg-slate-300'}`} />

            <CardHeader className="p-8 pb-4">
                <div className="flex justify-between items-start mb-6">
                    <div className="h-14 w-14 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center group-hover:scale-105 transition-transform duration-500">
                        <Shield className={`h-7 w-7 ${user.role === 'ADMIN' ? 'text-red-500' : 'text-blue-600'}`} />
                    </div>
                    <div className="flex flex-col items-end gap-2">
                        <Badge className={`${user.status === 'En línea' ? 'bg-green-50 text-green-600' :
                            user.status === 'En turno' ? 'bg-blue-50 text-blue-600' :
                                'bg-slate-50 text-slate-400'
                            } border-none rounded-lg px-2 text-[8px] font-black uppercase tracking-widest`}>
                            {user.status}
                        </Badge>
                        <span className="text-[9px] font-black text-slate-300 uppercase tracking-tighter">ID: {user.id.split('-')[0]}</span>
                    </div>
                </div>

                <CardTitle className="text-2xl font-black text-slate-900 dark:text-white leading-tight mb-1 font-heading">
                    {user.name}
                </CardTitle>
                <p className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] mb-4">
                    {user.role} <span className="text-slate-200 mx-1">/</span> {user.region}
                </p>

                <div className="flex flex-wrap gap-1.5">
                    {user.assignedRegions?.slice(0, 2).map((r: any) => (
                        <Badge key={r.id} variant="outline" className="text-[8px] px-2 py-0.5 border-slate-100 text-slate-400 bg-slate-50/50 rounded-md">
                            {r.name}
                        </Badge>
                    ))}
                    {user.assignedRegions?.length > 2 && (
                        <Badge variant="outline" className="text-[8px] px-2 py-0.5 border-slate-100 text-slate-400 bg-slate-50/50 rounded-md">
                            +{user.assignedRegions.length - 2}
                        </Badge>
                    )}
                </div>
            </CardHeader>

            <CardContent className="p-8 pt-4 space-y-4">
                <Button
                    variant="ghost"
                    onClick={() => setIsExpanded(!isExpanded)}
                    className="w-full h-12 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between px-6 group/btn transition-all hover:bg-blue-50"
                >
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover/btn:text-blue-600">
                        {isExpanded ? 'Ocultar Matriz' : 'Ver Permisos y Zonas'}
                    </span>
                    <ChevronDown className={`h-4 w-4 text-slate-300 transition-transform duration-500 ${isExpanded ? 'rotate-180 text-blue-600' : ''}`} />
                </Button>

                {isExpanded && (
                    <div className="space-y-6 animate-in slide-in-from-top-4 duration-500">
                        <div className="space-y-4">
                            {Object.entries(user.permissions).map(([module, abilities]) => (
                                <div key={module} className="space-y-2">
                                    <h4 className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] pl-1">
                                        {module === 'dir' ? 'Directorio' : module === 'news' ? 'Noticias' : module === 'staff' ? 'Gestión Staff' : 'Territorio'}
                                    </h4>
                                    <div className="grid grid-cols-2 gap-2">
                                        {Object.entries(abilities as any).map(([ability, val]) => (
                                            <div
                                                key={ability}
                                                onClick={() => handleTogglePermission(user.id, module, ability)}
                                                className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-300 ${val
                                                    ? "bg-blue-50/30 border-blue-100 text-blue-700"
                                                    : "bg-slate-50/50 border-slate-100 text-slate-300"
                                                    } ${currentUser.role === 'ADMIN' ? 'cursor-pointer hover:border-blue-300' : 'cursor-not-allowed'}`}
                                            >
                                                <span className="text-[8px] font-black uppercase tracking-tighter">
                                                    {ability === 'view' ? 'Ver' : ability === 'edit' ? 'Editar' : ability === 'delete' ? 'Borrar' : ability === 'create' ? 'Crear' : ability === 'edit_own' ? 'Propios' : ability === 'edit_all' ? 'Global' : ability === 'invite' ? 'Invitar' : ability === 'manage_perms' ? 'Matriz' : ability === 'block' ? 'Bloquear' : ability === 'allRegions' ? 'Todas' : ability}
                                                </span>
                                                {val ? <CheckCircle2 className="h-3 w-3 text-blue-600" /> : <Lock className="h-2.5 w-2.5 opacity-20" />}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="flex gap-2 pt-2">
                            <Button
                                variant="outline"
                                className="flex-1 h-12 rounded-2xl border-slate-100 text-[9px] font-black uppercase tracking-widest text-slate-400 hover:bg-slate-50"
                                onClick={onManageRegions}
                            >
                                <MapPin className="h-3 w-3 mr-2" /> Zonas
                            </Button>
                            {currentUser.role === 'ADMIN' && (
                                <Button
                                    variant="outline"
                                    className="h-12 w-12 rounded-2xl border-slate-100 text-slate-300 hover:text-blue-600 hover:bg-blue-50"
                                    onClick={() => handleResetToDefaults(user.id, user.role)}
                                >
                                    <TrendingUp className="h-4 w-4" />
                                </Button>
                            )}
                            <Button className="h-12 w-12 rounded-2xl bg-slate-900 hover:bg-black text-white">
                                <Edit3 className="h-4 w-4" />
                            </Button>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
