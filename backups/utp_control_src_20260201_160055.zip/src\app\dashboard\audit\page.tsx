'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
    Activity,
    Search,
    ShieldCheck,
    Users,
    FileCheck,
    AlertCircle,
    ExternalLink,
    Download,
    CheckCircle2,
    XCircle,
    Zap,
    RefreshCw,
    Activity as ActivityIcon,
    Server,
    Database,
    Lock as LockIcon
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";

import { toast } from "sonner";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

export default function AuditPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();

    const [complianceStats, setComplianceStats] = useState<any[]>([]);
    const [tcCompliance, setTcCompliance] = useState<any[]>([]);
    const [auditLogs, setAuditLogs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [health, setHealth] = useState<any>(null);
    const [isKilling, setIsKilling] = useState(false);

    const fetchData = async () => {
        setLoading(true);
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const headers = { 'Authorization': `Bearer ${session?.access_token}` };

            const [complianceRes, tcRes, logsRes] = await Promise.all([
                fetch(`${API_URL}/regional-reports/compliance-stats`, { headers }),
                fetch(`${API_URL}/users/tc-compliance`, { headers }),
                fetch(`${API_URL}/audit`, { headers })
            ]);

            if (complianceRes.ok) setComplianceStats(await complianceRes.json());
            if (tcRes.ok) setTcCompliance(await tcRes.json());
            if (logsRes.ok) {
                const rawLogs = await logsRes.json();
                const normalizedLogs = rawLogs.map((log: any) => ({
                    id: log.id,
                    time: new Date(log.timestamp).toLocaleString(),
                    user: log.user?.fullName || 'Sistema',
                    action: log.action,
                    detail: `${log.entity}: ${log.entityId}`,
                    ip: log.ipAddress || 'Interna'
                }));
                setAuditLogs(normalizedLogs);
            }
        } catch (e) {
            console.error("Error fetching audit data", e);
        } finally {
            setLoading(false);
        }
    };

    const fetchHealth = async () => {
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/audit/health`, {
                headers: { 'Authorization': `Bearer ${session?.access_token}` }
            });
            if (response.ok) setHealth(await response.json());
        } catch (e) { console.error("Health check failed", e); }
    };

    useEffect(() => {
        if (currentUser) {
            fetchData();
            fetchHealth();
            const interval = setInterval(fetchHealth, 30000); // Cada 30s
            return () => clearInterval(interval);
        }
    }, [currentUser, supabase.auth]);

    const handleKillSwitch = async () => {
        if (!confirm("⚠️ ATENCIÓN: Se cerrarán todos los procesos de Node y Prisma. El sistema se reiniciará. ¿Proceder con el Protocolo de Rescate?")) return;

        setIsKilling(true);
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/audit/kill-processes`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${session?.access_token}` }
            });

            if (response.ok) {
                toast.success("Protocolo Iniciado", { description: "Limpiando procesos bloqueantes..." });
                setTimeout(() => window.location.reload(), 3000);
            } else {
                toast.error("Error en Rescate", { description: "No se pudo ejecutar el comando de limpieza." });
            }
        } catch (error) {
            toast.error("Fallo de Conexión", { description: "El servidor podría estar ya reiniciándose." });
        } finally {
            setIsKilling(false);
        }
    };

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }


    return (
        <div className="space-y-8 animate-in fade-in duration-700" suppressHydrationWarning>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <Badge variant="outline" className="mb-2 rounded-full border-blue-100 bg-blue-50 text-blue-700 px-3 py-0.5 font-bold text-[10px] uppercase tracking-widest">
                        Centro de Control de Integridad
                    </Badge>
                    <h2 className="text-4xl font-black tracking-tight uppercase">Auditoría <span className="text-blue-600">&</span> Cumplimiento</h2>
                    <p className="text-slate-500 font-medium text-lg">
                        Supervisión inmutable de operaciones y compromisos legales.
                    </p>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 px-4 py-2 rounded-2xl border border-green-100 shadow-sm animate-pulse">
                    <ShieldCheck className="h-4 w-4" />
                    <span className="font-black uppercase tracking-widest text-[10px]">Logging de Seguridad Activo</span>
                </div>
            </div>

            <Tabs defaultValue="compliance" className="w-full space-y-8">
                <TabsList className="bg-slate-100 dark:bg-slate-900 p-1.5 rounded-2xl h-14 w-fit">
                    <TabsTrigger value="compliance" className="rounded-xl px-8 font-black uppercase tracking-widest text-[10px] data-[state=active]:bg-white data-[state=active]:shadow-lg h-full transition-all">
                        <FileCheck className="mr-2 h-4 w-4" /> Cumplimiento Operacional
                    </TabsTrigger>
                    <TabsTrigger value="activity" className="rounded-xl px-8 font-black uppercase tracking-widest text-[10px] data-[state=active]:bg-white data-[state=active]:shadow-lg h-full transition-all">
                        <ActivityIcon className="mr-2 h-4 w-4" /> Registro de Actividad
                    </TabsTrigger>
                    <TabsTrigger value="rescue" className="rounded-xl px-8 font-black uppercase tracking-widest text-[10px] data-[state=active]:bg-red-600 data-[state=active]:text-white data-[state=active]:shadow-lg h-full transition-all">
                        <Zap className="mr-2 h-4 w-4" /> Rescue Center
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="compliance" className="space-y-8 outline-none">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* National News Compliance */}
                        <Card className="rounded-[2.5rem] border-none shadow-2xl bg-white dark:bg-slate-950 overflow-hidden">
                            <CardHeader className="p-8 pb-4">
                                <CardTitle className="text-xl font-black uppercase tracking-tight flex items-center justify-between">
                                    <span>Acuses de Recibo: Noticias</span>
                                    <Badge className="bg-blue-600">En Vivo</Badge>
                                </CardTitle>
                                <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">Impacto de comunicados nacionales en coordinadores</p>
                            </CardHeader>
                            <CardContent className="p-8 pt-0 space-y-6">
                                {complianceStats.length === 0 ? (
                                    <div className="p-10 text-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
                                        <AlertCircle className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                                        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Sin comunicados registrados</p>
                                    </div>
                                ) : (
                                    complianceStats.map((stat: any) => (
                                        <div key={stat.id} className="space-y-3 p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 transition-all hover:bg-white dark:hover:bg-slate-900 group">
                                            <div className="flex justify-between items-start">
                                                <div className="flex-1">
                                                    <h4 className="text-xs font-black uppercase tracking-tight line-clamp-1 group-hover:text-blue-600 transition-colors">{stat.content.split(': ')[0]}</h4>
                                                    <p className="text-[10px] font-bold text-slate-400 uppercase mt-1 tracking-widest">ID: {stat.id.split('-')[0]}</p>
                                                </div>
                                                <Badge className={`${stat.percentage === 100 ? 'bg-green-500' : 'bg-blue-600'} rounded-lg text-[9px] font-black`}>
                                                    {stat.percentage.toFixed(0)}%
                                                </Badge>
                                            </div>
                                            <Progress value={stat.percentage} className="h-2 rounded-full overflow-hidden" />
                                            <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase tracking-widest pt-1">
                                                <span>{stat.readCount} Usuarios Han Leído</span>
                                                <span>Meta: {stat.totalUsers}</span>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </CardContent>
                        </Card>

                        {/* T&C Compliance */}
                        <Card className="rounded-[2.5rem] border-none shadow-2xl bg-white dark:bg-slate-950 overflow-hidden">
                            <CardHeader className="p-8 pb-4">
                                <CardTitle className="text-xl font-black uppercase tracking-tight flex items-center justify-between">
                                    <span>Compromiso Legal: T&C</span>
                                    <Users className="h-5 w-5 text-slate-300" />
                                </CardTitle>
                                <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">Aceptación de términos y condiciones por usuario</p>
                            </CardHeader>
                            <CardContent className="p-8 pt-0">
                                <div className="space-y-4">
                                    {tcCompliance.map((user: any) => (
                                        <div key={user.id} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800">
                                            <div className="flex items-center gap-4">
                                                <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-black text-xs ${user.acceptedTerms ? 'bg-green-500' : 'bg-slate-300 animate-pulse'}`}>
                                                    {user.fullName.substring(0, 2).toUpperCase()}
                                                </div>
                                                <div>
                                                    <h4 className="text-xs font-black uppercase tracking-tighter">{user.fullName}</h4>
                                                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{user.role} | {user.region?.name || 'NACIONAL'}</p>
                                                </div>
                                            </div>
                                            <div className="flex flex-col items-end gap-1">
                                                {user.acceptedTerms ? (
                                                    <Badge variant="outline" className="border-green-100 bg-green-50 text-green-600 rounded-lg text-[8px] font-black py-0">
                                                        FIRMADO
                                                    </Badge>
                                                ) : (
                                                    <Badge variant="outline" className="border-red-100 bg-red-50 text-red-600 rounded-lg text-[8px] font-black py-0">
                                                        PENDIENTE
                                                    </Badge>
                                                )}
                                                {user.acceptedAt && <span className="text-[8px] font-bold text-slate-400 font-mono tracking-tighter">{new Date(user.acceptedAt).toLocaleDateString()}</span>}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <Button className="w-full mt-6 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-black uppercase tracking-widest text-[9px] h-12 gap-2">
                                    <Download className="h-4 w-4" /> Exportar Reporte de Cumplimiento
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="activity" className="space-y-8 outline-none">
                    <Card className="rounded-[2.5rem] border-none shadow-2xl bg-white dark:bg-slate-950 overflow-hidden">
                        <CardHeader className="p-8">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                                <CardTitle className="text-xl font-black uppercase tracking-tight flex items-center gap-2">
                                    <Activity className="h-5 w-5 text-blue-600" />
                                    Últimos Movimientos
                                </CardTitle>
                                <div className="relative group w-full max-w-sm">
                                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                                    <input
                                        type="text"
                                        placeholder="Filtrar por usuario o IP..."
                                        className="w-full rounded-2xl border border-slate-100 bg-slate-50 py-3 pl-12 pr-4 text-xs font-bold outline-none focus:ring-4 focus:ring-blue-500/10 transition-all dark:border-slate-800 dark:bg-slate-900"
                                    />
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent className="p-8 pt-0">
                            <div className="relative w-full overflow-auto rounded-[1.5rem] bg-slate-50 dark:bg-slate-900/30 border border-slate-100 dark:border-slate-800">
                                <table className="w-full text-sm text-left">
                                    <thead>
                                        <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-800/50">
                                            <th className="h-14 px-6 align-middle font-black text-slate-500 uppercase tracking-widest text-[10px]">Timestamp</th>
                                            <th className="h-14 px-6 align-middle font-black text-slate-500 uppercase tracking-widest text-[10px]">Agente Operativo</th>
                                            <th className="h-14 px-6 align-middle font-black text-slate-500 uppercase tracking-widest text-[10px]">Acción Realizada</th>
                                            <th className="h-14 px-6 align-middle font-black text-slate-500 uppercase tracking-widest text-[10px]">Estado IP</th>
                                        </tr>
                                    </thead>
                                    <tbody className="[&_tr:last-child]:border-0 font-medium">
                                        {auditLogs.map((log) => (
                                            <tr key={log.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-white dark:hover:bg-slate-900 transition-colors">
                                                <td className="px-6 py-5 align-middle font-mono text-[10px] text-slate-400">{log.time}</td>
                                                <td className="px-6 py-5 align-middle">
                                                    <div className="flex items-center gap-3">
                                                        <div className="h-2 w-2 rounded-full bg-blue-600 shadow-lg shadow-blue-500/50 animate-pulse" />
                                                        <span className="font-black text-xs uppercase tracking-tighter">{log.user}</span>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-5 align-middle">
                                                    <Badge variant="outline" className="border-blue-100 bg-blue-50/30 text-blue-600 rounded-lg text-[9px] font-black uppercase">
                                                        {log.action}
                                                    </Badge>
                                                    <p className="text-[10px] text-slate-400 mt-1 font-bold pl-1">{log.detail}</p>
                                                </td>
                                                <td className="px-6 py-5 align-middle font-mono text-[10px] text-slate-400 tracking-tighter">{log.ip}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="rescue" className="space-y-8 outline-none">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        {/* Health Dashboard */}
                        <Card className="lg:col-span-2 rounded-[2.5rem] border-none shadow-2xl bg-slate-950 text-white overflow-hidden relative">
                            <div className="absolute top-0 right-0 p-8 opacity-10">
                                <Zap className="h-32 w-32 text-red-500" />
                            </div>
                            <CardHeader className="p-10">
                                <CardTitle className="text-2xl font-black uppercase tracking-tighter flex items-center gap-3">
                                    <ActivityIcon className="h-6 w-6 text-red-500" />
                                    Estado Vital del Sistema
                                </CardTitle>
                                <p className="text-white/40 font-bold uppercase tracking-widest text-xs">Diagnóstico en tiempo real de infraestructura</p>
                            </CardHeader>
                            <CardContent className="p-10 pt-0">
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                                    <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl transition-all hover:bg-white/10">
                                        <Server className="h-5 w-5 text-blue-400 mb-4" />
                                        <h4 className="text-[10px] font-black uppercase tracking-widest text-white/60 mb-1">API Core</h4>
                                        <div className="flex items-center gap-2">
                                            <div className="h-2 w-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                                            <span className="text-lg font-black uppercase tracking-tighter text-white">{health?.services?.api || '---'}</span>
                                        </div>
                                    </div>
                                    <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl transition-all hover:bg-white/10">
                                        <Database className="h-5 w-5 text-purple-400 mb-4" />
                                        <h4 className="text-[10px] font-black uppercase tracking-widest text-white/60 mb-1">Base de Datos</h4>
                                        <div className="flex items-center gap-2">
                                            <div className={`h-2 w-2 rounded-full shadow-lg ${health?.services?.database === 'ONLINE' ? 'bg-green-500 shadow-green-500/50' : 'bg-red-500 shadow-red-500/50 animate-pulse'}`} />
                                            <span className="text-lg font-black uppercase tracking-tighter text-white">{health?.services?.database || '---'}</span>
                                        </div>
                                    </div>
                                    <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl transition-all hover:bg-white/10">
                                        <LockIcon className="h-5 w-5 text-orange-400 mb-4" />
                                        <h4 className="text-[10px] font-black uppercase tracking-widest text-white/60 mb-1">Auth Service</h4>
                                        <div className="flex items-center gap-2">
                                            <div className="h-2 w-2 rounded-full bg-green-500 shadow-green-500/50" />
                                            <span className="text-lg font-black uppercase tracking-tighter text-white">{health?.services?.auth || '---'}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-8 p-6 rounded-3xl bg-red-500/10 border border-red-500/20">
                                    <div className="flex items-center justify-between mb-4">
                                        <span className="text-[10px] font-black uppercase tracking-widest text-red-400">Latencia de Respuesta DB</span>
                                        <span className="text-xl font-black text-white font-mono">{health?.metrics?.dbLatency || '0ms'}</span>
                                    </div>
                                    <Progress value={health?.metrics?.dbLatency ? parseInt(health.metrics.dbLatency) : 0} className="h-1.5 bg-white/10" />
                                </div>
                            </CardContent>
                        </Card>

                        {/* Kill Switch Action */}
                        <Card className="rounded-[2.5rem] border-none shadow-2xl bg-white dark:bg-slate-950 overflow-hidden flex flex-col justify-center p-10 text-center space-y-6">
                            <div className="mx-auto h-20 w-20 rounded-full bg-red-50 flex items-center justify-center border-4 border-red-100">
                                <RefreshCw className={`h-10 w-10 text-red-600 ${isKilling ? 'animate-spin' : ''}`} />
                            </div>
                            <div>
                                <h3 className="text-2xl font-black uppercase tracking-tighter">Protocolo de Rescate</h3>
                                <p className="text-sm font-medium text-slate-500 mt-2">Finaliza procesos colgados y libera la base de datos de forma segura.</p>
                            </div>
                            <Button
                                onClick={handleKillSwitch}
                                disabled={isKilling}
                                className="w-full h-16 rounded-3xl bg-red-600 hover:bg-red-700 text-white font-black uppercase tracking-widest text-xs shadow-[0_20px_40px_-10px_rgba(220,38,38,0.4)] transition-all hover:scale-[1.02] active:scale-95 gap-3"
                            >
                                <Zap className="h-5 w-5" />
                                {isKilling ? 'EJECUTANDO...' : 'EJECUTAR KILL SWITCH'}
                            </Button>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Uso exclusivo para administradores de nivel 1</p>
                        </Card>
                    </div>
                </TabsContent>
            </Tabs>
        </div >
    );
}

// Internal Button component to reduce dependency issues for this specific refactor
function Button({ children, onClick, variant, className, disabled, type }: any) {
    const baseStyles = "px-4 py-2 flex items-center justify-center transition-all duration-300 active:scale-95";
    const variantStyles = variant === 'outline'
        ? "border border-slate-200 hover:border-blue-200 hover:bg-blue-50/30"
        : variant === 'ghost' ? "hover:bg-slate-100" : "";

    return (
        <button
            type={type}
            disabled={disabled}
            onClick={onClick}
            className={`${baseStyles} ${variantStyles} ${className} ${disabled ? 'opacity-50 cursor-not-allowed text-slate-400' : ''}`}
        >
            {children}
        </button>
    );
}
