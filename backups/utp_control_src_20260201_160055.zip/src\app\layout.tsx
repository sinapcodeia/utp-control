import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/contexts/AuthContext";
import { InstallPWAPrompt } from "@/components/InstallPWAPrompt";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "UTP CONTROL - Gestión Territorial",
  description: "Sistema de Gestión Territorial Operativa",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "UTP CONTROL",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: "website",
    siteName: "UTP CONTROL",
    title: "UTP CONTROL - Gestión Territorial",
    description: "Sistema de Gestión Territorial Operativa",
  },
  twitter: {
    card: "summary",
    title: "UTP CONTROL",
    description: "Sistema de Gestión Territorial Operativa",
  },
};

export const viewport = {
  themeColor: "#2563eb",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${outfit.variable} antialiased`}
        suppressHydrationWarning
      >
        <AuthProvider>
          {children}
          <Toaster />
          <InstallPWAPrompt />
        </AuthProvider>
      </body>
    </html>
  );
}
