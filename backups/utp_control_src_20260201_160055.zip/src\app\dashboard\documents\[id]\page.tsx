'use client';

import { use, useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, MessageSquare, Send, User, Clock, ShieldCheck, Download, ExternalLink } from "lucide-react";
import Link from 'next/link';
import { toast } from "sonner";
import { useRouter } from 'next/navigation';
import { useCurrentUser } from "@/hooks/useCurrentUser";

interface User {
    id: string;
    fullName: string;
}

interface Comment {
    id: string;
    content: string;
    createdAt: string;
    user: User;
}

interface Document {
    id: string;
    title: string;
    url: string;
    createdAt: string;
    uploader: User;
    comments: Comment[];
}

export default function DocumentDetailPage({ params }: { params: Promise<{ id: string }> }) {
    const { user: currentUser, supabase } = useCurrentUser();
    const router = useRouter();
    const resolvedParams = use(params);
    const documentId = resolvedParams.id;

    const [document, setDocument] = useState<Document | null>(null);
    const [newComment, setNewComment] = useState('');
    const [loading, setLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

    useEffect(() => {
        const fetchDocument = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/documents/${documentId}`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });
                if (response.ok) {
                    const data = await response.json();
                    setDocument(data);
                } else {
                    toast.error("Documento no encontrado");
                    router.push('/dashboard/documents');
                }
            } catch (error) {
                console.error('Error fetching document:', error);
                toast.error("Error al cargar el documento");
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchDocument();
        }
    }, [documentId, router, currentUser, supabase.auth, API_URL]);

    const handleAddComment = async () => {
        if (!newComment.trim()) return;

        setIsSubmitting(true);
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/documents/${documentId}/comments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session?.access_token}`
                },
                body: JSON.stringify({ content: newComment }),
            });

            if (response.ok) {
                const comment = await response.json();
                setDocument(prev => prev ? {
                    ...prev,
                    comments: [...prev.comments, comment]
                } : null);
                setNewComment('');
                toast.success("Comentario añadido");
            } else {
                toast.error("Error al añadir comentario");
            }
        } catch (error) {
            console.error('Error adding comment:', error);
            toast.error("Error operativo al comentar");
        } finally {
            setIsSubmitting(false);
        }
    };

    if (loading) {
        return <div className="h-screen flex items-center justify-center animate-pulse text-blue-600 font-black">CARGANDO...</div>;
    }

    if (!document) return null;

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-6">
                    <Link href="/dashboard/documents">
                        <Button variant="outline" size="icon" className="h-14 w-14 rounded-2xl border-slate-200 hover:bg-blue-600 hover:text-white transition-all shadow-lg">
                            <ArrowLeft className="h-6 w-6" />
                        </Button>
                    </Link>
                    <div className="space-y-1">
                        <h1 className="text-4xl font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-none">
                            {document.title}
                        </h1>
                        <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest">
                            <ShieldCheck className="h-3 w-3 text-blue-600" />
                            Documento Integrado UTP • ID-{document.id.split('-')[0]}
                        </div>
                    </div>
                </div>

                <div className="flex gap-4">
                    <Button variant="outline" className="h-14 rounded-2xl px-6 font-black uppercase tracking-widest text-[10px] gap-2 border-slate-200 shadow-xl" asChild>
                        <a href={document.url} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4" />
                            Descargar
                        </a>
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Visualizer and Details */}
                <div className="lg:col-span-2 space-y-8">
                    <Card className="rounded-[2.5rem] border-none bg-slate-100 dark:bg-slate-900 overflow-hidden shadow-2xl min-h-[600px] flex flex-col items-center justify-center p-12 text-center relative">
                        <div className="absolute inset-0 bg-white/40 dark:bg-slate-950/40 backdrop-blur-sm z-10 flex flex-col items-center justify-center">
                            <div className="h-24 w-24 rounded-[2.5rem] bg-blue-600 flex items-center justify-center text-white mb-6 shadow-2xl shadow-blue-500/50">
                                <FileCheck className="h-10 w-10" />
                            </div>
                            <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter mb-4">Visualización Segura Activada</h3>
                            <p className="text-slate-500 font-medium max-w-md mb-8">
                                El visor nativo de alta resolución se está cargando. Puedes usar el enlace externo para una revisión inmediata.
                            </p>
                            <Button className="h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs gap-3" asChild>
                                <a href={document.url} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-4 w-4" />
                                    Abrir en Ventana Nueva
                                </a>
                            </Button>
                        </div>
                    </Card>

                    <Card className="rounded-[2.5rem] border-none bg-white dark:bg-slate-900 p-8 shadow-xl">
                        <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-6">Detalles Técnicos</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                            <div>
                                <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">Autor</p>
                                <p className="font-bold text-slate-900 dark:text-white">{document.uploader.fullName}</p>
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">Fecha</p>
                                <p className="font-bold text-slate-900 dark:text-white">{new Date(document.createdAt).toLocaleDateString()}</p>
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">Estado</p>
                                <Badge className="bg-green-100 text-green-700 border-none font-black text-[9px] uppercase tracking-widest">CERTIFIED</Badge>
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">Tipo</p>
                                <p className="font-bold text-slate-900 dark:text-white">PDF / Oficial</p>
                            </div>
                        </div>
                    </Card>
                </div>

                {/* Append-only Comments Section */}
                <div className="space-y-8">
                    <Card className="rounded-[2.5rem] border-none bg-white dark:bg-slate-900 p-8 shadow-xl h-full flex flex-col">
                        <div className="flex items-center justify-between mb-8">
                            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-[0.3em] flex items-center gap-2">
                                <MessageSquare className="h-4 w-4 text-blue-600" />
                                Hilo de Comentarios
                            </h3>
                            <Badge variant="outline" className="rounded-full border-blue-100 text-blue-600 text-[10px] font-bold">
                                {document.comments.length}
                            </Badge>
                        </div>

                        <div className="flex-1 space-y-6 overflow-y-auto pr-2 max-h-[500px] scrollbar-hide">
                            {document.comments.length === 0 ? (
                                <div className="text-center py-12">
                                    <p className="text-sm font-bold text-slate-400">No hay interacciones registradas.</p>
                                </div>
                            ) : document.comments.map((comment) => (
                                <div key={comment.id} className="group flex gap-4 animate-in slide-in-from-right-4 duration-500">
                                    <div className="h-10 w-10 shrink-0 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-blue-600 font-black text-[10px]">
                                        {comment.user.fullName.substring(0, 2).toUpperCase()}
                                    </div>
                                    <div className="flex-1 space-y-1">
                                        <div className="flex justify-between items-center">
                                            <span className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-tighter">
                                                {comment.user.fullName}
                                            </span>
                                            <span className="text-[8px] font-bold text-slate-400 flex items-center gap-1">
                                                <Clock className="h-2 w-2" />
                                                {new Date(comment.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                            </span>
                                        </div>
                                        <div className="p-4 rounded-2xl rounded-tl-none bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-sm font-medium text-slate-600 dark:text-slate-300">
                                            {comment.content}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="mt-8 space-y-4 pt-6 border-t border-slate-100 dark:border-slate-800">
                            <Textarea
                                placeholder="Añadir una observación técnica..."
                                className="min-h-[100px] rounded-2xl bg-slate-50 border-none font-bold placeholder:text-slate-300 focus:ring-4 focus:ring-blue-500/10"
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                disabled={isSubmitting}
                            />
                            <Button
                                className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs gap-3 shadow-xl shadow-blue-500/20"
                                onClick={handleAddComment}
                                disabled={isSubmitting || !newComment.trim()}
                            >
                                {isSubmitting ? 'Enviando...' : (
                                    <>
                                        <Send className="h-4 w-4" />
                                        Registrar Comentario
                                    </>
                                )}
                            </Button>
                            <p className="text-[9px] text-center font-bold text-slate-400 uppercase tracking-widest">
                                Los comentarios son permanentes para fines de auditoría.
                            </p>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
}

// Subcomponent for the icon (Missing in previous imports)
function FileCheck(props: any) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
            <polyline points="14 2 14 8 20 8" />
            <path d="m9 15 2 2 4-4" />
        </svg>
    );
}
