'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Activity, CheckCircle2, AlertTriangle, XCircle, Server, Database, Cloud, Shield, Clock } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from "recharts";
import { toast } from "sonner";

import { useCurrentUser } from "@/hooks/useCurrentUser";

// Datos simulados de latencia
const latencyData = [
    { time: '10:00', ms: 45 }, { time: '10:05', ms: 42 }, { time: '10:10', ms: 55 },
    { time: '10:15', ms: 48 }, { time: '10:20', ms: 40 }, { time: '10:25', ms: 38 },
    { time: '10:30', ms: 120 }, { time: '10:35', ms: 45 }, { time: '10:40', ms: 42 },
];

const components = [
    { name: 'API Gateway', status: 'Operational', uptime: '99.99%', icon: Server },
    { name: 'Base de Datos (PostgreSQL)', status: 'Operational', uptime: '99.95%', icon: Database },
    { name: 'Almacenamiento (Storage)', status: 'Operational', uptime: '99.99%', icon: Cloud },
    { name: 'Autenticación & Seguridad', status: 'Degraded', uptime: '98.50%', icon: Shield },
];

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

export default function StatusPage() {
    const { user: currentUser, supabase } = useCurrentUser();
    const [loading, setLoading] = useState(true);
    const [status, setStatus] = useState<any>(null);

    useEffect(() => {
        const fetchStatus = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/health`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });
                if (response.ok) {
                    const data = await response.json();
                    setStatus(data);
                }
            } catch (error) {
                console.error("Error al obtener estado del sistema:", error);
                toast.error("Error al conectar con el monitor de servicios");
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchStatus();
        }
    }, [currentUser, supabase.auth]);

    const renderedComponents = [
        {
            name: 'Pasarela de API',
            status: status ? 'Operativo' : 'Operativo',
            uptime: status?.uptime ? `${Math.floor(status.uptime / 3600)}h ${Math.floor((status.uptime % 3600) / 60)}m` : '99.99%',
            icon: Server
        },
        {
            name: 'Base de Datos (PostgreSQL)',
            status: status?.database?.status === 'healthy' ? 'Operativo' : status ? 'Degradado' : 'Operativo',
            uptime: '99.95%',
            icon: Database
        },
        { name: 'Almacenamiento de Archivos', status: 'Operativo', uptime: '99.99%', icon: Cloud },
        { name: 'Seguridad y Accesos', status: status ? 'Operativo' : 'Operativo', uptime: '98.50%', icon: Shield },
    ];

    return (
        <div className="space-y-8" suppressHydrationWarning>
            <div className="flex flex-col gap-2">
                <h2 className="text-3xl font-bold tracking-tight">Estado del Sistema</h2>
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium dark:bg-green-900/30 dark:text-green-400">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>Todos los sistemas operativos</span>
                    </div>
                    <p className="text-sm text-slate-500">Última actualización: Hace un momento</p>
                </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {renderedComponents.map((component) => (
                    <Card key={component.name} className="border-l-4 border-l-transparent hover:border-l-blue-500 transition-all">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">
                                {component.name}
                            </CardTitle>
                            <component.icon className="h-4 w-4 text-slate-500" />
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center gap-2 mt-2">
                                {component.status === 'Operational' ? (
                                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                                ) : component.status === 'Degraded' ? (
                                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                                ) : (
                                    <XCircle className="h-5 w-5 text-red-500" />
                                )}
                                <span className={`text-lg font-bold ${component.status === 'Operational' ? 'text-green-600' :
                                    component.status === 'Degraded' ? 'text-amber-600' : 'text-red-600'
                                    }`}>
                                    {component.status === 'Operational' ? 'Operativo' : 'Degradado'}
                                </span>
                            </div>
                            <p className="text-xs text-slate-500 mt-1">
                                Uptime (90d): {component.uptime}
                            </p>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <div className="grid gap-4 md:grid-cols-7">
                <Card className="col-span-4">
                    <CardHeader>
                        <CardTitle>Latencia del Sistema (ms)</CardTitle>
                        <CardDescription>Tiempo de respuesta del API en tiempo real.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={latencyData}>
                                    <defs>
                                        <linearGradient id="colorMs" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                                    <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}ms`} />
                                    <Tooltip
                                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                                    />
                                    <Area type="monotone" dataKey="ms" stroke="#3b82f6" fillOpacity={1} fill="url(#colorMs)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </CardContent>
                </Card>

                <Card className="col-span-3">
                    <CardHeader>
                        <CardTitle>Historial de Incidentes</CardTitle>
                        <CardDescription>Eventos registrados en los últimos 30 días.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-8">
                            <div className="flex">
                                <div className="mr-4 flex flex-col items-center">
                                    <div className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900">
                                        <Clock className="h-5 w-5 text-slate-500" />
                                    </div>
                                    <div className="h-full w-px bg-slate-200 dark:bg-slate-800 my-2" />
                                </div>
                                <div className="pb-8">
                                    <h4 className="text-sm font-semibold">Mantenimiento Base de Datos</h4>
                                    <span className="text-xs text-slate-500">22 Ene, 02:00 AM - 04:00 AM</span>
                                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                                        Ventana de mantenimiento programada completada exitosamente. Se aplicaron parches de seguridad y optimización de índices.
                                    </p>
                                </div>
                            </div>
                            <div className="flex">
                                <div className="mr-4 flex flex-col items-center">
                                    <div className="flex h-10 w-10 items-center justify-center rounded-full border border-amber-200 bg-amber-50 dark:border-amber-900/50 dark:bg-amber-900/20">
                                        <AlertTriangle className="h-5 w-5 text-amber-600" />
                                    </div>
                                </div>
                                <div>
                                    <h4 className="text-sm font-semibold">Latencia Alta en API</h4>
                                    <span className="text-xs text-slate-500">20 Ene, 14:30 PM - 14:45 PM</span>
                                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                                        Se detectó un pico inusual de tráfico que afectó los tiempos de respuesta. El balanceador de carga auto-escaló las instancias.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
