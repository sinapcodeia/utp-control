'use client';

import { useState, useEffect } from 'react';
import { jsPDF } from "jspdf";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
    FileText, Download, Eye, Filter, Calendar, MapPin, User, Clock,
    CheckCircle2, XCircle, AlertTriangle, TrendingUp, BarChart3, Search
} from "lucide-react";
import { toast } from "sonner";
import { format, parseISO, startOfDay, endOfDay, isWithinInterval, isValid } from 'date-fns';
import { es } from 'date-fns/locale';
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";

import { apiClient } from "@/lib/api-client";

interface VisitReport {
    id: string;
    visitId: string;
    fullName: string;
    addressText: string;
    scheduledAt: string;
    completedAt: string;
    status: string; // REALIZADA, NOVEDADES, NO_REALIZADA
    unitStatus?: string; // OPTIMO, SEGUIMIENTO, CRITICO
    compliance?: string; // SI, PARCIAL, NO
    alertType?: string; // CRITICA, PREVENTIVA, INFORMATIVA, NINGUNA
    alertObs?: string;
    evidence?: string[];
    duration?: number; // minutos
    region?: { name: string };
    municipality?: { name: string };
    assignedTo?: { fullName: string };
}

interface VisitStats {
    total: number;
    completed: number;
    withIssues: number;
    notCompleted: number;
    avgDuration: number;
    complianceRate: number;
}

export default function VisitReportsPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase, authReady } = useCurrentUser();
    const [reports, setReports] = useState<VisitReport[]>([]);
    const [filteredReports, setFilteredReports] = useState<VisitReport[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedReport, setSelectedReport] = useState<VisitReport | null>(null);
    const [isDetailOpen, setIsDetailOpen] = useState(false);
    const [stats, setStats] = useState<VisitStats>({
        total: 0,
        completed: 0,
        withIssues: 0,
        notCompleted: 0,
        avgDuration: 0,
        complianceRate: 0
    });

    // Filtros
    const [filters, setFilters] = useState({
        search: '',
        status: 'ALL',
        dateFrom: '',
        dateTo: '',
        region: 'ALL'
    });

    // Cargar reportes
    useEffect(() => {
        const fetchReports = async () => {
            try {
                setLoading(true);
                // Usamos el endpoint general para respetar jerarquías (Admins ven todo, Gestores solo lo suyo)
                const response = await apiClient.get<any[]>('/territory/visits');

                if (response) {
                    const data = response;
                    // Filtrar solo visitas completadas
                    // Nota: El backend ya devuelve los metadatos de los logs (compliance, etc.)
                    const completedVisits = data.filter((v: any) => v.status === 'COMPLETED' || v.status === 'REALIZADA');
                    setReports(completedVisits);
                    setFilteredReports(completedVisits);
                    calculateStats(completedVisits);
                }
            } catch (error) {
                console.error('Error fetching reports:', error);
                toast.error('Error al cargar reportes');
            } finally {
                setLoading(false);
            }
        };

        if (currentUser && authReady) {
            fetchReports();
        }
    }, [currentUser, authReady]);

    // Calcular estadísticas
    const calculateStats = (data: VisitReport[]) => {
        const total = data.length;
        const completed = data.filter(r => r.status === 'REALIZADA' || r.status === 'COMPLETED').length;
        const withIssues = data.filter(r => r.status === 'NOVEDADES').length;
        const notCompleted = data.filter(r => r.status === 'NO_REALIZADA').length;

        const durations = data.filter(r => r.duration).map(r => r.duration || 0);
        const avgDuration = durations.length > 0
            ? durations.reduce((a, b) => a + b, 0) / durations.length
            : 0;

        const compliant = data.filter(r => r.compliance === 'SI').length;
        const complianceRate = total > 0 ? (compliant / total) * 100 : 0;

        setStats({
            total,
            completed,
            withIssues,
            notCompleted,
            avgDuration,
            complianceRate
        });
    };

    // Aplicar filtros
    useEffect(() => {
        let filtered = [...reports];

        // Filtro de búsqueda
        if (filters.search) {
            filtered = filtered.filter(r =>
                r.fullName.toLowerCase().includes(filters.search.toLowerCase()) ||
                r.addressText.toLowerCase().includes(filters.search.toLowerCase())
            );
        }

        // Filtro de estado
        if (filters.status !== 'ALL') {
            filtered = filtered.filter(r => r.status === filters.status ||
                (filters.status === 'REALIZADA' && r.status === 'COMPLETED'));
        }

        // Filtro de fecha
        if (filters.dateFrom || filters.dateTo) {
            filtered = filtered.filter(r => {
                const reportDate = new Date(r.completedAt || r.scheduledAt);
                if (!isValid(reportDate)) return true;

                if (filters.dateFrom && filters.dateTo) {
                    return isWithinInterval(reportDate, {
                        start: startOfDay(parseISO(filters.dateFrom)),
                        end: endOfDay(parseISO(filters.dateTo))
                    });
                } else if (filters.dateFrom) {
                    return reportDate >= startOfDay(parseISO(filters.dateFrom));
                } else if (filters.dateTo) {
                    return reportDate <= endOfDay(parseISO(filters.dateTo));
                }
                return true;
            });
        }

        setFilteredReports(filtered);
        calculateStats(filtered);
    }, [filters, reports]);

    // Exportar a PDF Real
    const handleExportPDF = (report: VisitReport) => {
        try {
            const doc = new jsPDF();

            // Header con diseño premium
            doc.setFillColor(37, 99, 235); // Blue-600
            doc.rect(0, 0, 210, 40, 'F');

            doc.setTextColor(255, 255, 255);
            doc.setFont("helvetica", "bold");
            doc.setFontSize(22);
            doc.text("UTP CONTROL", 20, 20);
            doc.setFontSize(16);
            doc.text("REPORTE DE VISITA", 20, 30);

            doc.setFontSize(9);
            doc.setFont("helvetica", "normal");
            doc.text(`Fecha de Emisión: ${format(new Date(), "dd/MM/yyyy, HH:mm:ss")}`, 145, 30);

            // Body - Información General
            doc.setTextColor(0, 0, 0);
            doc.setFontSize(14);
            doc.setFont("helvetica", "bold");
            doc.text("INFORMACIÓN DEL BENEFICIARIO", 20, 55);

            doc.setFontSize(11);
            doc.setFont("helvetica", "normal");
            doc.text(`Nombre Completo: ${report.fullName}`, 20, 65);
            doc.text(`Dirección: ${report.addressText}`, 20, 75);

            const visitDate = new Date(report.completedAt || report.scheduledAt);
            doc.text(`Fecha Visita: ${isValid(visitDate) ? format(visitDate, "dd/MM/yyyy, HH:mm") : 'No registrada'}`, 20, 85);

            if (report.region) doc.text(`Región: ${report.region.name}`, 20, 95);
            if (report.municipality) doc.text(`Municipio: ${report.municipality.name}`, 110, 95);

            // Sección Resultados
            doc.setFillColor(248, 250, 252); // Slate-50
            doc.rect(15, 105, 180, 70, 'F');

            doc.setFont("helvetica", "bold");
            doc.text("RESULTADOS DE LA EVALUACIÓN", 20, 115);

            doc.setFont("helvetica", "normal");
            doc.text(`Estado Final: ${report.status}`, 20, 125);
            doc.text(`Estado de Unidad: ${report.unitStatus || 'N/A'}`, 20, 135);
            doc.text(`Cumplimiento Técnico: ${report.compliance || 'N/A'}`, 20, 145);
            doc.text(`Duración de Visita: ${report.duration ? `${report.duration} min` : 'No registrada'}`, 20, 155);

            // Alertas
            if (report.alertType && report.alertType !== 'NINGUNA') {
                doc.setTextColor(220, 38, 38); // Red-600
                doc.setFont("helvetica", "bold");
                doc.text(`ALERTA: ${report.alertType}`, 20, 165);
                doc.setTextColor(0, 0, 0);
                doc.setFont("helvetica", "italic");
                doc.text(`Obs: ${report.alertObs || 'Sin observaciones'}`, 20, 172);
            }

            // Gestor Responsable
            doc.setFont("helvetica", "bold");
            doc.text("GESTOR RESPONSABLE", 20, 195);
            doc.setFont("helvetica", "normal");
            doc.text(`${report.assignedTo?.fullName || currentUser?.full_name || 'Desconocido'}`, 20, 205);

            // Footer
            doc.setFontSize(9);
            doc.setTextColor(150, 150, 150);
            doc.text("Este es un documento oficial generado automáticamente por el sistema UTP CONTROL.", 105, 280, { align: 'center' });
            doc.text("© 2026 UTP - Todos los derechos reservados.", 105, 285, { align: 'center' });

            const fileName = `reporte-visita-${report.fullName.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`;
            doc.save(fileName);
            toast.success(`Reporte generado: ${fileName}`);
        } catch (error) {
            console.error("Error generating PDF:", error);
            toast.error("Error al generar el PDF");
        }
    };

    // Ver detalle
    const handleViewDetail = (report: VisitReport) => {
        setSelectedReport(report);
        setIsDetailOpen(true);
    };

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    const getStatusConfig = (status: string) => {
        switch (status) {
            case 'REALIZADA':
            case 'COMPLETED':
                return { color: 'bg-green-500', text: 'Realizada', icon: CheckCircle2 };
            case 'NOVEDADES':
                return { color: 'bg-amber-500', text: 'Con Novedades', icon: AlertTriangle };
            case 'NO_REALIZADA':
                return { color: 'bg-red-500', text: 'No Realizada', icon: XCircle };
            default:
                return { color: 'bg-gray-500', text: 'Desconocido', icon: FileText };
        }
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                    <Badge variant="outline" className="rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em]">
                        Análisis de Campo
                    </Badge>
                    <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                        Reportes de <span className="text-blue-600">Visitas</span>
                    </h1>
                    <p className="text-slate-500 font-medium max-w-xl text-lg">
                        Historial completo de visitas realizadas con métricas y análisis.
                    </p>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="rounded-[2rem] border-none bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-2xl shadow-blue-500/30">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                            <FileText className="h-8 w-8 opacity-80" />
                            <TrendingUp className="h-5 w-5 opacity-60" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Total</p>
                        <p className="text-4xl font-black">{stats.total}</p>
                    </CardContent>
                </Card>

                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                            <CheckCircle2 className="h-8 w-8 text-green-600" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Completadas</p>
                        <p className="text-4xl font-black text-slate-900 dark:text-white">{stats.completed}</p>
                    </CardContent>
                </Card>

                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                            <Clock className="h-8 w-8 text-blue-600" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Tiempo Promedio</p>
                        <p className="text-4xl font-black text-slate-900 dark:text-white">{Math.round(stats.avgDuration)}<span className="text-lg">min</span></p>
                    </CardContent>
                </Card>

                <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-xl">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                            <BarChart3 className="h-8 w-8 text-purple-600" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Cumplimiento</p>
                        <p className="text-4xl font-black text-slate-900 dark:text-white">{Math.round(stats.complianceRate)}<span className="text-lg">%</span></p>
                    </CardContent>
                </Card>
            </div>

            {/* Filtros */}
            <Card className="rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-2xl">
                <CardHeader className="p-8 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-800 rounded-t-[3rem]">
                    <div className="flex items-center gap-3">
                        <Filter className="h-6 w-6 text-slate-600 dark:text-slate-400" />
                        <CardTitle className="text-xl font-black uppercase tracking-tighter text-slate-900 dark:text-white">
                            Filtros
                        </CardTitle>
                    </div>
                </CardHeader>
                <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {/* Búsqueda */}
                        <div className="space-y-2">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Buscar</Label>
                            <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                <Input
                                    placeholder="Nombre o dirección..."
                                    value={filters.search}
                                    onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                                    className="h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none pl-11 font-medium"
                                />
                            </div>
                        </div>

                        {/* Estado */}
                        <div className="space-y-2">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Estado</Label>
                            <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                                <SelectTrigger className="h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none font-medium">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="ALL">Todos</SelectItem>
                                    <SelectItem value="REALIZADA">Realizadas</SelectItem>
                                    <SelectItem value="NOVEDADES">Con Novedades</SelectItem>
                                    <SelectItem value="NO_REALIZADA">No Realizadas</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        {/* Fecha Desde */}
                        <div className="space-y-2">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Desde</Label>
                            <Input
                                type="date"
                                value={filters.dateFrom}
                                onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
                                className="h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none font-medium"
                            />
                        </div>

                        {/* Fecha Hasta */}
                        <div className="space-y-2">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Hasta</Label>
                            <Input
                                type="date"
                                value={filters.dateTo}
                                onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
                                className="h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none font-medium"
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Lista de Reportes */}
            <Card className="rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-2xl">
                <CardHeader className="p-8">
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-2xl font-black uppercase tracking-tighter text-slate-900 dark:text-white">
                            Reportes ({filteredReports.length})
                        </CardTitle>
                    </div>
                </CardHeader>
                <CardContent className="p-8 pt-0">
                    {loading ? (
                        <div className="flex items-center justify-center py-12">
                            <div className="h-8 w-8 rounded-full border-4 border-blue-600 border-t-transparent animate-spin" />
                        </div>
                    ) : filteredReports.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-12 text-center">
                            <FileText className="h-16 w-16 text-slate-200 dark:text-slate-700 mb-4" />
                            <p className="text-sm font-bold text-slate-400">No se encontraron reportes</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {filteredReports.map(report => {
                                const statusConfig = getStatusConfig(report.status);
                                const StatusIcon = statusConfig.icon;

                                return (
                                    <Card key={report.id} className="rounded-2xl border border-slate-100 dark:border-slate-800 hover:shadow-lg transition-all duration-300 overflow-hidden group">
                                        <CardContent className="p-6">
                                            <div className="flex items-start justify-between gap-4">
                                                {/* Icono de Estado */}
                                                <div className={`h-12 w-12 rounded-2xl ${statusConfig.color} flex items-center justify-center text-white flex-shrink-0`}>
                                                    <StatusIcon className="h-6 w-6" />
                                                </div>

                                                {/* Información */}
                                                <div className="flex-1 min-w-0">
                                                    <h3 className="font-black text-slate-900 dark:text-white text-lg mb-2">{report.fullName}</h3>

                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                                                        <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                                            <MapPin className="h-4 w-4 flex-shrink-0" />
                                                            <span className="truncate">{report.addressText}</span>
                                                        </div>
                                                        <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                                                            <Calendar className="h-4 w-4 flex-shrink-0" />
                                                            <span>{new Date(report.completedAt || report.scheduledAt).toLocaleDateString('es-ES')}</span>
                                                        </div>
                                                    </div>

                                                    <div className="flex items-center gap-3">
                                                        <Badge className={`${statusConfig.color} text-white text-[8px] font-black uppercase tracking-widest`}>
                                                            {statusConfig.text}
                                                        </Badge>
                                                        {report.compliance && (
                                                            <Badge variant="outline" className="text-[8px] font-black uppercase tracking-widest">
                                                                Cumplimiento: {report.compliance}
                                                            </Badge>
                                                        )}
                                                        {report.duration && (
                                                            <span className="text-xs text-slate-500 font-medium">
                                                                {report.duration} min
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>

                                                {/* Acciones */}
                                                <div className="flex flex-col gap-2 flex-shrink-0">
                                                    <Button
                                                        size="sm"
                                                        onClick={() => handleViewDetail(report)}
                                                        className="h-10 w-10 rounded-xl bg-blue-600 hover:bg-blue-700 text-white p-0"
                                                    >
                                                        <Eye className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        onClick={() => handleExportPDF(report)}
                                                        className="h-10 w-10 rounded-xl border-slate-200 hover:bg-slate-50 p-0"
                                                    >
                                                        <Download className="h-4 w-4" />
                                                    </Button>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                );
                            })}
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Dialog de Detalle */}
            <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
                <DialogContent className="sm:max-w-[700px] rounded-[3rem] border-none bg-white dark:bg-slate-950 p-0 overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto">
                    {selectedReport && (
                        <>
                            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-10 text-white relative overflow-hidden">
                                <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
                                <div className="absolute -left-8 -bottom-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
                                <DialogHeader className="relative z-10">
                                    <div className="h-16 w-16 rounded-[2rem] bg-white/20 backdrop-blur-md flex items-center justify-center mb-4 shadow-xl">
                                        <FileText className="h-8 w-8 text-white" />
                                    </div>
                                    <DialogTitle className="text-3xl font-black uppercase tracking-tighter leading-none mb-2">
                                        Detalle de<br />
                                        <span className="opacity-70">Visita</span>
                                    </DialogTitle>
                                    <DialogDescription className="text-blue-100 font-medium">
                                        Información completa del reporte de visita
                                    </DialogDescription>
                                </DialogHeader>
                            </div>

                            <div className="p-10 space-y-6">
                                {/* Información Básica */}
                                <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-[2rem] space-y-4">
                                    <h3 className="text-lg font-black text-slate-900 dark:text-white">{selectedReport.fullName}</h3>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Dirección</p>
                                            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{selectedReport.addressText}</p>
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Fecha</p>
                                            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                                                {new Date(selectedReport.completedAt || selectedReport.scheduledAt).toLocaleString('es-ES')}
                                            </p>
                                        </div>
                                    </div>

                                    {selectedReport.region && (
                                        <div>
                                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Región</p>
                                            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{selectedReport.region.name}</p>
                                        </div>
                                    )}
                                </div>

                                {/* Resultados */}
                                <div className="space-y-4">
                                    <h4 className="text-sm font-black uppercase tracking-widest text-slate-400">Resultados</h4>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Estado de Visita</p>
                                            <Badge className={`${getStatusConfig(selectedReport.status).color} text-white`}>
                                                {getStatusConfig(selectedReport.status).text}
                                            </Badge>
                                        </div>

                                        {selectedReport.unitStatus && (
                                            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Estado Unidad</p>
                                                <Badge variant="outline">{selectedReport.unitStatus}</Badge>
                                            </div>
                                        )}

                                        {selectedReport.compliance && (
                                            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Cumplimiento</p>
                                                <Badge variant="outline">{selectedReport.compliance}</Badge>
                                            </div>
                                        )}

                                        {selectedReport.duration && (
                                            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Duración</p>
                                                <p className="text-lg font-black text-slate-900 dark:text-white">{selectedReport.duration} min</p>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {/* Alertas */}
                                {selectedReport.alertType && selectedReport.alertType !== 'NINGUNA' && (
                                    <div className="p-6 bg-red-50 dark:bg-red-900/20 rounded-[2rem] border-2 border-red-200 dark:border-red-800">
                                        <div className="flex items-center gap-3 mb-3">
                                            <AlertTriangle className="h-5 w-5 text-red-600" />
                                            <h4 className="text-sm font-black uppercase tracking-widest text-red-600">Alerta Registrada</h4>
                                        </div>
                                        <Badge className="bg-red-600 text-white mb-3">{selectedReport.alertType}</Badge>
                                        {selectedReport.alertObs && (
                                            <p className="text-sm text-slate-700 dark:text-slate-300">{selectedReport.alertObs}</p>
                                        )}
                                    </div>
                                )}

                                {/* Evidencia */}
                                {selectedReport.evidence && selectedReport.evidence.length > 0 && (
                                    <div className="space-y-3">
                                        <h4 className="text-sm font-black uppercase tracking-widest text-slate-400">Evidencia</h4>
                                        <div className="grid grid-cols-3 gap-3">
                                            {selectedReport.evidence.map((item, index) => (
                                                <div key={index} className="aspect-square bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center">
                                                    <FileText className="h-8 w-8 text-slate-400" />
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                <DialogFooter className="gap-3">
                                    <Button
                                        variant="ghost"
                                        onClick={() => setIsDetailOpen(false)}
                                        className="flex-1 h-14 rounded-2xl font-black uppercase tracking-widest text-xs text-slate-400 hover:text-slate-600"
                                    >
                                        Cerrar
                                    </Button>
                                    <Button
                                        onClick={() => handleExportPDF(selectedReport)}
                                        className="flex-1 h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20"
                                    >
                                        <Download className="h-4 w-4 mr-2" />
                                        Exportar PDF
                                    </Button>
                                </DialogFooter>
                            </div>
                        </>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
