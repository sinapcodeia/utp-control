
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Users, AlertTriangle, RefreshCcw, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { createClient } from "@/utils/supabase/client";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

interface SimulationResult {
    original: { backlog: number; sla: number; risk: string };
    simulated: { backlog: number; sla: number; risk: string; deltaBacklog: number; deltaSla: number };
}

export function CoordinatorSimulation() {
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<SimulationResult | null>(null);
    const [params, setParams] = useState({
        capacityAdjustment: 0,
        demandIncrease: 0,
        riskFactor: 0
    });

    const supabase = createClient();

    const runSimulation = async () => {
        setLoading(true);
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/territory/simulate`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session?.access_token}`
                },
                body: JSON.stringify(params)
            });
            if (response.ok) {
                const data = await response.json();
                setResult(data);
                toast.success("Escenario simulado correctamente");
            }
        } catch (e) {
            toast.error("Error al ejecutar simulación");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="rounded-[3rem] border-none bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
            <CardHeader className="p-8 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                <div className="flex items-center justify-between">
                    <div>
                        <Badge variant="outline" className="mb-2 border-indigo-200 bg-indigo-50 text-indigo-700 font-bold uppercase tracking-widest text-[10px]">Estrategia</Badge>
                        <CardTitle className="text-3xl font-black uppercase tracking-tight text-slate-900 dark:text-white">
                            Simulador <span className="text-indigo-600">Operativo</span>
                        </CardTitle>
                        <p className="text-sm font-medium text-slate-500 mt-1">
                            Proyección de impacto en SLAs y Capacidad (Análisis de Escenarios)
                        </p>
                    </div>
                    <div className="h-14 w-14 rounded-2xl bg-indigo-100 flex items-center justify-center text-indigo-600">
                        <TrendingUp className="h-7 w-7" />
                    </div>
                </div>
            </CardHeader>

            <CardContent className="p-0 grid grid-cols-1 lg:grid-cols-3">
                {/* Controls Panel */}
                <div className="p-8 space-y-8 border-r border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">

                    <div className="space-y-4">
                        <div className="flex justify-between">
                            <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Ajuste de Capacidad</span>
                            <Badge className={params.capacityAdjustment < 0 ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"}>
                                {params.capacityAdjustment > 0 ? "+" : ""}{params.capacityAdjustment}%
                            </Badge>
                        </div>
                        <Slider
                            value={[params.capacityAdjustment]}
                            min={-50} max={50} step={5}
                            onValueChange={(v) => setParams({ ...params, capacityAdjustment: v[0] })}
                            className="py-4"
                        />
                        <p className="text-[10px] text-slate-400">Simula contratación (+) o ausencias (-)</p>
                    </div>

                    <div className="space-y-4">
                        <div className="flex justify-between">
                            <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Aumento de Demanda</span>
                            <Badge variant="secondary" className="font-bold">{params.demandIncrease}%</Badge>
                        </div>
                        <Slider
                            value={[params.demandIncrease]}
                            min={0} max={100} step={5}
                            onValueChange={(v) => setParams({ ...params, demandIncrease: v[0] })}
                            className="py-4"
                        />
                        <p className="text-[10px] text-slate-400">Proyección de carga de trabajo entrante</p>
                    </div>

                    <div className="space-y-4">
                        <div className="flex justify-between">
                            <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Factor de Riesgo</span>
                            <Badge variant="outline" className={params.riskFactor > 0.7 ? "border-red-200 text-red-600 font-bold" : "border-slate-200 font-bold"}>
                                {(params.riskFactor * 100).toFixed(0)}%
                            </Badge>
                        </div>
                        <Slider
                            value={[params.riskFactor]}
                            min={0} max={1} step={0.1}
                            onValueChange={(v) => setParams({ ...params, riskFactor: v[0] })}
                            className="py-4"
                        />
                        <p className="text-[10px] text-slate-400">Impacto de clima o seguridad en productividad</p>
                    </div>

                    <Button
                        onClick={runSimulation}
                        disabled={loading}
                        className="w-full h-14 rounded-2xl bg-slate-900 text-white font-black uppercase tracking-widest hover:bg-slate-800 shadow-xl transition-all active:scale-95"
                    >
                        {loading ? <RefreshCcw className="animate-spin h-5 w-5" /> : "Simular Escenario"}
                    </Button>
                </div>

                {/* Results Visualizer */}
                <div className="lg:col-span-2 p-8 bg-slate-50/50 dark:bg-black/20 flex flex-col justify-center">
                    {!result ? (
                        <div className="text-center py-20 opacity-40">
                            <TrendingUp className="h-20 w-20 mx-auto text-slate-300 mb-4" />
                            <h3 className="text-xl font-bold text-slate-400">Esperando parámetros...</h3>
                            <p className="text-sm">Ajusta las variables para proyectar el futuro</p>
                        </div>
                    ) : (
                        <div className="space-y-8 animate-in fade-in zoom-in duration-500">
                            <div className="grid grid-cols-2 gap-8">
                                {/* Current State */}
                                <div className="space-y-4 opacity-60">
                                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 border-b pb-2">Estado Actual</h4>
                                    <div>
                                        <p className="text-sm text-slate-500">Pendientes (Backlog)</p>
                                        <p className="text-3xl font-black text-slate-700">{result.original.backlog}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-slate-500">SLA Proyectado</p>
                                        <p className="text-3xl font-black text-slate-700">{result.original.sla}%</p>
                                    </div>
                                </div>

                                {/* Simulated State */}
                                <div className="space-y-4">
                                    <h4 className="text-xs font-black uppercase tracking-widest text-indigo-600 border-b border-indigo-200 pb-2">Proyección</h4>
                                    <div>
                                        <p className="text-sm text-slate-500">Nuevos Pendientes</p>
                                        <div className="flex items-end gap-2">
                                            <p className="text-4xl font-black text-indigo-700">{result.simulated.backlog}</p>
                                            <Badge variant={result.simulated.deltaBacklog > 0 ? "destructive" : "default"} className="mb-1 text-[10px]">
                                                {result.simulated.deltaBacklog > 0 ? "+" : ""}{result.simulated.deltaBacklog}
                                            </Badge>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-sm text-slate-500">SLA Resultante</p>
                                        <div className="flex items-end gap-2">
                                            <p className={`text-4xl font-black ${result.simulated.sla < 85 ? "text-red-500" : "text-green-600"}`}>
                                                {result.simulated.sla}%
                                            </p>
                                            <span className="text-xs font-bold text-slate-400 mb-2">
                                                ({result.simulated.deltaSla > 0 ? "+" : ""}{result.simulated.deltaSla.toFixed(1)}%)
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Insight / Recommendation */}
                            <div className={`p-6 rounded-2xl border ${result.simulated.risk === 'HIGH' ? 'bg-red-50 border-red-100' : 'bg-green-50 border-green-100'}`}>
                                <div className="flex items-start gap-4">
                                    <div className={`p-3 rounded-xl ${result.simulated.risk === 'HIGH' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                        <AlertTriangle className="h-6 w-6" />
                                    </div>
                                    <div>
                                        <h5 className={`text-lg font-black uppercase tracking-tight ${result.simulated.risk === 'HIGH' ? 'text-red-700' : 'text-green-700'}`}>
                                            {result.simulated.risk === 'HIGH' ? 'Riesgo Operativo Detectado' : 'Operación Estable'}
                                        </h5>
                                        <p className="text-sm font-medium opacity-80 mt-1">
                                            {result.simulated.risk === 'HIGH'
                                                ? "La proyección indica una caída del SLA por debajo del umbral crítico. Se recomienda aumentar capacidad (+15%) o restringir la demanda."
                                                : "Los parámetros actuales mantienen el cumplimiento de SLA dentro de los márgenes aceptables."}
                                        </p>
                                        {result.simulated.risk === 'HIGH' && (
                                            <Button variant="destructive" size="sm" className="mt-4 rounded-xl font-bold uppercase tracking-widest text-[10px]">
                                                Aplicar Contramedidas
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}
