
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import { Plus, MapPin, User, Phone, FileText, Globe, Landmark, Map as MapIcon } from "lucide-react";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Region, Municipality } from "@/types";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

interface QuickCreateVisitModalProps {
    onVisitCreated: () => void;
}

export function QuickCreateVisitModal({ onVisitCreated }: QuickCreateVisitModalProps) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [regions, setRegions] = useState<Region[]>([]);
    const [municipalities, setMunicipalities] = useState<Municipality[]>([]);
    const [formData, setFormData] = useState({
        fullName: '',
        citizenId: '',
        phone: '',
        addressText: '',
        regionId: '',
        municipalityId: '',
        vereda: '',
    });

    useEffect(() => {
        const fetchRegions = async () => {
            try {
                const response = await fetch(`${API_URL}/territory/regions`);
                if (response.ok) {
                    const data = await response.json();
                    setRegions(data);
                }
            } catch (error) {
                console.error("Error fetching regions:", error);
            }
        };
        fetchRegions();
    }, []);

    useEffect(() => {
        if (!formData.regionId) {
            setMunicipalities([]);
            return;
        }
        const fetchMunicipalities = async () => {
            try {
                const response = await fetch(`${API_URL}/territory/municipalities?regionId=${formData.regionId}`);
                if (response.ok) {
                    const data = await response.json();
                    setMunicipalities(data);
                }
            } catch (error) {
                console.error("Error fetching municipalities:", error);
            }
        };
        fetchMunicipalities();
    }, [formData.regionId]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const payload = {
                ...formData,
                source: 'MANUAL'
            };

            const response = await fetch(`${API_URL}/territory/visits`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (response.ok) {
                toast.success("Visita creada correctamente");
                setOpen(false);
                setFormData({
                    fullName: '',
                    citizenId: '',
                    phone: '',
                    addressText: '',
                    regionId: '',
                    municipalityId: '',
                    vereda: ''
                });
                onVisitCreated();
            } else {
                toast.error("Error al crear visita");
            }
        } catch (error) {
            toast.error("Error de conexión");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all">
                    <Plus className="mr-2 h-5 w-5" /> Agregar Visita Manual
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] rounded-[2rem] border-none bg-white/95 backdrop-blur-xl dark:bg-slate-900/95 p-8">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-black uppercase tracking-tighter text-slate-900 dark:text-white">
                        Nueva Visita <span className="text-blue-600">Manual</span>
                    </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 mt-4">
                    <div className="space-y-2">
                        <Label htmlFor="citizenId" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Cédula</Label>
                        <div className="relative">
                            <FileText className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
                            <Input
                                id="citizenId"
                                placeholder="1234567890"
                                className="pl-12 h-12 rounded-xl bg-slate-50 border-transparent font-bold"
                                value={formData.citizenId}
                                onChange={e => setFormData({ ...formData, citizenId: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="fullName" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Nombre Completo</Label>
                        <div className="relative">
                            <User className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
                            <Input
                                id="fullName"
                                required
                                placeholder="Juan Pérez"
                                className="pl-12 h-12 rounded-xl bg-slate-50 border-transparent font-bold"
                                value={formData.fullName}
                                onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="phone" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Teléfono</Label>
                        <div className="relative">
                            <Phone className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
                            <Input
                                id="phone"
                                placeholder="300 123 4567"
                                className="pl-12 h-12 rounded-xl bg-slate-50 border-transparent font-bold"
                                value={formData.phone}
                                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="region" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Región</Label>
                            <Select
                                value={formData.regionId}
                                onValueChange={val => setFormData({ ...formData, regionId: val, municipalityId: '' })}
                            >
                                <SelectTrigger className="h-12 rounded-xl bg-slate-50 border-transparent font-bold">
                                    <SelectValue placeholder="Seleccionar..." />
                                </SelectTrigger>
                                <SelectContent className="rounded-xl border-slate-100 shadow-2xl">
                                    {regions.map(r => (
                                        <SelectItem key={r.id} value={r.id} className="font-bold">{r.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="municipality" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Municipio</Label>
                            <Select
                                value={formData.municipalityId}
                                onValueChange={val => setFormData({ ...formData, municipalityId: val })}
                                disabled={!formData.regionId}
                            >
                                <SelectTrigger className="h-12 rounded-xl bg-slate-50 border-transparent font-bold">
                                    <SelectValue placeholder="Seleccionar..." />
                                </SelectTrigger>
                                <SelectContent className="rounded-xl border-slate-100 shadow-2xl">
                                    {municipalities.map(m => (
                                        <SelectItem key={m.id} value={m.id} className="font-bold">{m.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="vereda" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Vereda / Sector</Label>
                        <div className="relative">
                            <MapIcon className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
                            <Input
                                id="vereda"
                                placeholder="Ej: Vereda La Esperanza"
                                className="pl-12 h-12 rounded-xl bg-slate-50 border-transparent font-bold"
                                value={formData.vereda}
                                onChange={e => setFormData({ ...formData, vereda: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="address" className="text-xs font-bold uppercase tracking-widest text-slate-500 ml-1">Dirección Física</Label>
                        <div className="relative">
                            <MapPin className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
                            <Input
                                id="address"
                                required
                                placeholder="Calle 10 # 20-30"
                                className="pl-12 h-12 rounded-xl bg-slate-50 border-transparent font-bold"
                                value={formData.addressText}
                                onChange={e => setFormData({ ...formData, addressText: e.target.value })}
                            />
                        </div>
                    </div>

                    <Button type="submit" disabled={loading} className="w-full h-14 text-lg rounded-2xl font-black bg-blue-600 hover:bg-blue-700">
                        {loading ? 'Guardando...' : 'Crear Registro'}
                    </Button>
                </form>
            </DialogContent>
        </Dialog>
    );
}
