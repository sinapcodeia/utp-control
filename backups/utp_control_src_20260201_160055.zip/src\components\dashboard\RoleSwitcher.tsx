
import { Button } from "@/components/ui/button";
import { UserRole } from "@/types";
import { Shield, Users, FileText, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentUser } from "@/hooks/useCurrentUser";

interface RoleSwitcherProps {
    currentRole: UserRole;
    onRoleChange: (role: UserRole) => void;
}

export function RoleSwitcher({ currentRole, onRoleChange }: RoleSwitcherProps) {
    const { user } = useCurrentUser();

    // Bloqueo de seguridad: Solo ADMIN puede ver o usar el simulador
    if (user?.role !== 'ADMIN') return null;

    const roles: { id: UserRole; label: string; icon: any; color: string }[] = [
        { id: 'ADMIN', label: 'Admin', icon: Shield, color: 'text-blue-600 bg-blue-100' },
        { id: 'COORDINATOR', label: 'Coord.', icon: Users, color: 'text-purple-600 bg-purple-100' },
        { id: 'GESTOR', label: 'Gestor', icon: FileText, color: 'text-indigo-600 bg-indigo-100' },
        { id: 'APOYO', label: 'Apoyo', icon: Zap, color: 'text-amber-600 bg-amber-100' },
    ];

    return (
        <div className="fixed bottom-4 right-4 z-50 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 p-2 rounded-2xl shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-10 fade-in duration-500">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 pl-2 mr-2 border-r border-slate-200 pr-2">
                Dev Mode
            </span>
            {roles.map((role) => (
                <button
                    key={role.id}
                    onClick={() => onRoleChange(role.id)}
                    className={cn(
                        "flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-300 border",
                        currentRole === role.id
                            ? "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm"
                            : "hover:bg-slate-50 dark:hover:bg-slate-800/50 border-transparent opacity-60 hover:opacity-100"
                    )}
                >
                    <div className={cn("h-6 w-6 rounded-lg flex items-center justify-center", role.color)}>
                        <role.icon className="h-3.5 w-3.5" />
                    </div>
                    {currentRole === role.id && (
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300 animate-in fade-in zoom-in duration-300">
                            {role.label}
                        </span>
                    )}
                </button>
            ))}
        </div>
    );
}
