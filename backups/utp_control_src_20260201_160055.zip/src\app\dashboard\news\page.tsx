
'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Bell, MapPin, ShieldAlert, Plus, ShieldCheck, Edit3, Trash2, Info, X, MessageSquare, Phone, Mail, FileText } from "lucide-react";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";
import { AlertCircle, ChevronDown } from "lucide-react";
import { Region, Municipality } from "@/types";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

interface NewsItem {
    id: number;
    title: string;
    category: string;
    priority: 'Alta' | 'Media' | 'Baja';
    location: string;
    time: string;
    description: string;
    authorId: string;
    attachmentUrl?: string;
}

interface NewAlertForm {
    title: string;
    category: string;
    priority: 'Alta' | 'Media' | 'Baja';
    region: string;
    departamento: string;
    municipio: string;
    description: string;
    attachmentUrl?: string;
}

interface IncomingMessage {
    from: string;
    to: string;
    content: string;
    time: string;
}

const DIRECTORY_DATA = [
    { id: 'USER-001', name: 'Carlos Pérez', email: 'carlos.perez@utp.gov', phone: '+57 321 456 7890', whatsapp: '573214567890' },
    { id: 'COORD-007', name: 'Ana García', email: 'ana.garcia@utp.gov', phone: '+57 300 111 2233', whatsapp: '573001112233' },
    { id: 'SYSTEM', name: 'Centro de Inteligencia', email: 'soporte@utp.gov', phone: '018000', whatsapp: '018000' }
];

const PRIORITY_SCORES: Record<NewsItem['priority'], number> = {
    'Alta': 100,
    'Media': 50,
    'Baja': 10
};

export default function NewsPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [isMessageOpen, setIsMessageOpen] = useState(false);
    const [incomingMessage, setIncomingMessage] = useState<IncomingMessage | null>(null);
    const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [newsLoading, setNewsLoading] = useState(true);

    const [news, setNews] = useState<NewsItem[]>([]);
    const [regions, setRegions] = useState<Region[]>([]);
    const [municipalities, setMunicipalities] = useState<Municipality[]>([]);
    const [isLoadingTerritories, setIsLoadingTerritories] = useState(false);

    const [newAlert, setNewAlert] = useState<NewAlertForm>({
        title: '',
        category: 'Clima',
        priority: 'Media',
        region: '',
        departamento: '',
        municipio: '',
        description: '',
        attachmentUrl: ''
    });

    const [isManualRegion, setIsManualRegion] = useState(false);
    const [isManualMunicipality, setIsManualMunicipality] = useState(false);

    // Cargar Catálogos Territoriales
    useEffect(() => {
        const fetchTerritories = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const res = await fetch(`${API_URL}/territory/regions`, {
                    headers: { 'Authorization': `Bearer ${session?.access_token}` }
                });
                if (res.ok) {
                    const data = await res.json();
                    setRegions(data);
                }
            } catch (error) {
                console.error("Error fetching regions:", error);
            }
        };

        if (currentUser) {
            fetchTerritories();
        }
    }, [currentUser, supabase.auth]);

    // Cargar Municipios cuando cambie la región
    useEffect(() => {
        const fetchMunicipalities = async () => {
            if (!newAlert.region || newAlert.region === 'NACIONAL') {
                setMunicipalities([]);
                return;
            }

            const selectedRegion = regions.find(r => r.name === newAlert.region || r.id === newAlert.region);
            if (!selectedRegion) return;

            try {
                setIsLoadingTerritories(true);
                const { data: { session } } = await supabase.auth.getSession();
                const res = await fetch(`${API_URL}/territory/municipalities?regionId=${selectedRegion.id}`, {
                    headers: { 'Authorization': `Bearer ${session?.access_token}` }
                });
                if (res.ok) {
                    const data = await res.json();
                    setMunicipalities(data);
                }
            } catch (error) {
                console.error("Error fetching municipalities:", error);
            } finally {
                setIsLoadingTerritories(false);
            }
        };

        fetchMunicipalities();
    }, [newAlert.region, regions]);

    // Pre-poblar formulario al abrir para nuevos reportes
    useEffect(() => {
        if (isDialogOpen && !isEditing && currentUser) {
            setNewAlert(prev => ({
                ...prev,
                region: currentUser.region?.name || '',
                departamento: '', // El esquema no tiene Depto explícito, se usa Región/Municipio
                municipio: currentUser.municipality?.name || '',
            }));
        }
    }, [isDialogOpen, isEditing, currentUser]);

    // Lógica de persistencia y notificaciones
    useEffect(() => {
        const fetchNews = async () => {
            try {
                setNewsLoading(true);
                const { data: { session } } = await supabase.auth.getSession();
                // Filtro Elite: Solo no leídos para este usuario (Modo Inbox)
                const response = await fetch(`${API_URL}/regional-reports?unreadBy=${currentUser?.id}`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });
                if (response.ok) {
                    const data = await response.json();

                    // Normalización de datos del servidor a la interfaz del UI
                    const normalized: NewsItem[] = data.map((item: any) => ({
                        id: item.id,
                        title: item.content.split(': ')[0] || 'Alerta Regional',
                        category: item.category === 'PUBLIC_ORDER' ? 'Orden Público' :
                            item.category.charAt(0) + item.category.slice(1).toLowerCase(),
                        priority: item.priority === 'HIGH' ? 'Alta' :
                            item.priority === 'MEDIUM' ? 'Media' : 'Baja',
                        location: item.locationManualRegion
                            ? `${item.locationManualRegion}${item.locationManualDepartment ? ` - ${item.locationManualDepartment}` : ''}${item.locationManualMunicipality ? `, ${item.locationManualMunicipality}` : ''}`
                            : (item.regionId ? `${item.region?.name || 'Región'}` : 'NACIONAL'),
                        time: new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                        description: item.content.includes(': ') ? item.content.split(': ').slice(1).join(': ') : item.content,
                        authorId: item.userId,
                        attachmentUrl: item.attachmentUrl
                    }));

                    setNews(normalized);
                }
            } catch (error) {
                console.error('Error fetching news:', error);
            } finally {
                setNewsLoading(false);
            }
        };

        if (currentUser) {
            fetchNews();
        }

        // Simulación de "Escucha" de mensajes directos
        const checkMessages = () => {
            if (!currentUser) return;
            const msg = localStorage.getItem('utp_direct_message');
            if (msg) {
                const messageData = JSON.parse(msg);
                if (messageData.to === currentUser.id) {
                    setIncomingMessage(messageData);
                    localStorage.removeItem('utp_direct_message');
                }
            }
        };

        const interval = setInterval(checkMessages, 2000);
        return () => clearInterval(interval);
    }, [currentUser, supabase.auth]);

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    const handleCreateAlert = async () => {
        const priorityMap: Record<string, string> = {
            'Alta': 'HIGH',
            'Media': 'MEDIUM',
            'Baja': 'LOW'
        };

        const categoryMap: Record<string, string> = {
            'Clima': 'CLIMATE',
            'Seguridad': 'SECURITY',
            'Orden Público': 'PUBLIC_ORDER',
            'Salud': 'HEALTH',
            'Infraestructura': 'INFRASTRUCTURE',
            'Otros': 'OTHER'
        };

        const selectedRegion = regions.find(r => r.name === newAlert.region);
        const selectedMunicipality = municipalities.find(m => m.name === newAlert.municipio);
        const isNacional = newAlert.region === 'NACIONAL';

        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/regional-reports`, {
                method: isEditing ? 'PATCH' : 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session?.access_token}`
                },
                body: JSON.stringify({
                    category: categoryMap[newAlert.category] || 'OTHER',
                    priority: priorityMap[newAlert.priority] || 'MEDIUM',
                    content: newAlert.description,
                    title: newAlert.title,
                    attachmentUrl: newAlert.attachmentUrl,
                    regionId: isNacional ? null : (selectedRegion?.id || null),
                    municipalityId: isNacional ? null : (selectedMunicipality?.id || null),
                    locationManualRegion: newAlert.region || (currentUser.role !== 'ADMIN' ? currentUser.region?.name : 'NACIONAL'),
                    locationManualDepartment: newAlert.departamento,
                    locationManualMunicipality: newAlert.municipio,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Error al publicar');
            }

            const item = await response.json();

            // Normalización inmediata para el estado local
            const newItem: NewsItem = {
                id: item.id,
                title: item.title || item.content.split(': ')[0] || 'Alerta',
                category: item.category === 'PUBLIC_ORDER' ? 'Orden Público' :
                    item.category.charAt(0) + item.category.slice(1).toLowerCase(),
                priority: item.priority === 'HIGH' ? 'Alta' :
                    item.priority === 'MEDIUM' ? 'Media' : 'Baja',
                location: item.locationManualRegion
                    ? `${item.locationManualRegion}${item.locationManualDepartment ? ` - ${item.locationManualDepartment}` : ''}${item.locationManualMunicipality ? `, ${item.locationManualMunicipality}` : ''}`
                    : (item.regionId ? `${item.region?.name || 'Región'}` : 'NACIONAL'),
                time: new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                description: item.content.includes(': ') ? item.content.split(': ').slice(1).join(': ') : item.content,
                authorId: item.userId,
                attachmentUrl: item.attachmentUrl
            };

            if (isEditing) {
                setNews(prev => prev.map(n => n.id === item.id ? newItem : n));
            } else {
                setNews(prev => [newItem, ...prev]);
            }
            toast.success("Alerta oficial publicada y sincronizada");
        } catch (error) {
            toast.error("Error al sincronizar con el servidor");
            console.error(error);
        }

        resetForm();
    };

    const handleMarkAsRead = async (reportId: string | number) => {
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/regional-reports/${reportId}/read`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${session?.access_token}`
                }
            });

            if (response.ok) {
                // Remove from local state
                setNews(prev => prev.filter(n => n.id !== reportId));
                setIsViewOpen(false);
                toast.success("Recibo confirmado. La alerta se ha archivado en la Bóveda.");
            }
        } catch (error) {
            console.error('Error marking as read:', error);
            toast.error("Error al confirmar el recibo");
        }
    };

    const resetForm = () => {
        setIsDialogOpen(false);
        setIsEditing(false);
        setSelectedNews(null);
        setNewAlert({
            title: '',
            category: 'Clima',
            priority: 'Media',
            region: currentUser?.region?.name || '',
            departamento: '',
            municipio: currentUser?.municipality?.name || '',
            description: '',
            attachmentUrl: ''
        });
    };

    const handleDeleteAlert = async (id: number | string) => {
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/regional-reports/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${session?.access_token}`
                }
            });

            if (response.ok) {
                setNews(prev => prev.filter(n => n.id !== id));
                toast.error("Alerta eliminada del servidor");
            }
        } catch (error) {
            toast.error("Error al eliminar del servidor");
        }
    };

    const startEditing = (item: NewsItem) => {
        setSelectedNews(item);
        setIsEditing(true);
        const [region, deptoMun] = item.location.split(' - ');
        const [depto, mun] = deptoMun ? deptoMun.split(', ') : ['', ''];

        setNewAlert({
            title: item.title,
            category: item.category,
            priority: item.priority,
            region: region || '',
            departamento: depto || '',
            municipio: mun || '',
            description: item.description,
            attachmentUrl: item.attachmentUrl
        });
        setIsDialogOpen(true);
    };

    const handleAction = (type: string, value: string) => {
        if (type === 'whatsapp') {
            window.open(`https://wa.me/${value}`, '_blank');
        } else if (type === 'call') {
            window.location.href = `tel:${value}`;
        } else if (type === 'email') {
            window.location.href = `mailto:${value}`;
        }
        toast.info(`Iniciando ${type}...`);
    };

    const sendDirectMessage = (authorId: string) => {
        if (authorId === currentUser.id) {
            toast.error("No puedes enviarte un mensaje a ti mismo.");
            return;
        }
        const message = {
            from: currentUser.full_name,
            to: authorId,
            content: "Informe recibido. Procedemos a verificar según protocolo.",
            time: new Date().toLocaleTimeString()
        };
        localStorage.setItem('utp_direct_message', JSON.stringify(message));
        toast.success("Mensaje Directo enviado al Home del autor", {
            description: "Aparecerá un Pop-Up en su pantalla de inmediato."
        });
    };

    const getScore = (item: NewsItem) => {
        let score = PRIORITY_SCORES[item.priority] || 0;
        // Estrategia de Silicon Valley: Priorización hiperlocal
        if (currentUser.region?.name && item.location.toLowerCase().includes(currentUser.region.name.toLowerCase())) {
            score += 1000;
        }
        return score;
    };

    const sortedNews = [...news].sort((a, b) => {
        return getScore(b) - getScore(a);
    });

    const urgentCount = sortedNews.filter(n => n.priority === 'Alta' && (currentUser.region?.name ? n.location.includes(currentUser.region.name) : false)).length;

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20" suppressHydrationWarning>
            {/* Resumen del Tablero Operacional */}
            {currentUser.role === 'COORDINATOR' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                    <div className="bg-blue-600 rounded-[2.5rem] p-8 text-white shadow-2xl shadow-blue-500/30 overflow-hidden relative">
                        <div className="absolute -right-6 -bottom-6 opacity-10">
                            <ShieldAlert className="h-40 w-40" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-2 opacity-80">Estado Operacional</p>
                        <h3 className="text-4xl font-black tracking-tighter mb-4">ACTIVO</h3>
                        <div className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-2xl w-fit backdrop-blur-md">
                            <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
                            <span className="text-[10px] font-bold uppercase tracking-widest">{urgentCount} Urgencias en {currentUser.region?.name || 'Nacional'}</span>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-white dark:border-slate-800 shadow-xl flex flex-col justify-center">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-1">Total Novedades</p>
                        <div className="flex items-end gap-3">
                            <h3 className="text-5xl font-black text-slate-900 dark:text-white leading-none">{news.length}</h3>
                            <span className="text-blue-600 font-bold text-sm mb-1">Últimas 24h</span>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-white dark:border-slate-800 shadow-xl flex flex-col justify-center overflow-hidden relative">
                        <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-1 opacity-5">
                            <MapPin className="h-20 w-20" />
                        </div>
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-1">Jurisdicción</p>
                        <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">{currentUser.region?.name || 'Nacional'}</h3>
                        <p className="text-xs text-blue-600 font-bold mt-1">Cobertura en tiempo real</p>
                    </div>
                </div>
            )}

            {/* POPUP DE NOTIFICACIÓN DE MENSAJE (ESTILO SILICON VALLEY) */}
            {incomingMessage && (
                <div className="fixed top-24 right-8 z-[100] animate-in slide-in-from-right duration-500 max-w-sm">
                    <div className="bg-white dark:bg-slate-900 border-none rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] p-8 ring-4 ring-blue-600/10 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-6 opacity-5">
                            <MessageSquare className="h-20 w-20 text-blue-600" />
                        </div>
                        <div className="flex items-center gap-4 mb-4">
                            <div className="h-12 w-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white">
                                <Bell className="h-6 w-6 animate-bounce" />
                            </div>
                            <div>
                                <h4 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tighter">Mensaje de {incomingMessage.from}</h4>
                                <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">{incomingMessage.time}</p>
                            </div>
                            <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setIncomingMessage(null)}
                                className="ml-auto h-8 w-8 rounded-full hover:bg-slate-100"
                            >
                                <X className="h-4 w-4" />
                            </Button>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 mb-6 border border-slate-100 dark:border-slate-800">
                            <p className="text-sm font-medium text-slate-600 dark:text-slate-300 italic">"{incomingMessage.content}"</p>
                        </div>
                        <Button
                            className="w-full h-12 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-[9px] shadow-lg shadow-blue-500/20"
                            onClick={() => setIncomingMessage(null)}
                        >
                            Acusar Recibo
                        </Button>
                    </div>
                </div>
            )}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-3xl font-black tracking-tighter text-slate-900 dark:text-slate-50 uppercase">
                        Feed <span className="text-blue-600">Inteligente</span>
                    </h2>
                    <p className="text-sm font-medium text-slate-500/80">
                        {currentUser.role === 'COORDINATOR'
                            ? `Resumen operacional para la ${currentUser.region?.name || 'Región'}.`
                            : 'Monitoreo en tiempo real de incidentes regionales.'}
                    </p>
                </div>

                <div className="flex gap-4">
                    <Link href="/dashboard/news/archive">
                        <Button variant="outline" className="rounded-2xl border-blue-200 bg-blue-50/30 text-blue-700 font-black uppercase text-[10px] tracking-widest hover:bg-blue-100 h-12 px-8">
                            Ver Historial Regional (Bóveda)
                        </Button>
                    </Link>
                </div>

                <Dialog open={isDialogOpen} onOpenChange={(open) => {
                    if (!open) resetForm();
                    setIsDialogOpen(open);
                }}>
                    <DialogTrigger asChild>
                        <Button className="gap-2 bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 rounded-xl h-12 px-6 font-black uppercase tracking-widest text-[10px]">
                            <Plus className="h-4 w-4" />
                            Nueva Alerta
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[520px] rounded-[2.5rem] border-none bg-white dark:bg-slate-950 p-0 overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] animate-slide-in">
                        <div className="relative">
                            <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-blue-600/5 to-transparent pointer-events-none" />

                            <DialogHeader className="p-10 text-center space-y-3">
                                <div className="mx-auto h-16 w-16 rounded-[2rem] bg-blue-600/10 flex items-center justify-center mb-2 shadow-inner">
                                    <ShieldAlert className="h-8 w-8 text-blue-600" />
                                </div>
                                <DialogTitle className="text-3xl font-black tracking-tighter uppercase text-slate-900 dark:text-slate-50 leading-tight">
                                    {isEditing ? 'Corregir' : 'Reportar'} <span className="text-blue-600">Novedad</span>
                                </DialogTitle>
                                <DialogDescription className="text-sm font-semibold text-slate-500 max-w-[320px] mx-auto leading-relaxed">
                                    {isEditing ? 'Actualiza los datos del incidente para mantener la precisión operativa.' : 'Informa sobre un incidente o evento relevante para activar los protocolos regionales.'}
                                </DialogDescription>
                            </DialogHeader>

                            <div className="px-10 pb-10 space-y-7">
                                <div className="space-y-3">
                                    <Label htmlFor="title" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                        Título del Incidente
                                    </Label>
                                    <Input
                                        id="title"
                                        value={newAlert.title}
                                        onChange={(e) => setNewAlert({ ...newAlert, title: e.target.value })}
                                        className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold px-5 placeholder:text-slate-300 dark:bg-slate-900 dark:border-slate-800"
                                        placeholder="Ej: Accidente de tránsito masivo..."
                                    />
                                </div>

                                <div className="grid grid-cols-2 gap-5">
                                    <div className="space-y-3">
                                        <Label htmlFor="category" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                            Categoría
                                        </Label>
                                        <Select onValueChange={(val) => setNewAlert({ ...newAlert, category: val })} value={newAlert.category}>
                                            <SelectTrigger className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold px-5 dark:bg-slate-900 dark:border-slate-800">
                                                <SelectValue placeholder="Categoría" />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl p-2">
                                                <SelectItem value="Clima" className="rounded-xl py-3 font-bold">Clima</SelectItem>
                                                <SelectItem value="Orden Público" className="rounded-xl py-3 font-bold">Orden Público</SelectItem>
                                                <SelectItem value="Salud" className="rounded-xl py-3 font-bold">Salud</SelectItem>
                                                <SelectItem value="Infraestructura" className="rounded-xl py-3 font-bold">Infraestructura</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="space-y-3">
                                        <Label htmlFor="priority" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                            Prioridad
                                        </Label>
                                        <Select onValueChange={(val: 'Alta' | 'Media' | 'Baja') => setNewAlert({ ...newAlert, priority: val })} value={newAlert.priority}>
                                            <SelectTrigger className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold px-5 dark:bg-slate-900 dark:border-slate-800">
                                                <SelectValue placeholder="Prioridad" />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl p-2">
                                                <SelectItem value="Baja" className="rounded-xl py-3 font-bold text-blue-600">Baja</SelectItem>
                                                <SelectItem value="Media" className="rounded-xl py-3 font-bold text-amber-600">Media</SelectItem>
                                                <SelectItem value="Alta" className="rounded-xl py-3 font-bold text-red-600">Alta</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-5">
                                    <div className="space-y-3">
                                        <Label className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                            Región / Jurisdicción
                                        </Label>
                                        <Select
                                            onValueChange={(val) => {
                                                if (val === 'MANUAL') {
                                                    setIsManualRegion(true);
                                                    setNewAlert({ ...newAlert, region: '', municipio: '' });
                                                } else {
                                                    setIsManualRegion(false);
                                                    setNewAlert({ ...newAlert, region: val, municipio: '' });
                                                }
                                            }}
                                            value={isManualRegion ? 'MANUAL' : newAlert.region}
                                        >
                                            <SelectTrigger className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold px-5 dark:bg-slate-900 dark:border-slate-800">
                                                <SelectValue placeholder="Seleccionar Región" />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl p-2">
                                                <SelectItem value="NACIONAL" className="rounded-xl py-3 font-bold border-b border-slate-100">COBERTURA NACIONAL</SelectItem>
                                                {regions.map(r => (
                                                    <SelectItem key={r.id} value={r.name} className="rounded-xl py-3 font-bold">
                                                        {r.name}
                                                    </SelectItem>
                                                ))}
                                                <SelectItem value="MANUAL" className="rounded-xl py-3 font-bold text-blue-600 border-t border-slate-100">OTRO (ESCRIBIR MANUAL)</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        {isManualRegion && (
                                            <Input
                                                placeholder="Nombre de la Región..."
                                                value={newAlert.region}
                                                onChange={(e) => setNewAlert({ ...newAlert, region: e.target.value })}
                                                className="mt-2 h-12 rounded-xl border-blue-200 bg-blue-50/10"
                                            />
                                        )}
                                    </div>

                                    <div className="space-y-3">
                                        <Label className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                            Municipio {isLoadingTerritories && "..."}
                                        </Label>
                                        <Select
                                            onValueChange={(val) => {
                                                if (val === 'MANUAL') {
                                                    setIsManualMunicipality(true);
                                                    setNewAlert({ ...newAlert, municipio: '' });
                                                } else {
                                                    setIsManualMunicipality(false);
                                                    setNewAlert({ ...newAlert, municipio: val });
                                                }
                                            }}
                                            value={isManualMunicipality ? 'MANUAL' : newAlert.municipio}
                                            disabled={(!newAlert.region && !isManualRegion) || newAlert.region === 'NACIONAL'}
                                        >
                                            <SelectTrigger className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold px-5 dark:bg-slate-900 dark:border-slate-800">
                                                <SelectValue placeholder={municipalities.length > 0 || isManualRegion ? "Seleccionar Municipio" : "N/A"} />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl p-2">
                                                {municipalities.map(m => (
                                                    <SelectItem key={m.id} value={m.name} className="rounded-xl py-3 font-bold">
                                                        {m.name}
                                                    </SelectItem>
                                                ))}
                                                <SelectItem value="MANUAL" className="rounded-xl py-3 font-bold text-blue-600 border-t border-slate-100">OTRO (ESCRIBIR MANUAL)</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        {isManualMunicipality && (
                                            <Input
                                                placeholder="Nombre del Municipio..."
                                                value={newAlert.municipio}
                                                onChange={(e) => setNewAlert({ ...newAlert, municipio: e.target.value })}
                                                className="mt-2 h-12 rounded-xl border-blue-200 bg-blue-50/10"
                                            />
                                        )}
                                    </div>
                                </div>

                                {/* Campo de Departamento (Manual para mayor precisión si se requiere) */}
                                <div className="space-y-3">
                                    <Label htmlFor="departamento" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                        Departamento / Zona Específica (Opcional)
                                    </Label>
                                    <Input
                                        id="departamento"
                                        placeholder="Ej: Noroccidente, Sector Industrial..."
                                        value={newAlert.departamento}
                                        onChange={(e) => setNewAlert({ ...newAlert, departamento: e.target.value })}
                                        className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold px-5 placeholder:text-slate-300 dark:bg-slate-900 dark:border-slate-800"
                                    />
                                </div>

                                <div className="space-y-3">
                                    <Label htmlFor="description" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                        Detalle de los Hechos
                                    </Label>
                                    <Textarea
                                        id="description"
                                        value={newAlert.description}
                                        onChange={(e) => setNewAlert({ ...newAlert, description: e.target.value })}
                                        className="min-h-[120px] rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold p-5 placeholder:text-slate-300 dark:bg-slate-900 dark:border-slate-800 resize-none"
                                        placeholder="Describe la situación con la mayor precisión posible..."
                                    />
                                </div>

                                <div className="space-y-3">
                                    <Label htmlFor="attachmentUrl" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                        URL del Documento Anexo (Opcional)
                                    </Label>
                                    <div className="relative">
                                        <Input
                                            id="attachmentUrl"
                                            value={newAlert.attachmentUrl || ''}
                                            onChange={(e) => setNewAlert({ ...newAlert, attachmentUrl: e.target.value })}
                                            className="h-14 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-bold pl-12 dark:bg-slate-900 dark:border-slate-800"
                                            placeholder="https://ejemplo.com/documento.pdf"
                                        />
                                        <FileText className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                                    </div>
                                </div>

                                <DialogFooter className="pt-4 sm:flex-col gap-4">
                                    <Button
                                        type="submit"
                                        onClick={handleCreateAlert}
                                        className="w-full h-16 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs shadow-[0_12px_24px_-8px_rgba(37,99,235,0.4)] transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-3"
                                    >
                                        <ShieldAlert className="h-4 w-4" />
                                        {isEditing ? 'Guardar Cambios' : 'Publicar Alerta Oficial'}
                                    </Button>
                                    <Button
                                        variant="ghost"
                                        onClick={resetForm}
                                        className="w-full h-10 rounded-xl text-xs font-bold text-slate-400 hover:text-slate-600 uppercase tracking-widest"
                                    >
                                        Cancelar
                                    </Button>
                                </DialogFooter>
                            </div>
                        </div>
                    </DialogContent>
                </Dialog>

                {/* Diálogo de Ver Detalles */}
                <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
                    <DialogContent className="sm:max-w-[600px] rounded-[3rem] border-none bg-slate-50 dark:bg-slate-950 p-0 overflow-hidden shadow-2xl">
                        {selectedNews && (
                            <div className="relative">
                                <div className={`h-24 w-full bg-gradient-to-r ${selectedNews.priority === 'Alta' ? 'from-red-600 to-red-400' :
                                    selectedNews.priority === 'Media' ? 'from-amber-500 to-amber-300' :
                                        'from-blue-600 to-blue-400'
                                    } flex items-end p-8`}>
                                    <Badge className="bg-white/20 backdrop-blur-md text-white border-none font-black uppercase tracking-widest text-[10px]">
                                        {selectedNews.category}
                                    </Badge>
                                </div>
                                <div className="p-10 -mt-6 rounded-t-[3rem] bg-slate-50 dark:bg-slate-950 relative z-10 space-y-8">
                                    <div className="space-y-4">
                                        <h2 className="text-4xl font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-none">
                                            {selectedNews.title}
                                        </h2>
                                        <div className="flex items-center gap-4 text-slate-400 font-bold text-xs uppercase tracking-widest">
                                            <div className="flex items-center gap-2">
                                                <MapPin className="h-4 w-4 text-blue-500" />
                                                {selectedNews.location}
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Bell className="h-4 w-4" />
                                                {selectedNews.time}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="space-y-3">
                                        <Label className="text-[10px] font-black uppercase tracking-widest text-blue-600">Descripción Detallada</Label>
                                        <div className="p-8 rounded-[2rem] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm">
                                            <p className="text-base text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                                                {selectedNews.description}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="flex items-center justify-between pt-4 gap-4">
                                        <div className="flex items-center gap-3">
                                            <div className="h-10 w-10 rounded-full bg-slate-200 flex items-center justify-center">
                                                <ShieldCheck className="h-5 w-5 text-slate-400" />
                                            </div>
                                            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                                ID Reporte: {selectedNews.id}
                                            </div>
                                        </div>
                                        <div className="flex gap-2">
                                            <Button
                                                variant="outline"
                                                onClick={() => setIsViewOpen(false)}
                                                className="h-14 px-6 rounded-2xl border-slate-200 text-slate-500 font-black uppercase tracking-widest text-[10px]"
                                            >
                                                Cerrar
                                            </Button>
                                            <Button
                                                onClick={() => handleMarkAsRead(selectedNews.id)}
                                                className="h-14 px-10 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-[10px] shadow-xl shadow-blue-500/20"
                                            >
                                                Acusar Recibo y Archivar
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </DialogContent>
                </Dialog>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 relative z-10">
                {newsLoading ? (
                    // Loading skeletons
                    Array.from({ length: 6 }).map((_, i) => (
                        <Card key={i} className="rounded-[2rem] border-none bg-white dark:bg-slate-900 overflow-hidden">
                            <CardHeader className="pb-2 px-8 pt-8">
                                <div className="flex justify-between items-start mb-2">
                                    <div className="h-6 w-24 bg-slate-200 dark:bg-slate-700 rounded-lg animate-pulse" />
                                    <div className="h-4 w-16 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
                                </div>
                                <div className="h-6 w-3/4 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
                            </CardHeader>
                            <CardContent className="px-8 pb-8 pt-2">
                                <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 rounded-full mb-4 animate-pulse" />
                                <div className="space-y-2">
                                    <div className="h-4 w-full bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
                                    <div className="h-4 w-5/6 bg-slate-200 dark:bg-slate-700 rounded animate-pulse" />
                                </div>
                                <div className="mt-4 h-12 bg-slate-200 dark:bg-slate-700 rounded-2xl animate-pulse" />
                            </CardContent>
                        </Card>
                    ))
                ) : sortedNews.length === 0 ? (
                    // Empty state
                    <div className="col-span-full flex flex-col items-center justify-center py-20 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md rounded-[4rem] border border-dashed border-slate-200 dark:border-slate-800">
                        <ShieldAlert className="h-20 w-20 text-slate-200 dark:text-slate-700 mb-6" />
                        <h3 className="text-2xl font-black text-slate-400 uppercase tracking-tighter">Sin novedades pendientes</h3>
                        <p className="text-slate-400 font-medium mt-2">Todas las alertas han sido revisadas.</p>
                    </div>
                ) : sortedNews.map((item) => (
                    <Card key={item.id} className={`group relative overflow-hidden rounded-[2rem] border-none bg-white transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl dark:bg-slate-900 ${item.priority === 'Alta' ? 'shadow-red-500/10' : item.priority === 'Media' ? 'shadow-amber-500/10' : 'shadow-blue-500/10'
                        } ${(currentUser.region?.name && item.location.includes(currentUser.region.name)) ? ' ring-2 ring-blue-600/20' : ''}`}>

                        {/* Status indicators */}
                        {(currentUser.region?.name && item.location.includes(currentUser.region.name)) && (
                            <div className="absolute top-4 right-8 z-20">
                                <Badge className="bg-blue-600 text-white border-none rounded-lg px-2 py-0.5 text-[8px] font-black tracking-widest uppercase shadow-lg shadow-blue-500/40">
                                    Tu Jurisdicción
                                </Badge>
                            </div>
                        )}
                        {/* Borde de prioridad lateral */}
                        <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${item.priority === 'Alta' ? 'bg-red-500 animate-pulse' :
                            item.priority === 'Media' ? 'bg-amber-500' :
                                'bg-blue-500'
                            }`} />

                        <CardHeader className="pb-2 px-8 pt-8">
                            <div className="flex justify-between items-start mb-2">
                                <Badge variant="outline" className={`rounded-lg px-2 py-0.5 text-[10px] font-black uppercase tracking-widest ${item.priority === 'Alta' ? 'border-red-100 bg-red-50 text-red-600' :
                                    item.priority === 'Media' ? 'border-amber-100 bg-amber-50 text-amber-600' :
                                        'border-blue-100 bg-blue-50 text-blue-600'
                                    } translate-x-[-4px]`}>
                                    {item.category}
                                </Badge>

                                <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                                    <Bell className="h-3 w-3" />
                                    {item.time}
                                </div>
                            </div>

                            <CardTitle className="text-xl font-black tracking-tight text-slate-900 group-hover:text-blue-600 transition-colors dark:text-white leading-tight">
                                {item.title}
                            </CardTitle>
                        </CardHeader>

                        <CardContent className="px-8 pb-8 pt-2">
                            <div className="flex items-center gap-2 text-[11px] font-bold text-slate-500 mb-4 bg-slate-50 dark:bg-slate-800/50 w-fit px-3 py-1 rounded-full">
                                <MapPin className="h-3.5 w-3.5 text-blue-500" />
                                <span className="truncate max-w-[200px]">{item.location}</span>
                            </div>

                            <p className="text-sm text-slate-500 font-medium leading-relaxed dark:text-slate-400">
                                {item.description}
                            </p>

                            {/* Barra de Comunicación */}
                            <div className="mt-4 flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100/50 dark:border-slate-800">
                                {(() => {
                                    const author = DIRECTORY_DATA.find(u => u.id === item.authorId) || DIRECTORY_DATA[2];
                                    return (
                                        <>
                                            <Button
                                                variant="ghost" size="icon" className="h-10 w-10 rounded-xl text-green-500 hover:bg-green-50"
                                                onClick={() => handleAction('whatsapp', author.whatsapp)}
                                            >
                                                <MessageSquare className="h-4 w-4" />
                                            </Button>
                                            <Button
                                                variant="ghost" size="icon" className="h-10 w-10 rounded-xl text-blue-600 hover:bg-blue-50"
                                                onClick={() => handleAction('call', author.phone)}
                                            >
                                                <Phone className="h-4 w-4" />
                                            </Button>
                                            <Button
                                                variant="ghost" size="icon" className="h-10 w-10 rounded-xl text-slate-400 hover:text-blue-600"
                                                onClick={() => handleAction('email', author.email)}
                                            >
                                                <Mail className="h-4 w-4" />
                                            </Button>
                                            <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-1" />
                                            <Button
                                                variant="ghost" className="flex-1 h-10 rounded-xl text-[9px] font-black uppercase tracking-widest text-blue-600 hover:bg-blue-600 hover:text-white transition-all gap-2"
                                                onClick={() => sendDirectMessage(item.authorId)}
                                            >
                                                <Bell className="h-3 w-3" />
                                                Alerta Directa
                                            </Button>
                                        </>
                                    );
                                })()}
                            </div>

                            <div className="mt-6 pt-6 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center">
                                <div className="flex gap-2">
                                    {(item.authorId === currentUser.id || currentUser.role === 'ADMIN') && (
                                        <>
                                            <Button
                                                onClick={() => startEditing(item)}
                                                variant="ghost"
                                                size="icon"
                                                className="h-10 w-10 rounded-xl text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-all"
                                            >
                                                <Edit3 className="h-4 w-4" />
                                            </Button>
                                            <Button
                                                onClick={() => handleDeleteAlert(item.id)}
                                                variant="ghost"
                                                size="icon"
                                                className="h-10 w-10 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-all"
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </>
                                    )}
                                </div>
                                <Button
                                    onClick={() => {
                                        setSelectedNews(item);
                                        setIsViewOpen(true);
                                    }}
                                    variant="ghost"
                                    className="h-10 px-5 rounded-xl text-[10px] font-black uppercase tracking-widest text-blue-600 hover:text-blue-700 hover:bg-blue-50 flex items-center gap-2 group/btn"
                                >
                                    Ver Detalles
                                    <Info className="h-3 w-3 group-hover/btn:scale-110 transition-transform" />
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div >
    );
}

