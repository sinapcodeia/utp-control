'use client';

import { useMemo } from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, MapPin, Activity } from "lucide-react";

interface Coordinate {
    id: string;
    latitude: number;
    longitude: number;
    priority: 'LOW' | 'MEDIUM' | 'HIGH';
}

interface CoverageMapProps {
    coordinates: Coordinate[];
}

export function CoverageMap({ coordinates }: CoverageMapProps) {
    // Definimos los límites aproximados de Antioquia (o la zona de interés)
    // Para el demo/estilo, normalizaremos las coordenadas a un canvas de 100x100
    const bounds = useMemo(() => {
        if (coordinates.length === 0) return { minLat: 5, maxLat: 8, minLng: -76, maxLng: -74 };

        return {
            minLat: Math.min(...coordinates.map(c => c.latitude)) - 0.2,
            maxLat: Math.max(...coordinates.map(c => c.latitude)) + 0.2,
            minLng: Math.min(...coordinates.map(c => c.longitude)) - 0.2,
            maxLng: Math.max(...coordinates.map(c => c.longitude)) + 0.2,
        };
    }, [coordinates]);

    const normalize = (lat: number, lng: number) => {
        const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
        const y = 100 - (((lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * 100);
        return { x, y };
    };

    return (
        <Card className="rounded-[2.5rem] border-none bg-slate-900 shadow-2xl overflow-hidden relative group min-h-[400px]">
            {/* Background Grid Style */}
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:20px_20px]" />

            {/* Header Overlay */}
            <div className="absolute top-6 left-6 z-10 flex flex-col gap-2">
                <Badge className="bg-blue-600/20 text-blue-400 border-none px-3 py-1 text-[10px] font-black uppercase tracking-widest backdrop-blur-md">
                    Control Territorial Activo
                </Badge>
                <h3 className="text-xl font-black text-white uppercase tracking-tighter">
                    Mapa de <span className="text-blue-500">Calor Operativo</span>
                </h3>
            </div>

            {/* Live Stats Overlay */}
            <div className="absolute top-6 right-6 z-10 flex gap-3">
                <div className="bg-black/40 backdrop-blur-xl p-3 rounded-2xl border border-white/10 flex items-center gap-3">
                    <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                    <div className="text-left">
                        <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Sincronización</p>
                        <p className="text-xs font-bold text-white uppercase">Tiempo Real</p>
                    </div>
                </div>
            </div>

            {/* Legend Overlay */}
            <div className="absolute bottom-6 left-6 z-10 space-y-2 bg-black/40 backdrop-blur-xl p-4 rounded-3xl border border-white/10">
                <div className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                    <span className="text-[9px] font-black text-white/60 uppercase tracking-widest">Alerta Crítica</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
                    <span className="text-[9px] font-black text-white/60 uppercase tracking-widest">Visita Ejecutada</span>
                </div>
            </div>

            {/* Map Canvas / Visualization */}
            <div className="relative w-full h-full flex items-center justify-center p-12">
                <svg viewBox="0 0 100 100" className="w-full h-full max-h-[350px] drop-shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                    <defs>
                        <filter id="heatMapBlur" x="-50%" y="-50%" width="200%" height="200%">
                            <feGaussianBlur in="SourceGraphic" stdDeviation="2.5" />
                        </filter>
                    </defs>

                    {/* Simplified Territorial Shape (Stylized) */}
                    <path
                        d="M30,20 Q50,10 70,20 T90,50 T70,80 T30,90 T10,60 T30,20"
                        fill="none"
                        stroke="rgba(59,130,246,0.1)"
                        strokeWidth="0.5"
                        strokeDasharray="2 2"
                    />

                    {/* Heatmap Layer */}
                    <g filter="url(#heatMapBlur)" className="opacity-40">
                        {coordinates.map((coord, i) => {
                            const { x, y } = normalize(coord.latitude, coord.longitude);
                            return (
                                <circle key={`heat-${i}`} cx={x} cy={y} r="6" fill={coord.priority === 'HIGH' ? '#ef4444' : '#3b82f6'} />
                            );
                        })}
                    </g>

                    {/* Nodes (Visits) */}
                    {coordinates.length === 0 ? (
                        <g>
                            {/* Decorative Placeholder dots if no data */}
                            {[...Array(50)].map((_, i) => (
                                <circle
                                    key={i}
                                    cx={20 + Math.random() * 60}
                                    cy={20 + Math.random() * 60}
                                    r="0.2"
                                    fill="rgba(59,130,246,0.3)"
                                />
                            ))}
                            <text x="50" y="55" textAnchor="middle" className="text-[3px] font-black fill-white/20 uppercase tracking-[0.3em]">
                                SCANNING FOR ACTIVE NODES...
                            </text>
                        </g>
                    ) : (
                        <g>
                            {coordinates.map((coord, i) => {
                                const { x, y } = normalize(coord.latitude, coord.longitude);
                                const isHigh = coord.priority === 'HIGH';

                                return (
                                    <g key={coord.id} className="cursor-pointer group/node">
                                        {/* Glow Effect */}
                                        <circle
                                            cx={x}
                                            cy={y}
                                            r={isHigh ? "2" : "1.5"}
                                            className={`${isHigh ? 'fill-red-500/20' : 'fill-blue-500/20'} animate-pulse`}
                                        />

                                        {/* Main Node */}
                                        <circle
                                            cx={x}
                                            cy={y}
                                            r={isHigh ? "1.2" : "0.8"}
                                            className={`${isHigh ? 'fill-red-500' : 'fill-blue-400'} transition-all duration-300 group-hover/node:r-[1.5] group-hover/node:fill-white`}
                                        />

                                        {/* Tooltip (Simulated with Title) */}
                                        <title>
                                            Punto ID: {coord.id.slice(0, 8)}\n
                                            Coordenadas: {coord.latitude.toFixed(4)}, {coord.longitude.toFixed(4)}\n
                                            Prioridad: {coord.priority}
                                        </title>
                                    </g>
                                );
                            })}
                        </g>
                    )}

                    {/* Simulation of routes / active coverage area */}
                    {coordinates.length > 2 && (
                        <path
                            d={`M ${coordinates.slice(0, 3).map(c => {
                                const { x, y } = normalize(c.latitude, c.longitude);
                                return `${x},${y}`;
                            }).join(' L ')} Z`}
                            fill="rgba(59,130,246,0.05)"
                            stroke="rgba(59,130,246,0.2)"
                            strokeWidth="0.1"
                            strokeDasharray="1 1"
                            className="animate-in fade-in duration-1000"
                        />
                    )}
                </svg>
            </div>

            {/* Footer Interactive */}
            <div className="absolute bottom-6 right-6 z-10">
                <button className="flex items-center gap-2 bg-white text-slate-900 px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all">
                    <Activity className="h-3 w-3" /> Ampliar Radar
                </button>
            </div>
        </Card>
    );
}
