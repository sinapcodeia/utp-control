'use client';

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle2, XCircle, AlertTriangle, Camera, FileText, PenTool, ChevronLeft } from "lucide-react";
import { toast } from "sonner";

interface VisitWizardProps {
    visit: any;
    onComplete: (data: any) => void;
    onCancel: () => void;
}

type Step = 'PRE_VISIT' | 'VISIT_STATUS' | 'UNIT_STATUS' | 'COMPLIANCE' | 'ALERTS' | 'EVIDENCE' | 'CLOSING';

export function VisitWizard({ visit, onComplete, onCancel }: VisitWizardProps) {
    const [step, setStep] = useState<Step>('PRE_VISIT');
    const [data, setData] = useState({
        status: '',
        unitStatus: '',
        compliance: '',
        alertType: 'NONE',
        alertObs: '',
        evidence: [] as string[]
    });
    const [syncState, setSyncState] = useState<'IDLE' | 'SYNCING' | 'SYNCED' | 'OFFLINE'>('IDLE');

    const updateData = (key: string, value: any) => {
        setData(prev => ({ ...prev, [key]: value }));
    };

    // 4. Unidad Productiva – Pre‑Visita
    if (step === 'PRE_VISIT') {
        return (
            <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 p-6">
                <Button variant="ghost" onClick={onCancel} className="self-start -ml-2 mb-8 text-slate-400">
                    <ChevronLeft className="mr-1 h-5 w-5" /> Volver
                </Button>

                <div className="space-y-8">
                    <h1 className="text-4xl font-black text-slate-900 dark:text-white leading-tight">
                        {visit.fullName}
                    </h1>

                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <span className="text-2xl">📍</span>
                            <span className="text-xl font-bold text-slate-600 dark:text-slate-300">
                                {visit.municipality?.name || visit.area || 'Municipio – Jurisdicción'}
                            </span>
                        </div>
                        {visit.scheduledAt && (
                            <div className="flex items-center gap-3">
                                <span className="text-2xl">🕒</span>
                                <span className="text-xl font-bold text-slate-600 dark:text-slate-300">
                                    Programada: {new Date(visit.scheduledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                            </div>
                        )}
                    </div>

                    <div className="p-6 bg-blue-50 dark:bg-blue-900/20 rounded-3xl border border-blue-100 dark:border-blue-800 flex items-center justify-between">
                        <div>
                            <p className="text-sm font-black text-blue-700 dark:text-blue-500 uppercase tracking-widest mb-1">Estado Actual</p>
                            <div className={`h-4 w-4 rounded-full ${visit.status === 'COMPLETED' ? 'bg-green-500' : 'bg-amber-500'} animate-pulse`} />
                        </div>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                                // Redirigir al calendario de visitas para reagendar
                                window.location.href = '/dashboard/visits';
                            }}
                            className="rounded-xl border-blue-200 text-blue-600 font-bold"
                        >
                            Cambiar Fecha
                        </Button>
                    </div>
                </div>

                <div className="mt-auto pb-6">
                    <Button
                        onClick={() => {
                            updateData('startTime', new Date().toISOString());
                            updateData('location', { lat: 6.2442, lng: -75.5812 }); // Mock GPS
                            setStep('VISIT_STATUS');
                        }}
                        className="w-full h-16 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-lg font-black uppercase tracking-widest shadow-lg shadow-blue-600/30"
                    >
                        Iniciar Visita
                    </Button>
                </div>
            </div>
        );
    }

    // 5. Registro – Estado de la Visita
    if (step === 'VISIT_STATUS') {
        return (
            <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-6 pt-12 animate-in slide-in-from-right">
                <h2 className="text-3xl font-black text-center mb-12">¿Cómo fue la visita?</h2>
                <div className="grid gap-4">
                    {[
                        { label: '✅ Realizada', val: 'REALIZADA', color: 'bg-green-50 text-green-700 border-green-200' },
                        { label: '⚠️ Con novedades', val: 'NOVEDADES', color: 'bg-amber-50 text-amber-700 border-amber-200' },
                        { label: '❌ No realizada', val: 'NO_REALIZADA', color: 'bg-red-50 text-red-700 border-red-200' }
                    ].map(opt => (
                        <button
                            key={opt.val}
                            onClick={() => {
                                updateData('status', opt.val);
                                if (opt.val === 'NO_REALIZADA') {
                                    setStep('ALERTS');
                                } else {
                                    setStep('UNIT_STATUS');
                                }
                            }}
                            className={`h-24 rounded-3xl border-2 ${opt.color} text-xl font-black text-left pl-8 shadow-sm transition-transform active:scale-[0.98]`}
                        >
                            {opt.label}
                        </button>
                    ))}
                </div>
            </div>
        );
    }

    // 6. Registro – Estado de la Unidad
    if (step === 'UNIT_STATUS') {
        return (
            <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-6 pt-12 animate-in slide-in-from-right">
                <h2 className="text-3xl font-black text-center mb-12">Estado de la unidad</h2>
                <div className="grid gap-4">
                    {[
                        { label: '🟢 Óptimo', val: 'OPTIMO', color: 'bg-green-100 text-green-800' },
                        { label: '🟡 Seguimiento', val: 'SEGUIMIENTO', color: 'bg-amber-100 text-amber-800' },
                        { label: '🔴 Crítico', val: 'CRITICO', color: 'bg-red-100 text-red-800' }
                    ].map(opt => (
                        <button
                            key={opt.val}
                            onClick={() => {
                                updateData('unitStatus', opt.val);
                                setStep('COMPLIANCE');
                            }}
                            className={`h-24 rounded-3xl ${opt.color} text-xl font-black text-center shadow-lg transition-transform active:scale-[0.98]`}
                        >
                            {opt.label}
                        </button>
                    ))}
                </div>
            </div>
        );
    }

    // 7. Registro – Cumplimiento
    if (step === 'COMPLIANCE') {
        return (
            <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-6 pt-12 animate-in slide-in-from-right">
                <h2 className="text-3xl font-black text-center mb-12">¿Se cumplió el objetivo?</h2>
                <div className="grid gap-4">
                    {[
                        { label: '✅ Sí', val: 'SI', color: 'bg-white border-2 border-slate-200 text-slate-900' },
                        { label: '➖ Parcial', val: 'PARCIAL', color: 'bg-white border-2 border-slate-200 text-slate-900' },
                        { label: '❌ No', val: 'NO', color: 'bg-white border-2 border-slate-200 text-slate-900' }
                    ].map(opt => (
                        <button
                            key={opt.val}
                            onClick={() => {
                                updateData('compliance', opt.val);
                                setStep('ALERTS');
                            }}
                            className={`h-24 rounded-3xl ${opt.color} text-xl font-black text-center shadow-sm hover:border-slate-900 transition-all active:scale-[0.98]`}
                        >
                            {opt.label}
                        </button>
                    ))}
                </div>
            </div>
        );
    }

    // 8. Registro – Alertas (Condicional)
    if (step === 'ALERTS') {
        return (
            <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-6 pt-12 animate-in slide-in-from-right">
                <h2 className="text-3xl font-black text-center mb-8">¿Registrar alerta?</h2>

                <div className="grid grid-cols-2 gap-3 mb-6">
                    {['CRITICA', 'PREVENTIVA', 'INFORMATIVA', 'NINGUNA'].map((type) => {
                        const style =
                            type === 'CRITICA' ? '🔴 Crítica' :
                                type === 'PREVENTIVA' ? '🟡 Preventiva' :
                                    type === 'INFORMATIVA' ? '🔵 Informativa' : '🚫 No aplica';

                        return (
                            <button
                                key={type}
                                onClick={() => updateData('alertType', type)}
                                className={`h-20 rounded-2xl border-2 font-bold text-sm transition-all ${data.alertType === type
                                    ? 'border-slate-900 bg-slate-900 text-white'
                                    : 'border-slate-200 text-slate-500'
                                    }`}
                            >
                                {style}
                            </button>
                        );
                    })}
                </div>

                {data.alertType !== 'NINGUNA' && (
                    <div className="space-y-2">
                        <span className="text-xs font-black uppercase tracking-widest text-slate-400 pl-1">Observación</span>
                        <Textarea
                            placeholder="Observación breve..."
                            className="h-32 rounded-2xl bg-slate-50 p-4 border-slate-200 resize-none text-lg"
                            value={data.alertObs}
                            onChange={(e) => updateData('alertObs', e.target.value)}
                            maxLength={300}
                        />
                        <div className="text-right text-xs text-slate-400 font-bold">{data.alertObs.length}/300</div>
                    </div>
                )}

                <div className="mt-auto">
                    <Button
                        onClick={() => {
                            if (data.status === 'NO_REALIZADA' && (data.alertType === 'NONE' || data.alertType === 'NINGUNA')) {
                                toast.error("Para cancelaciones es obligatorio registrar una novedad.");
                                return;
                            }
                            setStep(data.status === 'NO_REALIZADA' ? 'CLOSING' : 'EVIDENCE');
                        }}
                        className="w-full h-16 rounded-2xl bg-slate-900 text-white text-lg font-black uppercase tracking-widest"
                    >
                        {data.status === 'NO_REALIZADA' ? 'Cerrar con Novedad' : 'Continuar'}
                    </Button>
                </div>
            </div>
        );
    }

    // 9. Registro – Evidencia
    if (step === 'EVIDENCE') {
        return (
            <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-6 pt-12 animate-in slide-in-from-right">
                <h2 className="text-3xl font-black text-center mb-12">Evidencia</h2>

                <div className="grid gap-4 mb-8">
                    <button className="h-20 rounded-3xl bg-slate-50 border-2 border-slate-200 flex items-center px-6 gap-4 text-slate-600 font-bold active:bg-slate-100">
                        <Camera className="h-6 w-6" /> 📷 Tomar foto
                    </button>
                    <button className="h-20 rounded-3xl bg-slate-50 border-2 border-slate-200 flex items-center px-6 gap-4 text-slate-600 font-bold active:bg-slate-100">
                        <FileText className="h-6 w-6" /> 📄 Adjuntar doc
                    </button>
                    <button className="h-20 rounded-3xl bg-slate-50 border-2 border-slate-200 flex items-center px-6 gap-4 text-slate-600 font-bold active:bg-slate-100">
                        <PenTool className="h-6 w-6" /> ✍️ Firma digital
                    </button>
                </div>

                <div className="mt-auto">
                    <Button
                        onClick={() => setStep('CLOSING')}
                        className="w-full h-16 rounded-2xl bg-blue-600 text-white text-lg font-black uppercase tracking-widest shadow-lg shadow-blue-600/30"
                    >
                        Continuar
                    </Button>
                </div>
            </div>
        );
    }

    // 10. Cierre de Visita & Sincronización
    if (step === 'CLOSING') {
        // Auto-trigger sync on mount
        if (syncState === 'IDLE') {
            setSyncState('SYNCING');
            // Simulate sync delay
            setTimeout(() => {
                const isOnline = navigator.onLine;
                setSyncState(isOnline ? 'SYNCED' : 'OFFLINE');
                onComplete({ ...data, syncStatus: isOnline ? 'SYNCED' : 'PENDING' });
            }, 2000);
        }

        return (
            <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-6 justify-center items-center text-center animate-in zoom-in-95 duration-300">
                {syncState === 'SYNCING' && (
                    <>
                        <div className="h-24 w-24 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-6 animate-pulse">
                            <span className="text-4xl">🔄</span>
                        </div>
                        <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Sincronizando...</h2>
                        <p className="text-slate-400 font-medium">Subiendo evidencia a la nube</p>
                    </>
                )}

                {syncState === 'SYNCED' && (
                    <>
                        <div className="h-24 w-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                            <CheckCircle2 className="h-12 w-12" />
                        </div>
                        <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-2">¡Todo listo!</h2>
                        <div className="flex items-center gap-2 mb-12">
                            <span className="text-sm font-bold text-slate-500">Estado:</span>
                            <span className="text-xs font-black uppercase tracking-widest text-green-600 bg-green-50 px-3 py-1 rounded-full border border-green-200">Sincronizado 🟢</span>
                        </div>
                    </>
                )}

                {syncState === 'OFFLINE' && (
                    <>
                        <div className="h-24 w-24 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mb-6">
                            <AlertTriangle className="h-12 w-12" />
                        </div>
                        <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-2">Guardado Local</h2>
                        <div className="flex items-center gap-2 mb-12">
                            <span className="text-sm font-bold text-slate-500">Estado:</span>
                            <span className="text-xs font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">Pendiente de Red 🟡</span>
                        </div>
                        <p className="text-slate-400 text-sm mb-8 px-8">La visita se sincronizará automáticamente cuando recuperes la conexión.</p>
                    </>
                )}

                {syncState !== 'SYNCING' && (
                    <div className="w-full space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <Button
                            onClick={onCancel} // In a real app this would trigger next visit logic
                            className="w-full h-16 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-lg font-black uppercase tracking-widest shadow-xl mb-4"
                        >
                            Siguiente Visita
                        </Button>
                        <Button
                            variant="ghost"
                            onClick={() => {
                                // Redirigir al calendario de visitas
                                window.location.href = '/dashboard/visits';
                            }}
                            className="w-full h-12 text-slate-400 font-bold uppercase tracking-widest hover:text-slate-600"
                        >
                            Ver Resumen
                        </Button>
                    </div>
                )}
            </div>
        );
    }

    return null;
}
