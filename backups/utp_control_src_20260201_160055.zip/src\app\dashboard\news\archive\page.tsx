'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Folder, FolderOpen, ChevronRight, FileText, Map, User, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { NewsHierarchy, RegionalReport } from "@/types";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

export default function NewsArchivePage() {
    const { user: currentUser, supabase } = useCurrentUser();
    const [hierarchy, setHierarchy] = useState<NewsHierarchy | null>(null);
    const [loading, setLoading] = useState(true);
    const [path, setPath] = useState<string[]>([]); // [Region, Municipality]
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchHierarchy = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/regional-reports/hierarchy?admin=true`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });

                if (response.ok) {
                    const data: NewsHierarchy = await response.json();
                    setHierarchy(data);
                }
            } catch (error) {
                console.error('Error fetching hierarchy:', error);
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchHierarchy();
        }
    }, [currentUser, supabase.auth]);

    if (!currentUser) {
        return <div className="flex items-center justify-center min-h-screen"><p className="text-slate-600">Cargando...</p></div>;
    }

    const getCurrentItems = () => {
        if (!hierarchy) return [];
        if (path.length === 0) return Object.keys(hierarchy).map(name => ({ type: 'region', name }));
        if (path.length === 1) return Object.keys(hierarchy[path[0]] || {}).map(name => ({ type: 'municipality', name }));
        if (path.length === 2) return (hierarchy[path[0]][path[1]] || []).filter((item: any) =>
            item.content.toLowerCase().includes(searchTerm.toLowerCase())
        );
        return [];
    };

    const handleBack = () => setPath(path.slice(0, -1));

    if (loading) return <div className="p-10 text-center font-black animate-pulse text-slate-300">ACCEDIENDO A LA BÓVEDA...</div>;

    const items = getCurrentItems();

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                    <Badge variant="outline" className="rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em]">
                        Archivo Maestro de Comunicaciones
                    </Badge>
                    <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                        Bóveda <span className="text-blue-600">Regional</span>
                    </h1>
                    <p className="text-slate-500 font-medium max-w-xl text-lg">
                        Información histórica organizada por jerarquía territorial y operativa.
                    </p>
                </div>
            </div>

            <div className="bg-white/80 dark:bg-slate-950/50 backdrop-blur-xl rounded-[2.5rem] border border-slate-100 dark:border-slate-800 p-8 shadow-2xl">
                <div className="flex items-center justify-between mb-8 overflow-x-auto pb-4">
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" className="text-xs font-bold uppercase" onClick={() => setPath([])}>Raíz</Button>
                        {path.map((p, i) => (
                            <div key={i} className="flex items-center gap-2">
                                <ChevronRight className="h-4 w-4 text-slate-300" />
                                <Button variant="ghost" className="text-xs font-bold uppercase text-blue-600 bg-blue-50 dark:bg-blue-900/20" onClick={() => setPath(path.slice(0, i + 1))}>
                                    {p}
                                </Button>
                            </div>
                        ))}
                    </div>
                    {path.length === 2 && (
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                            <Input
                                placeholder="Buscar en carpeta..."
                                className="pl-10 w-64 rounded-xl border-slate-100 dark:border-slate-800 focus:ring-blue-500"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {items.map((item: any, i: number) => {
                        const isFolder = path.length < 2;
                        return (
                            <div
                                key={i}
                                onClick={() => !isFolder ? null : setPath([...path, item.name])}
                                className={`group flex items-center p-6 rounded-[2rem] transition-all duration-300 cursor-pointer border shadow-sm
                                    ${isFolder
                                        ? 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-blue-400 hover:scale-105 hover:shadow-xl'
                                        : 'bg-slate-50 dark:bg-slate-900/50 border-transparent hover:bg-white dark:hover:bg-slate-800'}`}
                            >
                                <div className={`h-14 w-14 rounded-2xl flex items-center justify-center mr-5 transition-transform group-hover:rotate-6
                                    ${isFolder ? 'bg-blue-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
                                    {isFolder ? <Folder className="h-7 w-7" /> : <FileText className="h-7 w-7" />}
                                </div>
                                <div className="flex-1 overflow-hidden">
                                    <div className="flex items-center gap-2 mb-1">
                                        <p className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tighter truncate">
                                            {isFolder ? item.name : item.content.split(': ')[0]}
                                        </p>
                                        {!isFolder && item.priority && (
                                            <Badge variant="outline" className={`rounded-lg px-2 py-0 text-[8px] font-black uppercase tracking-widest ${item.priority === 'HIGH' ? 'border-red-100 bg-red-50 text-red-600' :
                                                    item.priority === 'MEDIUM' ? 'border-amber-100 bg-amber-50 text-amber-600' :
                                                        'border-blue-100 bg-blue-50 text-blue-600'
                                                }`}>
                                                {item.priority}
                                            </Badge>
                                        )}
                                    </div>
                                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest truncate">
                                        {isFolder
                                            ? `${item.type === 'region' ? 'Carpeta Regional' : 'Dependencia Municipal'}`
                                            : `Publicado por: ${item.user?.fullName} • ${new Date(item.createdAt).toLocaleDateString()}`}
                                    </p>
                                </div>
                                {isFolder && <ChevronRight className="h-5 w-5 text-slate-300 group-hover:text-blue-600 transition-colors" />}
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

// Minimal Button internal to avoid complex imports if not needed, but better to use existing
function Button({ children, onClick, variant, className, disabled }: any) {
    return (
        <button
            disabled={disabled}
            onClick={onClick}
            className={`px-4 py-2 flex items-center justify-center transition-all ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
            {children}
        </button>
    );
}

