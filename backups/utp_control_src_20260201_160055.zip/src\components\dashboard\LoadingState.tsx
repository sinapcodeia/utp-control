'use client';

import { ShieldAlert } from "lucide-react";

export function LoadingState() {
    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 animate-in fade-in duration-700">
            <div className="relative">
                <div className="h-24 w-24 rounded-[2rem] bg-blue-600/10 flex items-center justify-center animate-pulse">
                    <ShieldAlert className="h-10 w-10 text-blue-600 animate-bounce" />
                </div>
                <div className="absolute inset-0 rounded-[2rem] border-2 border-blue-600/20 animate-ping" />
            </div>
            <div className="space-y-2 text-center">
                <h3 className="text-xl font-black tracking-tighter text-slate-900 dark:text-white uppercase">
                    Sincronizando <span className="text-blue-600">Datos</span>
                </h3>
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest animate-pulse">
                    Accediendo a la bóveda segura...
                </p>
            </div>
        </div>
    );
}
