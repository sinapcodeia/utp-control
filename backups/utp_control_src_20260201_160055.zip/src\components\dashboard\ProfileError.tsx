'use client';

import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

export function ProfileError() {
    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6">
            <div className="h-24 w-24 rounded-[2.5rem] bg-red-50 dark:bg-red-900/20 flex items-center justify-center text-red-500 shadow-xl shadow-red-500/10">
                <AlertCircle className="h-12 w-12" />
            </div>
            <div className="text-center space-y-3">
                <h2 className="text-3xl font-black uppercase tracking-tighter text-slate-900 dark:text-white">Perfil no detectado</h2>
                <p className="text-slate-500 dark:text-slate-400 max-w-md font-medium">
                    Tu cuenta está autenticada pero no hemos encontrado un perfil operativo asociado.
                    Contacta al administrador para habilitar tu acceso.
                </p>
            </div>
            <Button
                onClick={() => window.location.reload()}
                variant="outline"
                className="rounded-2xl px-10 h-14 font-black uppercase tracking-widest text-xs border-slate-200 hover:bg-slate-50 transition-all"
            >
                Reintentar Sincronización
            </Button>
        </div>
    );
}
