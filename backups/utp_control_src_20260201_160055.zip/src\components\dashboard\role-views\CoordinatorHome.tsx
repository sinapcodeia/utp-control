'use client';

import { useState, useMemo, useEffect } from 'react';
import { DashboardStats, RegionalReport, TeamMember } from "@/types";
import { CoordinatorStats } from "../coordinator/CoordinatorStats";
import { OperationsCalendar } from "../coordinator/OperationsCalendar";
import { TeamHierarchy } from "../coordinator/TeamHierarchy";
import { ManagerDetailSheet } from "../coordinator/ManagerDetailSheet";
import { CoordinatorSimulation } from "./CoordinatorSimulation";
import { isSameDay } from 'date-fns';
import { ShieldCheck, Activity } from "lucide-react";
import { CoverageMap } from "../coordinator/CoverageMap";

interface CoordinatorHomeProps {
    stats: DashboardStats | null;
    recentNews: RegionalReport[];
    user: any;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

export function CoordinatorHome({ stats, recentNews, user }: CoordinatorHomeProps) {
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [selectedManager, setSelectedManager] = useState<any>(null);
    const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
    const [loadingTeam, setLoadingTeam] = useState(true);

    useEffect(() => {
        const fetchTeam = async () => {
            try {
                const token = localStorage.getItem('token');
                const res = await fetch(`${API_URL}/stats/team`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.ok) {
                    const data = await res.json();
                    setTeamMembers(data);
                }
            } catch (e) {
                console.error("Error fetching team:", e);
            } finally {
                setLoadingTeam(false);
            }
        };

        fetchTeam();
    }, []);

    // Filter members based on date (Simulation logic: randomize availability based on day if not current day)
    const dailyMembers = useMemo(() => {
        if (isSameDay(selectedDate, new Date())) return teamMembers;

        const day = selectedDate.getDate();
        return teamMembers.filter((m, i) => (day + i) % 3 !== 0);
    }, [selectedDate, teamMembers]);

    return (
        <div className="space-y-6 animate-in fade-in duration-700 pb-12">
            {/* Header Section: Fecha | Región | Filtros */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
                <div>
                    <h2 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white uppercase">
                        Centro de Comando <span className="text-blue-600">Operativo</span>
                    </h2>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">
                        Región {user.region} • {new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 bg-red-50 text-red-600 px-4 py-2 rounded-full border border-red-100 animate-pulse">
                        <span className="h-2 w-2 bg-red-600 rounded-full" />
                        <span className="text-[10px] font-black uppercase tracking-widest">{stats?.criticalAlerts || 0} Alertas Críticas</span>
                    </div>
                </div>
            </div>

            {/* Executive Stats (North Star) */}
            <CoordinatorStats
                stats={stats}
                regionName={user.region || 'Regional'}
                onStatClick={(section) => {
                    const el = document.getElementById(section === 'team' ? 'team-hierarchy' : 'ops-calendar');
                    el?.scrollIntoView({ behavior: 'smooth' });
                }}
            />

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                {/* Column 1 & 2: Charts & Map Area */}
                <div className="lg:col-span-2 space-y-6">



                    {/* Visitas Prog vs Ejecutadas Chart Area */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Visitas: Programadas vs Ejecutadas */}
                        <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-6 shadow-lg border border-slate-100 dark:border-slate-800 flex flex-col justify-between h-full">
                            <h3 className="text-sm font-black uppercase tracking-tight text-slate-900 dark:text-white mb-6">Visitas: Programadas vs Ejecutadas</h3>
                            <div className="flex items-end gap-4 h-32 px-4 mb-4">
                                <div className="flex-1 flex flex-col items-center gap-2 group">
                                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-t-xl relative h-full overflow-hidden">
                                        <div className="absolute bottom-0 w-full bg-slate-300 dark:bg-slate-600 h-[80%]" />
                                    </div>
                                    <span className="text-[10px] font-bold text-slate-400">Prog.</span>
                                </div>
                                <div className="flex-1 flex flex-col items-center gap-2 group">
                                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-t-xl relative h-full overflow-hidden">
                                        <div className="absolute bottom-0 w-full bg-blue-600 h-[72%]" />
                                    </div>
                                    <span className="text-[10px] font-bold text-slate-400">Ejec.</span>
                                </div>
                            </div>
                            <div className="mt-auto flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-400 pt-4 border-t border-slate-50 dark:border-slate-800">
                                <span className="flex items-center gap-1.5"><div className="h-1.5 w-1.5 rounded-full bg-slate-300" /> {stats?.personnelTotal || 150} Total</span>
                                <span className="flex items-center gap-1.5 text-blue-600"><div className="h-1.5 w-1.5 rounded-full bg-blue-600" /> {stats?.totalReports || 108} Realizadas</span>
                            </div>
                        </div>

                        {/* Alertas Inteligentes Summary */}
                        <div className="bg-white dark:bg-slate-900 rounded-[2rem] p-6 shadow-lg border border-slate-100 dark:border-slate-800 h-full">
                            <h3 className="text-sm font-black uppercase tracking-tight text-slate-900 dark:text-white mb-4">Alertas Inteligentes</h3>
                            <div className="space-y-3">
                                <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-xl border border-red-100 dark:border-red-900/50">
                                    <div className="flex items-center gap-3">
                                        <div className="h-2 w-2 rounded-full bg-red-600 animate-pulse" />
                                        <span className="text-xs font-bold text-red-700 dark:text-red-400">Críticas (Acción Inmediata)</span>
                                    </div>
                                    <span className="text-lg font-black text-red-700 dark:text-red-400">{stats?.criticalAlerts || 0}</span>
                                </div>
                                <div className="flex items-center justify-between p-3 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-100 dark:border-amber-900/50">
                                    <div className="flex items-center gap-3">
                                        <div className="h-2 w-2 rounded-full bg-amber-500" />
                                        <span className="text-xs font-bold text-amber-700 dark:text-amber-400">Preventivas</span>
                                    </div>
                                    <span className="text-lg font-black text-amber-700 dark:text-amber-400">{stats?.preventiveAlerts || 5}</span>
                                </div>
                                <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-900/50">
                                    <div className="flex items-center gap-3">
                                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                                        <span className="text-xs font-bold text-blue-700 dark:text-blue-400">Informativas</span>
                                    </div>
                                    <span className="text-lg font-black text-blue-700 dark:text-blue-400">12</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Interactive Coverage Map */}
                    <CoverageMap coordinates={stats?.visitCoordinates || []} />

                    <div id="team-hierarchy">
                        {loadingTeam ? (
                            <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-12 text-center">
                                <Activity className="h-8 w-8 animate-spin mx-auto text-blue-600 mb-4" />
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Sincronizando equipo...</p>
                            </div>
                        ) : (
                            <TeamHierarchy
                                members={[...dailyMembers]}
                                onMemberSelect={(member) => setSelectedManager(member)}
                            />
                        )}
                    </div>
                </div>

                {/* Right Column: Calendar & Monthly Reports */}
                <div className="space-y-6">
                    <div id="ops-calendar">
                        <OperationsCalendar
                            selectedDate={selectedDate}
                            onDateSelect={setSelectedDate}
                        />
                    </div>

                    {/* Monthly Reports Box */}
                    <div className="bg-slate-900 text-white rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 opacity-10">
                            <svg className="w-32 h-32" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                        </div>
                        <h3 className="text-lg font-black uppercase tracking-tight mb-6 relative z-10">Informes del Mes</h3>
                        <div className="space-y-4 relative z-10">
                            <button
                                onClick={async () => {
                                    try {
                                        const token = localStorage.getItem('token') || '';
                                        const res = await fetch('http://127.0.0.1:3001/reports/executive/pdf', {
                                            headers: { 'Authorization': `Bearer ${token}` }
                                        });
                                        if (!res.ok) throw new Error('Error generando PDF');
                                        const blob = await res.blob();
                                        const url = window.URL.createObjectURL(blob);
                                        const a = document.createElement('a');
                                        a.href = url;
                                        a.download = `Informe_Ejecutivo_${new Date().toISOString().slice(0, 10)}.pdf`;
                                        document.body.appendChild(a);
                                        a.click();
                                        window.URL.revokeObjectURL(url);
                                    } catch (e) {
                                        console.error(e);
                                        alert('Error descargando informe');
                                    }
                                }}
                                className="w-full flex items-center justify-between p-4 bg-white/10 rounded-2xl hover:bg-white/20 transition-all group font-sans"
                            >
                                <div className="text-left">
                                    <p className="text-sm font-bold">Informe Ejecutivo</p>
                                    <p className="text-[10px] opacity-60 uppercase tracking-wider">Enero 2026</p>
                                </div>
                                <span className="text-xs font-black bg-white text-slate-900 px-3 py-1 rounded-lg">PDF</span>
                            </button>
                            <button className="w-full flex items-center justify-between p-4 bg-white/5 rounded-2xl hover:bg-white/10 transition-all font-sans">
                                <div className="text-left">
                                    <p className="text-sm font-bold text-white/60">Auditoría Riesgos</p>
                                    <p className="text-[10px] opacity-40 uppercase tracking-wider">Protocolo Activo</p>
                                </div>
                                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                            </button>
                        </div>
                    </div>

                    {/* Simulation Tool (Mini) */}
                    <CoordinatorSimulation />
                </div>
            </div>

            {/* Drill-Down Sheet */}
            <ManagerDetailSheet
                isOpen={!!selectedManager}
                onClose={() => setSelectedManager(null)}
                manager={selectedManager}
            />
        </div>
    );
}
