'use client';

import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import { createClient } from '@/utils/supabase/client';
import { User } from '@supabase/supabase-js';

export interface CurrentUser {
    id: string;
    email: string;
    full_name: string;
    role: 'ADMIN' | 'COORDINATOR' | 'GESTOR' | 'SUPPORT' | 'USER';
    region_id: string | null;
    municipality_id: string | null;
    region?: {
        id: string;
        name: string;
        code: string;
    };
    municipality?: {
        id: string;
        name: string;
    };
    is_active: boolean;
    permissions?: any;
}

interface AuthContextType {
    user: CurrentUser | null;
    authUser: User | null;
    loading: boolean;
    profileLoading: boolean;
    error: Error | null;
    refreshUser: () => Promise<void>;
    supabase: ReturnType<typeof createClient>;
    authReady: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<CurrentUser | null>(null);
    const [authUser, setAuthUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [profileLoading, setProfileLoading] = useState(false);
    const [authReady, setAuthReady] = useState(false);
    const [error, setError] = useState<Error | null>(null);
    const supabase = createClient();

    const loadProfile = useCallback(async () => {
        try {
            setProfileLoading(true);
            console.log('[AuthContext] Loading profile from /api/users/me...');

            const response = await fetch('/api/users/me', {
                credentials: 'include', // Importante para cookies
                headers: {
                    'Cache-Control': 'no-cache'
                }
            });

            console.log('[AuthContext] Response status:', response.status);

            if (response.ok) {
                const userData = await response.json();
                console.log('[AuthContext] Profile loaded successfully:', {
                    email: userData.email,
                    role: userData.role
                });
                setUser(userData);
                setAuthReady(true);
            } else {
                console.warn('[AuthContext] Profile fetch failed with status:', response.status);
                setUser(null);
            }
        } catch (err) {
            console.error('[AuthContext] Error loading profile:', err);
            console.error('[AuthContext] Error details:', {
                name: (err as any)?.name,
                message: (err as any)?.message,
                stack: (err as any)?.stack
            });
            setError(err instanceof Error ? err : new Error('Failed to load profile'));
        } finally {
            setProfileLoading(false);
        }
    }, []);

    const initializeAuth = useCallback(async () => {
        try {
            setLoading(true);
            const { data: { user: currentAuthUser }, error: authError } = await supabase.auth.getUser();

            if (authError || !currentAuthUser) {
                setAuthUser(null);
                setUser(null);
                setAuthReady(true); // Ready even if not logged in
            } else {
                setAuthUser(currentAuthUser);
                await loadProfile();
            }
        } catch (err) {
            console.error('Auth initialization error:', err);
            setError(err instanceof Error ? err : new Error('Auth initialization failed'));
        } finally {
            setLoading(false);
        }
    }, [loadProfile, supabase.auth]);

    useEffect(() => {
        // Initial load
        initializeAuth();

        // Listen for auth changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
            if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
                const newUser = session?.user || null;
                setAuthUser(newUser);
                if (newUser) await loadProfile();
            } else if (event === 'SIGNED_OUT') {
                setAuthUser(null);
                setUser(null);
            }
        });

        return () => {
            subscription.unsubscribe();
        };
    }, [initializeAuth, loadProfile, supabase.auth]);

    const contextValue = useMemo(() => ({
        user,
        authUser,
        loading,
        profileLoading,
        error,
        refreshUser: initializeAuth,
        supabase,
        authReady
    }), [user, authUser, loading, profileLoading, error, initializeAuth, supabase, authReady]);

    return (
        <AuthContext.Provider value={contextValue}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
