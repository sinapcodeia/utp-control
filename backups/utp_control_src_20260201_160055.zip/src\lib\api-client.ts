
import { createClient } from '@/utils/supabase/client';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

type RequestMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

async function request<T = any>(endpoint: string, method: RequestMethod, body?: any): Promise<T> {
    const supabase = createClient();
    const { data: { session } } = await supabase.auth.getSession();
    const token = session?.access_token;

    const headers: HeadersInit = {
        'Content-Type': 'application/json',
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    // Ensure endpoint starts with / if not absolute
    const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    const url = endpoint.startsWith('http') ? endpoint : `${API_URL}${normalizedEndpoint}`;

    const response = await fetch(url, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
    });

    if (!response.ok) {
        if (response.status === 401) {
            console.error(`Unauthorized access to ${url}`);
            // Optional: trigger logout or redirect
        }
        throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    // Return null for 204 No Content
    if (response.status === 204) {
        return null as T;
    }

    return response.json();
}

export const apiClient = {
    get: <T = any>(endpoint: string) => request<T>(endpoint, 'GET'),
    post: <T = any>(endpoint: string, body: any) => request<T>(endpoint, 'POST', body),
    put: <T = any>(endpoint: string, body: any) => request<T>(endpoint, 'PUT', body),
    patch: <T = any>(endpoint: string, body: any) => request<T>(endpoint, 'PATCH', body),
    delete: <T = any>(endpoint: string) => request<T>(endpoint, 'DELETE'),
};
