import { useAuth, CurrentUser } from '@/contexts/AuthContext';
import { ROLE_DEFAULTS } from '@/utils/role-defaults';
import { useEffect, useState } from 'react';

export type { CurrentUser };

interface UseCurrentUserReturn {
    user: CurrentUser | null;
    loading: boolean;
    profileLoading: boolean;
    error: Error | null;
    supabase: ReturnType<typeof useAuth>['supabase'];
    authReady: boolean;
}

export function useCurrentUser(): UseCurrentUserReturn {
    const { user: realUser, loading, profileLoading, error, supabase, authReady } = useAuth();
    const [simulatedUser, setSimulatedUser] = useState<CurrentUser | null>(null);

    useEffect(() => {
        if (!realUser) {
            setSimulatedUser(null);
            return;
        }

        // Only allow simulation if real user is ADMIN (Safety Check)
        if (realUser.role !== 'ADMIN') {
            setSimulatedUser(realUser);
            return;
        }

        // Check for local simulation override
        const storedRole = localStorage.getItem('dev_simulate_role');
        if (storedRole && ['COORDINATOR', 'GESTOR', 'USER'].includes(storedRole)) {
            // Mock permissions based on role
            const mockPermissions = ROLE_DEFAULTS[storedRole];

            // Mock region if simulating regional role
            const mockRegion = storedRole === 'COORDINATOR' ? {
                id: 'REG-ANT-001',
                name: 'Antioquia',
                code: 'ANT'
            } : realUser.region;

            setSimulatedUser({
                ...realUser,
                role: storedRole as any,
                permissions: mockPermissions as any, // TypeScript might complain about specific shape mismatch if strict
                region: mockRegion
            });
        } else {
            setSimulatedUser(realUser);
        }
    }, [realUser]);

    return {
        user: simulatedUser || realUser, // Fallback to realUser while effect runs
        loading,
        profileLoading,
        error,
        supabase,
        authReady
    };
}
