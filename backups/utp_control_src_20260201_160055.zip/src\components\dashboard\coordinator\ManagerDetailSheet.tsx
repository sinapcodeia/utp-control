'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserCircle2, MapPin, Phone, Mail, Clock, CheckCircle2, AlertTriangle, X, ShieldAlert, Activity, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface ManagerDetailSheetProps {
    isOpen: boolean;
    onClose: () => void;
    manager: any; // Replace with proper type
}

export function ManagerDetailSheet({ isOpen, onClose, manager }: ManagerDetailSheetProps) {
    const [isAssigning, setIsAssigning] = useState(false);
    const [assignData, setAssignData] = useState({ fullName: '', scheduledAt: '' });

    if (!manager) return null;

    const handleAssign = async () => {
        if (!assignData.fullName || !assignData.scheduledAt) {
            toast.error("Complete todos los campos");
            return;
        }

        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001'}/territory/visits`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    fullName: assignData.fullName,
                    addressText: 'Asignado por Coordinador',
                    scheduledAt: new Date(assignData.scheduledAt).toISOString(),
                    regionId: 'REG-ANT-001',
                    municipalityId: 'MUN-MED-001',
                    assignedToId: manager.id,
                    status: 'PENDING',
                    priority: 'HIGH',
                    source: 'MANUAL'
                })
            });

            if (!response.ok) throw new Error("Error");
            toast.success("Misión asignada con éxito");
            setIsAssigning(false);
            setAssignData({ fullName: '', scheduledAt: '' });
            window.location.reload();
        } catch (e) {
            toast.error("No se pudo asignar la misión");
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="fixed right-0 top-0 h-full w-full max-w-md border-l border-slate-200 bg-white p-0 shadow-2xl duration-500 data-[state=open]:slide-in-from-right data-[state=closed]:slide-out-to-right sm:max-w-md dark:bg-slate-950 dark:border-slate-800 rounded-none sm:rounded-none translate-x-0 translate-y-0 left-auto">
                <div className="flex flex-col h-full overflow-hidden">
                    {/* Header Premium */}
                    <div className="relative bg-slate-900 p-8 pb-12 overflow-hidden shrink-0">
                        <div className="absolute top-0 right-0 p-8 opacity-10">
                            <UserCircle2 className="h-40 w-40 text-white" />
                        </div>

                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={onClose}
                            className="absolute top-4 right-4 text-white/50 hover:text-white hover:bg-white/10 rounded-full"
                        >
                            <X className="h-5 w-5" />
                        </Button>

                        <div className="relative z-10 flex flex-col items-center text-center">
                            <div className="h-24 w-24 rounded-3xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center mb-4 shadow-xl">
                                <UserCircle2 className="h-12 w-12 text-white" />
                            </div>
                            <h2 className="text-2xl font-black text-white tracking-tight">{manager.name}</h2>
                            <p className="text-blue-400 font-bold text-xs uppercase tracking-widest mt-1">{manager.role}</p>

                            <div className="flex gap-2 mt-4">
                                <Badge className={`border-none px-3 py-1 text-[10px] font-black uppercase tracking-widest ${manager.status === 'active' ? 'bg-green-500 text-white' :
                                    manager.status === 'break' ? 'bg-amber-500 text-white' :
                                        'bg-slate-700 text-slate-300'
                                    }`}>
                                    {manager.status === 'active' ? 'En Campo' : manager.status === 'break' ? 'En Pausa' : 'Inactivo'}
                                </Badge>
                                <Badge variant="outline" className="border-white/20 text-white px-3 py-1 text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                                    <MapPin className="h-3 w-3" />
                                    {manager.municipality}
                                </Badge>
                            </div>
                        </div>
                    </div>

                    {/* Scrollable Content */}
                    <div className="flex-1 overflow-y-auto p-6 space-y-8">
                        {/* KPIs Rápidos */}
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Visitas Hoy</p>
                                <div className="flex items-end gap-2">
                                    <span className="text-3xl font-black text-slate-900 dark:text-white">{manager.visitsCompleted}</span>
                                    <span className="text-xs font-bold text-slate-400 mb-1">/ {manager.visitsAssigned}</span>
                                </div>
                                <Progress value={(manager.visitsCompleted / manager.visitsAssigned) * 100} className="h-1.5 mt-3 bg-slate-200" />
                            </div>
                            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Eficiencia</p>
                                <div className="flex items-center gap-2">
                                    <span className="text-3xl font-black text-blue-600">94%</span>
                                    <Activity className="h-4 w-4 text-blue-500" />
                                </div>
                                <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-wide">Tiempo prom: 12m</p>
                            </div>
                        </div>

                        {/* Asignación Rápida */}
                        <div className="space-y-4">
                            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest flex items-center gap-2">
                                Gestión de Misiones
                            </h3>
                            <Dialog open={isAssigning} onOpenChange={setIsAssigning}>
                                <DialogTrigger asChild>
                                    <Button className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-600/20 flex items-center justify-center gap-2">
                                        <Plus className="h-4 w-4" /> Asignar Nueva Misión
                                    </Button>
                                </DialogTrigger>
                                <DialogContent className="rounded-[2.5rem] border-none bg-white dark:bg-slate-900 p-8">
                                    <DialogHeader>
                                        <DialogTitle className="text-xl font-black uppercase tracking-tight text-slate-900 dark:text-white text-center">Asignar a {manager.name}</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-6 py-4">
                                        <div className="space-y-2">
                                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Unidad Productiva</Label>
                                            <Input
                                                placeholder="Nombre de la UP"
                                                value={assignData.fullName}
                                                onChange={(e) => setAssignData({ ...assignData, fullName: e.target.value })}
                                                className="h-14 rounded-2xl border-slate-100 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-lg font-bold"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Fecha y Hora</Label>
                                            <Input
                                                type="datetime-local"
                                                value={assignData.scheduledAt}
                                                onChange={(e) => setAssignData({ ...assignData, scheduledAt: e.target.value })}
                                                className="h-14 rounded-2xl border-slate-100 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-lg font-bold"
                                            />
                                        </div>
                                        <Button
                                            onClick={handleAssign}
                                            className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-black uppercase tracking-widest mt-4 shadow-xl shadow-blue-600/20"
                                        >
                                            Confirmar Asignación
                                        </Button>
                                    </div>
                                </DialogContent>
                            </Dialog>
                        </div>

                        {/* Contacto */}
                        <div className="space-y-3">
                            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest">Información de Contacto</h3>
                            <div className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
                                <div className="h-8 w-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                                    <Phone className="h-4 w-4" />
                                </div>
                                <div className="flex-1">
                                    <p className="text-xs font-bold text-slate-900 dark:text-white">Teléfono</p>
                                    <p className="text-xs text-slate-500">+57 300 123 4567</p>
                                </div>
                                <Button size="sm" variant="ghost" className="text-blue-600 text-xs font-bold">Llamar</Button>
                            </div>
                            <div className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
                                <div className="h-8 w-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                                    <Mail className="h-4 w-4" />
                                </div>
                                <div className="flex-1">
                                    <p className="text-xs font-bold text-slate-900 dark:text-white">Email</p>
                                    <p className="text-xs text-slate-500">gestor@utp.edu.co</p>
                                </div>
                                <Button size="sm" variant="ghost" className="text-indigo-600 text-xs font-bold">Copiar</Button>
                            </div>
                        </div>

                        {/* Timeline */}
                        <div className="space-y-4">
                            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest">Actividad Reciente</h3>
                            <div className="relative pl-4 border-l-2 border-slate-100 dark:border-slate-800 space-y-6">
                                {[
                                    { time: '10:45 AM', title: 'Visita Completada', desc: 'Barrio El Poblado - Encuesta finalizada', type: 'success' },
                                    { time: '09:30 AM', title: 'Inicio de Ruta', desc: 'Check-in en zona asignada', type: 'info' },
                                    { time: '08:15 AM', title: 'Sincronización', desc: 'Descarga de 15 registros nuevos', type: 'system' },
                                ].map((item, i) => (
                                    <div key={i} className="relative">
                                        <div className={`absolute -left-[21px] top-0 h-3 w-3 rounded-full border-2 border-white dark:border-slate-950 ${item.type === 'success' ? 'bg-green-500' :
                                            item.type === 'info' ? 'bg-blue-500' : 'bg-slate-400'
                                            }`} />
                                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{item.time}</p>
                                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">{item.title}</h4>
                                        <p className="text-xs text-slate-500 mt-0.5">{item.desc}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Alertas Asociadas */}
                        <div className="space-y-3">
                            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest flex items-center gap-2">
                                Alertas Activas
                                <Badge className="bg-red-100 text-red-600 border-none px-1.5 py-0 text-[9px]">1</Badge>
                            </h3>
                            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/50 flex gap-3">
                                <ShieldAlert className="h-5 w-5 text-red-600 shrink-0" />
                                <div>
                                    <h4 className="text-xs font-black text-red-700 dark:text-red-400 uppercase tracking-tight">Reporte de Seguridad</h4>
                                    <p className="text-xs text-red-600/80 dark:text-red-400/80 mt-1">Zona con restricción de acceso temporal reportada por el gestor.</p>
                                    <Button size="sm" className="mt-3 h-7 bg-red-600 hover:bg-red-700 text-white text-[10px] font-black uppercase tracking-widest w-full">
                                        Ver Incidente
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
