'use client';

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronRight, ArrowLeftRight, Plus, Calendar as CalendarIcon, MapPin, Search, Globe, Building2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState, useEffect, useCallback } from "react";
import { toast } from "sonner";
import { createClient } from "@/utils/supabase/client";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

interface ManagerAgendaProps {
    visits: any[];
    onSelectVisit: (visit: any) => void;
    onBack?: () => void;
    filterMode?: 'ALL' | 'PENDING' | 'HIGH';
}

export function ManagerAgenda({ visits, onSelectVisit, onBack, filterMode = 'ALL' }: ManagerAgendaProps) {
    const [searchTerm, setSearchTerm] = useState("");
    const todayStr = new Date().toLocaleDateString('en-CA');

    const filteredVisits = visits
        .filter(v => {
            if (filterMode === 'PENDING') return v.status === 'PENDING';
            if (filterMode === 'HIGH') return v.priority === 'HIGH' || v.status === 'CANCELLED';
            return true;
        })
        .filter(v =>
            v.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            v.citizenId?.includes(searchTerm) ||
            v.id?.includes(searchTerm)
        )
        .sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime());

    const todayVisits = filteredVisits.filter(v => v.scheduledAt && v.scheduledAt.startsWith(todayStr));
    const upcomingVisits = filteredVisits.filter(v => v.scheduledAt && !v.scheduledAt.startsWith(todayStr));

    const formattedDate = new Date().toLocaleDateString('es-CO', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });

    const [isAdding, setIsAdding] = useState(false);
    const [regions, setRegions] = useState<any[]>([]);
    const [municipalities, setMunicipalities] = useState<any[]>([]);
    const [isManualMode, setIsManualMode] = useState(false);

    const [newVisit, setNewVisit] = useState({
        fullName: '',
        scheduledAt: '',
        regionId: '',
        municipalityId: '',
        manualMunicipality: ''
    });

    // Cargar regiones al montar
    useEffect(() => {
        const fetchRegions = async () => {
            try {
                const supabase = createClient();
                const { data: { session } } = await supabase.auth.getSession();

                if (!session?.access_token) return;

                const response = await fetch(`${API_URL}/territory/regions`, {
                    headers: { 'Authorization': `Bearer ${session.access_token}` }
                });
                if (response.ok) {
                    const data = await response.json();
                    setRegions(data);
                } else {
                    console.error("Failed to fetch regions", response.status);
                    toast.error("Error al cargar regiones del servidor");
                }
            } catch (e) {
                console.error("Error fetching regions", e);
                toast.error("No se pudo conectar con el servidor de territorios");
            }
        };
        fetchRegions();
    }, []);

    // Cargar municipios cuando cambia la región
    useEffect(() => {
        const fetchMunicipalities = async () => {
            if (!newVisit.regionId) {
                setMunicipalities([]);
                return;
            }
            try {
                const supabase = createClient();
                const { data: { session } } = await supabase.auth.getSession();

                if (!session?.access_token) return;

                const response = await fetch(`${API_URL}/territory/municipalities?regionId=${newVisit.regionId}`, {
                    headers: { 'Authorization': `Bearer ${session.access_token}` }
                });
                if (response.ok) {
                    const data = await response.json();
                    setMunicipalities(data);
                }
            } catch (e) {
                console.error("Error fetching municipalities", e);
            }
        };
        fetchMunicipalities();
    }, [newVisit.regionId]);

    // Render individual visit item
    const renderVisitItem = (visit: any) => {
        const statusColors = {
            PENDING: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
            COMPLETED: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
            CANCELLED: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
        };

        const priorityColors = {
            LOW: 'bg-blue-100 text-blue-700',
            MEDIUM: 'bg-amber-100 text-amber-700',
            HIGH: 'bg-red-100 text-red-700',
        };

        return (
            <div
                key={visit.id}
                onClick={() => onSelectVisit(visit)}
                className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800 cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all duration-200"
            >
                <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                        <h3 className="font-black text-sm text-slate-900 dark:text-white uppercase tracking-tight">
                            {visit.fullName || 'Sin nombre'}
                        </h3>
                        <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mt-1">
                            {visit.citizenId || visit.id}
                        </p>
                    </div>
                    <ChevronRight className="h-5 w-5 text-slate-400" />
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                    <Badge className={`text-[8px] font-black uppercase px-2 py-0.5 ${statusColors[visit.status as keyof typeof statusColors] || statusColors.PENDING}`}>
                        {visit.status || 'PENDING'}
                    </Badge>
                    {visit.priority && (
                        <Badge className={`text-[8px] font-black uppercase px-2 py-0.5 ${priorityColors[visit.priority as keyof typeof priorityColors] || priorityColors.MEDIUM}`}>
                            {visit.priority}
                        </Badge>
                    )}
                    {visit.scheduledAt && (
                        <div className="flex items-center gap-1 text-[9px] font-bold text-slate-500 dark:text-slate-400">
                            <CalendarIcon className="h-3 w-3" />
                            {new Date(visit.scheduledAt).toLocaleDateString('es-CO', { day: '2-digit', month: 'short' })}
                        </div>
                    )}
                    {visit.municipality?.name && (
                        <div className="flex items-center gap-1 text-[9px] font-bold text-slate-500 dark:text-slate-400">
                            <MapPin className="h-3 w-3" />
                            {visit.municipality.name}
                        </div>
                    )}
                </div>
            </div>
        );
    };

    const handleCreateVisit = async () => {
        if (!newVisit.fullName || !newVisit.scheduledAt || !newVisit.regionId) {
            toast.error("Por favor completa los campos obligatorios");
            return;
        }

        if (!isManualMode && !newVisit.municipalityId) {
            toast.error("Selecciona un municipio o activa el modo manual");
            return;
        }

        try {
            const supabase = createClient();
            const { data: { session } } = await supabase.auth.getSession();
            const token = session?.access_token;

            if (!token) {
                toast.error("Sesión no válida. Por favor reingresa.");
                return;
            }

            const response = await fetch(`${API_URL}/territory/visits`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    fullName: newVisit.fullName,
                    addressText: isManualMode ? `Manual: ${newVisit.manualMunicipality}` : 'Ingresado por Gestor',
                    scheduledAt: new Date(newVisit.scheduledAt).toISOString(),
                    regionId: newVisit.regionId,
                    municipalityId: isManualMode ? null : newVisit.municipalityId,
                    area: isManualMode ? newVisit.manualMunicipality : undefined,
                    assignedToId: session?.user?.id, // Ensure it's assigned to the current gestor
                    status: 'PENDING',
                    priority: 'MEDIUM',
                    source: 'MANUAL'
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || "Error al crear visita");
            }

            toast.success("Misión programada exitosamente");
            setIsAdding(false);
            setNewVisit({ fullName: '', scheduledAt: '', regionId: '', municipalityId: '', manualMunicipality: '' });

            // In a real app we would refetch, but here we trigger parents fetch via a callback if provided
            // or we use a more gentle way to update. For now, let's stick to reload but with better timing.
            setTimeout(() => window.location.reload(), 500);
        } catch (error) {
            console.error(error);
            toast.error("No se pudo programar la visita");
        }
    };

    return (
        <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 p-4">
            {/* Header con botón atrás */}
            <div className="flex items-center gap-4 mb-2">
                {onBack && (
                    <Button
                        variant="ghost"
                        size="icon"
                        onClick={onBack}
                        className="rounded-full bg-white dark:bg-slate-900 shadow-sm border border-slate-100 dark:border-slate-800"
                    >
                        <ChevronRight className="h-6 w-6 rotate-180" />
                    </Button>
                )}
                <div>
                    <h1 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none">Mi Agenda</h1>
                    <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mt-1">
                        {filterMode === 'PENDING' ? 'Filtrando: Pendientes' :
                            filterMode === 'HIGH' ? 'Filtrando: Críticas/Reprogramadas' :
                                'Todas las misiones'}
                    </p>
                </div>
            </div>

            <div className="flex items-center gap-4 mb-8">
                <div className="relative flex-1">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input
                        placeholder="Buscar por nombre o ID..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="h-14 rounded-2xl border-none bg-white dark:bg-slate-900 shadow-sm pl-12 font-bold text-lg"
                    />
                </div>
                <Dialog open={isAdding} onOpenChange={setIsAdding}>
                    <DialogTrigger asChild>
                        <Button className="h-12 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-600/20 text-white flex items-center gap-2">
                            <Plus className="h-5 w-5" />
                            <span className="text-[10px] font-black uppercase tracking-widest">Agendar Visita</span>
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="rounded-[2.5rem] border-none bg-white dark:bg-slate-900 p-8 max-w-lg overflow-y-auto max-h-[90vh]">
                        <DialogHeader>
                            <DialogTitle className="text-xl font-black uppercase tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                                <Globe className="h-5 w-5 text-blue-600" /> Programar Misión
                            </DialogTitle>
                        </DialogHeader>

                        <div className="space-y-6 py-4">
                            {/* Nombre de UP */}
                            <div className="space-y-2">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Unidad Productiva / Cliente</Label>
                                <Input
                                    placeholder="Ej: Finca San José (Antioquia)"
                                    value={newVisit.fullName}
                                    onChange={(e) => setNewVisit({ ...newVisit, fullName: e.target.value })}
                                    className="h-14 rounded-2xl border-slate-100 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-lg font-bold"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                {/* Selección de Región / Departamento */}
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Región / Depto</Label>
                                    <Select onValueChange={(val) => setNewVisit({ ...newVisit, regionId: val, municipalityId: '' })}>
                                        <SelectTrigger className="h-14 rounded-2xl border-slate-100 bg-slate-50 dark:bg-slate-800 font-bold text-sm">
                                            <SelectValue placeholder="Seleccionar" />
                                        </SelectTrigger>
                                        <SelectContent className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-[0_20px_50px_rgba(0,0,0,0.3)] z-[100] focus:ring-0">
                                            {regions.map(r => (
                                                <SelectItem key={r.id} value={r.id} className="font-bold">{r.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                {/* Selección de Municipio */}
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Municipio</Label>
                                    {!isManualMode ? (
                                        <Select
                                            disabled={!newVisit.regionId}
                                            onValueChange={(val) => {
                                                if (val === 'MANUAL') {
                                                    setIsManualMode(true);
                                                    setNewVisit({ ...newVisit, municipalityId: '' });
                                                } else {
                                                    setNewVisit({ ...newVisit, municipalityId: val });
                                                }
                                            }}
                                        >
                                            <SelectTrigger className="h-14 rounded-2xl border-slate-100 bg-slate-50 dark:bg-slate-800 font-bold text-sm">
                                                <SelectValue placeholder="Seleccionar" />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-[0_20px_50px_rgba(0,0,0,0.3)] z-[100] focus:ring-0">
                                                {municipalities.map(m => (
                                                    <SelectItem key={m.id} value={m.id} className="font-bold">{m.name}</SelectItem>
                                                ))}
                                                <SelectItem value="MANUAL" className="text-blue-600 font-black">+ Otro (Ingresar manual)</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    ) : (
                                        <div className="relative">
                                            <Input
                                                placeholder="Nombre municipio"
                                                value={newVisit.manualMunicipality}
                                                onChange={(e) => setNewVisit({ ...newVisit, manualMunicipality: e.target.value })}
                                                className="h-14 rounded-2xl border-blue-200 bg-blue-50/30 text-sm font-bold pr-10"
                                            />
                                            <button
                                                onClick={() => setIsManualMode(false)}
                                                className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-black text-blue-600 uppercase"
                                            >
                                                Lista
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Fecha y Hora */}
                            <div className="space-y-2">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Fecha y Hora Programada</Label>
                                <div className="relative">
                                    <Input
                                        type="datetime-local"
                                        value={newVisit.scheduledAt}
                                        onChange={(e) => setNewVisit({ ...newVisit, scheduledAt: e.target.value })}
                                        className="h-14 rounded-2xl border-slate-100 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-lg font-bold pl-12"
                                    />
                                    <CalendarIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                                </div>
                            </div>

                            <Button
                                onClick={handleCreateVisit}
                                className="w-full h-16 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-base font-black uppercase tracking-widest mt-4 shadow-xl shadow-blue-600/20 active:scale-95 transition-all"
                            >
                                Confirmar Ruta y Programar
                            </Button>
                        </div>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="space-y-4">
                {todayVisits.length === 0 && upcomingVisits.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
                        <div className="h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-3xl">
                            📭
                        </div>
                        <div>
                            <p className="text-lg font-black text-slate-900 dark:text-white uppercase tracking-tight">Sin misiones</p>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">No se encontraron resultados para los filtros</p>
                        </div>
                    </div>
                ) : (
                    <>
                        {todayVisits.length > 0 && (
                            <div className="space-y-4">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 pl-2">Hoy</Label>
                                {todayVisits.map((visit) => renderVisitItem(visit))}
                            </div>
                        )}
                        {upcomingVisits.length > 0 && (
                            <div className="space-y-4 mt-8">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 pl-2">Próximas / Otros días</Label>
                                {upcomingVisits.map((visit) => renderVisitItem(visit))}
                            </div>
                        )}
                    </>
                )}
            </div>

            <div className="mt-auto pb-4 text-center space-y-2 opacity-60">
                <div className="flex items-center justify-center gap-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <span className="flex items-center gap-2"><ArrowLeftRight className="h-3 w-3" /> Swipe ← Reprogramar</span>
                    <span className="flex items-center gap-2">Tap → Ingresar</span>
                </div>
            </div>
        </div>
    );
}
