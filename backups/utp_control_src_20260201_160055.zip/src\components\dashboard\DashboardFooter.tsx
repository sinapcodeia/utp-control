'use client';


import Link from 'next/link';
import { Shield, Scale, FileText } from 'lucide-react';
import { useState } from 'react';
import { TermsModal } from '@/components/legal/TermsModal';

export function DashboardFooter() {
    const currentYear = new Date().getFullYear();
    const [modalConfig, setModalConfig] = useState<{
        open: boolean;
        tab: 'terms' | 'privacy' | 'security';
    }>({ open: false, tab: 'terms' });

    const openModal = (tab: 'terms' | 'privacy' | 'security') => {
        setModalConfig({ open: true, tab });
    };

    return (
        <>
            <TermsModal
                open={modalConfig.open}
                onOpenChange={(open) => setModalConfig(prev => ({ ...prev, open }))}
                defaultTab={modalConfig.tab}
                readOnly={true}
            />
            <footer className="mt-20 border-t border-slate-200 dark:border-slate-800 bg-gradient-to-br from-slate-50 to-white dark:from-slate-900 dark:to-slate-950">
                <div className="container mx-auto px-6 py-12">
                    <div className="flex flex-col md:flex-row justify-between gap-12 lg:gap-24">
                        {/* Company Info */}
                        <div className="space-y-4 max-w-sm">
                            <div className="flex items-center gap-2">
                                <div className="h-10 w-10 rounded-xl bg-blue-600 flex items-center justify-center">
                                    <Shield className="h-6 w-6 text-white" />
                                </div>
                                <span className="font-black text-lg uppercase tracking-tight">UTP Control</span>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                                Sistema de Gestión Regional - Plataforma de inteligencia operativa para la coordinación territorial.
                            </p>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-12 lg:gap-24">
                            {/* Legal */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-black uppercase tracking-widest text-slate-400">Marcos Legales</h4>
                                <ul className="space-y-2 text-xs">
                                    <li>
                                        <button
                                            onClick={() => openModal('privacy')}
                                            className="text-slate-600 dark:text-slate-300 hover:text-blue-600 transition-colors font-medium text-left"
                                        >
                                            Privacidad
                                        </button>
                                    </li>
                                    <li>
                                        <button
                                            onClick={() => openModal('terms')}
                                            className="text-slate-600 dark:text-slate-300 hover:text-blue-600 transition-colors font-medium text-left"
                                        >
                                            Términos
                                        </button>
                                    </li>
                                    <li>
                                        <button
                                            onClick={() => openModal('security')}
                                            className="text-slate-600 dark:text-slate-300 hover:text-blue-600 transition-colors font-medium text-left"
                                        >
                                            Seguridad
                                        </button>
                                    </li>
                                </ul>
                            </div>

                            {/* Contact */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-black uppercase tracking-widest text-slate-400">Información</h4>
                                <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
                                    <p className="font-medium">Sistema empresarial de gestión territorial</p>
                                    <p>v1.0.0 - Build 2026.01</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Bottom Bar */}
                    <div className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800">
                        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
                            <div className="text-slate-500 dark:text-slate-400 font-medium tracking-wide w-full text-center md:text-left">
                                © {currentYear} <a href="https://sinap-code.vercel.app/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-600 transition-colors">SINAPCODE</a> | CONTROL UTP. Licenciado bajo términos corporativos.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </>
    );
}

