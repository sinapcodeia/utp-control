
'use client';

import { use, useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, FileDown, Save, Share2, History, UserCheck, ShieldCheck, Clock, Download } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from 'next/navigation';
import { useCurrentUser } from "@/hooks/useCurrentUser";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

export default function ReportDetailPage({ params }: { params: Promise<{ id: string }> }) {
    const { user: currentUser, supabase } = useCurrentUser();
    const router = useRouter();
    const resolvedParams = use(params);
    const reportId = resolvedParams.id;

    // State for the report
    const [report, setReport] = useState<any>({
        id: reportId || 'INF-000',
        title: 'Cargando...',
        author: '',
        type: 'General',
        status: 'Aprobado',
        date: new Date().toISOString().split('T')[0],
        content: '',
        attachment: null
    });

    const [loading, setLoading] = useState(true);

    // Security check
    const isOwnerOrAdmin = currentUser?.role === 'ADMIN' || report.author === currentUser?.full_name;

    // Load data from API on mount
    useEffect(() => {
        const fetchReport = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/reports/${reportId}`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });
                if (response.ok) {
                    const data = await response.json();
                    setReport({
                        id: data.code,
                        dbId: data.id,
                        title: data.metadata?.title || `${data.type} - Informe`,
                        author: data.generatedBy?.fullName || 'Sistema',
                        type: data.type,
                        status: 'Aprobado',
                        date: new Date(data.generatedAt).toISOString().split('T')[0],
                        content: data.metadata?.content || '',
                        attachment: data.url ? { name: 'Documento Oficial', size: 'PDF' } : null
                    });
                }
            } catch (error) {
                console.error("Error al obtener el informe:", error);
                toast.error("Error al conectar con la bóveda de informes");
            } finally {
                setLoading(false);
            }
        };
        fetchReport();
    }, [reportId]);

    const [file, setFile] = useState<{ name: string, size: string } | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (!selectedFile) return;

        // 5MB Limit Validation (5 * 1024 * 1024 bytes)
        const MAX_SIZE = 5 * 1024 * 1024;

        if (selectedFile.type !== 'application/pdf') {
            toast.error("Formato no válido", {
                description: "Por favor, sube solo archivos en formato PDF."
            });
            return;
        }

        if (selectedFile.size > MAX_SIZE) {
            toast.error("Archivo demasiado grande", {
                description: "El límite máximo es de 5MB por informe."
            });
            return;
        }

        // Update local state and include in persistence
        setReport((prev: any) => ({
            ...prev,
            attachment: {
                name: selectedFile.name,
                size: (selectedFile.size / (1024 * 1024)).toFixed(2) + " MB"
            }
        }));

        toast.success("Archivo adjunto", {
            description: `${selectedFile.name} se ha cargado correctamente.`
        });
    };

    const triggerUpload = () => {
        fileInputRef.current?.click();
    };


    const handleSave = () => {
        // Save to localStorage
        const saved = localStorage.getItem('utp_reports');
        if (saved) {
            let allReports = JSON.parse(saved);
            const index = allReports.findIndex((r: any) => r.id === report.id);

            if (index !== -1) {
                // Update existing
                allReports[index] = { ...allReports[index], ...report };
            } else {
                // Add new if not found
                allReports = [report, ...allReports];
            }

            localStorage.setItem('utp_reports', JSON.stringify(allReports));
        }

        toast.success("Informe guardado exitosamente", {
            description: "Los cambios han sido persistidos correctamente.",
            duration: 2000,
        });

        // Redirect after a short delay
        setTimeout(() => {
            router.push('/dashboard/reports');
        }, 1000);
    };

    const handleShare = async () => {
        const shareData = {
            title: report.title,
            text: `Revisa este informe: ${report.title}`,
            url: window.location.href,
        };

        try {
            if (navigator.share) {
                await navigator.share(shareData);
                toast.success("Abriendo menú de compartir");
            } else {
                await navigator.clipboard.writeText(window.location.href);
                toast.success("Enlace copiado", {
                    description: "El enlace al informe se ha copiado al portapapeles."
                });
            }
        } catch (err) {
            console.error("Error al compartir:", err);
        }
    };

    const handleDownloadAttachment = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (!report.attachment) return;

        // Simulate downloading the stored PDF
        const content = "Simulated PDF content for: " + report.attachment.name;
        const blob = new Blob([content], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = report.attachment.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        toast.success("Descargando archivo adjunto", {
            description: report.attachment.name
        });
    };

    return (
        <div className="space-y-6" suppressHydrationWarning>
            <div className="flex items-center gap-4">
                <Link href="/dashboard/reports">
                    <Button variant="outline" size="icon" className="rounded-xl border-slate-200 bg-white/50 backdrop-blur-sm hover:bg-slate-100">
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                </Link>
                <div className="flex-1">
                    <h2 className="text-3xl font-bold tracking-tighter text-slate-900 dark:text-slate-50">{report.title}</h2>
                    <div className="flex items-center gap-2 text-sm text-slate-500/80 font-medium">
                        <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded dark:bg-slate-800">{report.id}</span>
                        <span>•</span>
                        <span>{report.date}</span>
                        <span>•</span>
                        <span className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">
                            {report.status}
                        </span>
                    </div>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" className="rounded-xl border-slate-200 bg-white/50 backdrop-blur-sm font-bold gap-2" onClick={handleShare}>
                        <Share2 className="h-4 w-4" />
                        Compartir
                    </Button>
                    {isOwnerOrAdmin ? (
                        <Button onClick={handleSave} className="rounded-xl font-bold gap-2 shadow-lg shadow-blue-500/20">
                            <Save className="h-4 w-4" />
                            Guardar Cambios
                        </Button>
                    ) : (
                        <div className="flex gap-2">
                            <Button onClick={() => toast.error("Función de rechazo no implementada")} variant="outline" className="rounded-xl font-bold text-red-600 border-red-100 hover:bg-red-50">
                                Rechazar
                            </Button>
                            <Button onClick={() => toast.success("Informe Aprobado")} className="rounded-xl font-bold bg-green-600 hover:bg-green-700 shadow-lg shadow-green-500/20">
                                Aprobar Informe
                            </Button>
                        </div>
                    )}
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
                <div className="md:col-span-2 space-y-6">
                    <Card className="premium-card">
                        <CardHeader className="border-b border-slate-50 dark:border-slate-900/50">
                            <CardTitle className="text-lg font-bold">Contenido del Informe</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6 pt-6">
                            <div className="space-y-2">
                                <Label className="text-xs font-bold uppercase tracking-widest text-slate-500">Título Principal</Label>
                                <Input
                                    value={report.title}
                                    onChange={(e) => setReport({ ...report, title: e.target.value })}
                                    disabled={!isOwnerOrAdmin}
                                    className="rounded-xl border-slate-200 bg-white/50 focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-lg disabled:opacity-80 disabled:bg-slate-50"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label className="text-xs font-bold uppercase tracking-widest text-slate-500">Cuerpo del Informe</Label>
                                <Textarea
                                    className="min-h-[450px] resize-y font-sans text-base leading-relaxed rounded-xl border-slate-200 bg-white/50 focus:ring-4 focus:ring-blue-500/10 transition-all disabled:opacity-100 disabled:select-text disabled:bg-slate-50/30"
                                    placeholder="Escribe aquí los detalles del informe..."
                                    value={report.content}
                                    onChange={(e) => setReport({ ...report, content: e.target.value })}
                                    disabled={!isOwnerOrAdmin}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="premium-card">
                        <CardHeader className="border-b border-slate-50 dark:border-slate-900/50">
                            <CardTitle className="text-sm font-bold uppercase tracking-widest">Configuración</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-5 pt-5">
                            <div className="space-y-2">
                                <Label className="text-xs font-bold text-slate-500">Tipo de Informe</Label>
                                <Select
                                    value={report.type}
                                    onValueChange={(val) => setReport({ ...report, type: val })}
                                    disabled={!isOwnerOrAdmin}
                                >
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl z-[150]">
                                        <SelectItem value="General" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">General</SelectItem>
                                        <SelectItem value="Regional" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Regional</SelectItem>
                                        <SelectItem value="Alert" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Seguridad</SelectItem>
                                        <SelectItem value="Audit" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Auditoría</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>Estado</Label>
                                <Select
                                    value={report.status}
                                    onValueChange={(val) => setReport({ ...report, status: val })}
                                    disabled={!isOwnerOrAdmin}
                                >
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl z-[150]">
                                        <SelectItem value="Draft" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Borrador</SelectItem>
                                        <SelectItem value="Review" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">En Revisión</SelectItem>
                                        <SelectItem value="Approved" className="py-2.5 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Aprobado</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="pt-5 border-t border-slate-100 dark:border-slate-800">
                                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-3">Archivos Adjuntos (PDF)</h4>
                                <div className="space-y-4">
                                    <input
                                        type="file"
                                        ref={fileInputRef}
                                        className="hidden"
                                        accept=".pdf"
                                        onChange={handleFileChange}
                                    />
                                    <div
                                        onClick={isOwnerOrAdmin ? triggerUpload : undefined}
                                        className={`rounded-xl border-2 border-dashed border-slate-200 p-8 text-center text-sm text-slate-500 transition-all flex flex-col items-center justify-center gap-3 group 
                                            ${isOwnerOrAdmin ? 'hover:bg-blue-50/50 hover:border-blue-400/50 hover:text-blue-600 cursor-pointer' : 'opacity-50 cursor-not-allowed'}`}
                                    >
                                        <div className="h-12 w-12 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                                            <FileDown className="h-6 w-6 text-slate-400 group-hover:text-blue-600" />
                                        </div>
                                        <div className="space-y-1">
                                            <p className="font-bold">{isOwnerOrAdmin ? 'Haz clic para subir documento' : 'Solo el autor puede adjuntar'}</p>
                                            <p className="text-[10px] uppercase tracking-widest opacity-60">Formato PDF máximo 5MB</p>
                                        </div>
                                    </div>

                                    {report.attachment && (
                                        <div className="flex items-center gap-4 rounded-xl border border-slate-100 p-4 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900/50 animate-fade-in animate-slide-in">
                                            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400">
                                                <span className="font-bold text-[10px]">PDF</span>
                                            </div>
                                            <div className="flex-1 overflow-hidden">
                                                <p className="truncate text-sm font-bold text-slate-900 dark:text-slate-100">
                                                    {report.attachment.name}
                                                </p>
                                                <p className="text-xs font-medium text-slate-400">{report.attachment.size} • Guardado</p>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="rounded-full h-8 w-8 text-blue-600 hover:bg-blue-50"
                                                    title="Descargar anexo"
                                                    onClick={handleDownloadAttachment}
                                                >
                                                    <Download className="h-4 w-4" />
                                                </Button>
                                                {isOwnerOrAdmin && (
                                                    <Button
                                                        variant="ghost"
                                                        size="icon"
                                                        className="rounded-full h-8 w-8 text-slate-400 hover:text-red-600 hover:bg-red-50"
                                                        title="Eliminar anexo"
                                                        onClick={() => setReport((prev: any) => ({ ...prev, attachment: null }))}
                                                    >
                                                        <span className="text-xl">×</span>
                                                    </Button>
                                                )}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    <Card className="premium-card shadow-lg shadow-blue-500/5">
                        <CardHeader className="pb-3 border-b border-slate-50 dark:border-slate-900/50 mb-4">
                            <CardTitle className="text-sm flex items-center gap-2">
                                <ShieldCheck className="h-4 w-4 text-blue-600" />
                                Auditoría & Trazabilidad
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {/* Responsables */}
                            <div className="space-y-4">
                                <div className="flex items-start gap-3">
                                    <div className="mt-1 h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center dark:bg-slate-800">
                                        <History className="h-4 w-4 text-slate-500" />
                                    </div>
                                    <div>
                                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Generado por</p>
                                        <p className="text-sm font-medium">{report.author || 'Sistema'}</p>
                                        <p className="text-[10px] text-slate-400 font-mono">ID: USER-{report.author === 'Carlos Pérez' ? '9823-XYZ' : '0044-ABC'}</p>
                                    </div>
                                </div>

                                {report.status === 'Approved' && (
                                    <div className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-100 dark:bg-green-900/10 dark:border-green-900/20">
                                        <div className="mt-1 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center dark:bg-green-900/30">
                                            <UserCheck className="h-4 w-4 text-green-600" />
                                        </div>
                                        <div>
                                            <p className="text-xs font-semibold text-green-700 uppercase tracking-wider dark:text-green-500">Aprobado por</p>
                                            <p className="text-sm font-bold text-green-900 dark:text-green-100">Dra. Ana Marina (SIA)</p>
                                            <p className="text-[10px] text-green-600 font-mono">Firma: 0x8F2A...E4B1</p>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Línea de Tiempo */}
                            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Historial de Eventos</h4>
                                <div className="space-y-4">
                                    <div className="relative pl-6 before:absolute before:left-[7px] before:top-2 before:bottom-0 before:w-0.5 before:bg-slate-100 dark:before:bg-slate-800">
                                        <div className="absolute left-0 top-1 h-3.5 w-3.5 rounded-full border-2 border-slate-100 bg-white dark:border-slate-800 dark:bg-slate-950" />
                                        <p className="text-xs font-medium">Reporte Editado</p>
                                        <p className="text-[10px] text-slate-400">Hace 15 minutos • Carlos Pérez</p>
                                    </div>

                                    <div className="relative pl-6 before:absolute before:left-[7px] before:top-2 before:bottom-0 before:w-0.5 before:bg-slate-100 dark:before:bg-slate-800">
                                        <div className="absolute left-0 top-1 h-3.5 w-3.5 rounded-full border-2 border-slate-100 bg-white dark:border-slate-800 dark:bg-slate-950" />
                                        <p className="text-xs font-medium">Adjunto subido: prueba.pdf</p>
                                        <p className="text-[10px] text-slate-400">Hace 1 hora • Carlos Pérez</p>
                                    </div>

                                    <div className="relative pl-6">
                                        <div className="absolute left-0 top-1 h-3.5 w-3.5 rounded-full border-2 border-blue-500 bg-blue-50 dark:bg-blue-900/20" />
                                        <p className="text-xs font-medium">Creación inicial</p>
                                        <p className="text-[10px] text-slate-400">22 Ene, 2026 • Sistema Central</p>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
