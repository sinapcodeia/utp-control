'use client';

import { useEffect } from 'react';

/**
 * Suprime warnings de hidratación causados por extensiones del navegador
 * que inyectan atributos como bis_skin_checked, data-darkreader, etc.
 */
export function SuppressHydrationWarning() {
    useEffect(() => {
        // Suprimir solo warnings específicos de extensiones del navegador
        const originalConsoleError = console.error;

        console.error = (...args) => {
            const errorMessage = args[0]?.toString() || '';

            // Suprimir warnings de hidratación causados por extensiones
            if (
                errorMessage.includes('bis_skin_checked') ||
                errorMessage.includes('data-darkreader') ||
                errorMessage.includes('browser extension') ||
                (errorMessage.includes('hydration') && errorMessage.includes('attribute'))
            ) {
                return; // Ignorar estos warnings
            }

            // Mostrar todos los demás errores
            originalConsoleError(...args);
        };

        return () => {
            console.error = originalConsoleError;
        };
    }, []);

    return null;
}
