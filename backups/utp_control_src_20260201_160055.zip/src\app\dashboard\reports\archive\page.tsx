'use client';

import { useState, useEffect } from 'react';
import { useCurrentUser } from "@/hooks/useCurrentUser";
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Folder, ChevronRight, FileText, Search, Briefcase, MapPin, Calendar, User } from "lucide-react";
import { Input } from "@/components/ui/input";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

export default function ReportsArchivePage() {
    const { user: currentUser, supabase } = useCurrentUser();
    const [hierarchy, setHierarchy] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [path, setPath] = useState<string[]>([]); // [Region, Municipality]
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchHierarchy = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/reports/hierarchy`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    setHierarchy(data);
                } else {
                    console.error('Error al cargar jerarquía:', response.status);
                }
            } catch (err) {
                console.error('Error de conexión:', err);
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchHierarchy();
        }
    }, [currentUser, supabase.auth]);

    if (!currentUser) {
        return <div className="flex items-center justify-center min-h-screen"><p className="text-slate-600">Cargando...</p></div>;
    }

    const getCurrentItems = () => {
        if (!hierarchy || hierarchy.message) return [];
        if (path.length === 0) return Object.keys(hierarchy).map(name => ({ type: 'region', name }));
        if (path.length === 1) return Object.keys(hierarchy[path[0]] || {}).map(name => ({ type: 'municipality', name }));

        const possibleItems = hierarchy[path[0]]?.[path[1]];
        if (path.length === 2 && Array.isArray(possibleItems)) {
            return possibleItems.filter((item: any) =>
                item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.type.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        return [];
    };

    if (loading) return <div className="p-20 text-center font-black animate-pulse text-slate-300 tracking-[0.5em]">ACCEDIENDO A LA BÓVEDA ESTRATÉGICA...</div>;

    const items = getCurrentItems();

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                    <Badge variant="outline" className="rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em]">
                        Archivo de Inteligencia Operativa
                    </Badge>
                    <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                        Bóveda de <span className="text-blue-600">Informes</span>
                    </h1>
                    <p className="text-slate-500 font-medium max-w-xl text-lg">
                        Trazabilidad absoluta de documentos oficiales procesados por el comando regional.
                    </p>
                </div>

                <Link href="/dashboard/reports">
                    <button className="h-12 px-8 rounded-2xl border border-slate-200 font-black uppercase tracking-widest text-[10px] hover:bg-slate-50 transition-all">
                        Volver al Buzón
                    </button>
                </Link>
            </div>

            <div className="bg-white/90 dark:bg-slate-950/50 backdrop-blur-2xl rounded-[3rem] border border-slate-100 dark:border-slate-800 p-10 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)]">
                <div className="flex items-center justify-between mb-10 overflow-x-auto pb-4">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setPath([])} className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-600 transition-colors">UTP ROOT</button>
                        {path.map((p, i) => (
                            <div key={i} className="flex items-center gap-2">
                                <ChevronRight className="h-4 w-4 text-slate-300" />
                                <button
                                    onClick={() => setPath(path.slice(0, i + 1))}
                                    className="text-[10px] font-black uppercase tracking-widest px-4 py-2 bg-blue-50 text-blue-700 rounded-xl"
                                >
                                    {p}
                                </button>
                            </div>
                        ))}
                    </div>
                    {path.length === 2 && (
                        <div className="relative">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                            <Input
                                placeholder="Buscar código o tipo..."
                                className="pl-12 w-72 rounded-2xl border-slate-100 dark:border-slate-800 h-12 text-xs font-bold"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {items.map((item: any, i: number) => {
                        const isFolder = path.length < 2;
                        return (
                            <div
                                key={i}
                                onClick={() => isFolder ? setPath([...path, item.name]) : window.open(item.url, '_blank')}
                                className={`group relative p-8 rounded-[2.5rem] transition-all duration-500 cursor-pointer border shadow-sm flex flex-col items-start
                                    ${isFolder
                                        ? 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-blue-400 hover:scale-[1.03] hover:shadow-2xl'
                                        : 'bg-slate-50 dark:bg-slate-900/50 border-transparent hover:bg-white dark:hover:bg-slate-800 hover:border-blue-200'}`}
                            >
                                <div className={`h-16 w-16 rounded-[1.5rem] flex items-center justify-center mb-6 transition-all group-hover:rotate-12 group-hover:scale-110 shadow-lg
                                    ${isFolder ? 'bg-blue-600 text-white shadow-blue-500/30' : 'bg-white dark:bg-slate-800 text-slate-500 shadow-slate-200/50'}`}>
                                    {isFolder ? <Folder className="h-8 w-8" /> : <Briefcase className="h-8 w-8 text-blue-600" />}
                                </div>

                                <div className="space-y-2 w-full">
                                    <h3 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight group-hover:text-blue-600 transition-colors truncate">
                                        {isFolder ? item.name : item.code}
                                    </h3>
                                    <div className="flex flex-col gap-1.5 pt-2">
                                        {isFolder ? (
                                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                                {item.type === 'region' ? 'Directorio Regional' : 'Archivos Municipales'}
                                            </p>
                                        ) : (
                                            <>
                                                <div className="flex items-center gap-2 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                                                    <Calendar className="h-3 w-3" /> {new Date(item.generatedAt).toLocaleDateString()}
                                                </div>
                                                <div className="flex items-center gap-2 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                                                    <User className="h-3 w-3" /> {item.generatedBy?.fullName}
                                                </div>
                                                <div className="flex items-center gap-2 text-[9px] font-black text-blue-600 uppercase tracking-widest mt-1">
                                                    <FileText className="h-3 w-3" /> {item.type === 'REGIONAL' ? 'REGIONAL' : item.type === 'AUDIT' ? 'AUDITORÍA' : item.type} (SHA-256)
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </div>

                                {isFolder && (
                                    <div className="absolute top-8 right-8 h-8 w-8 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                                        <ChevronRight className="h-4 w-4 text-blue-600" />
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

