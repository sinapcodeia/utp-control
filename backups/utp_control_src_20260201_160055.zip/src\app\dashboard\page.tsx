'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart3, FileText, ShieldAlert, Users, TrendingUp, Activity } from "lucide-react"
import { ActivityChart } from "@/components/dashboard/activity-chart"
import { Badge } from "@/components/ui/badge"
import { useState, useEffect } from 'react'
import { toast } from "sonner"
import { ShieldCheck, Send, Trash2, CheckCircle, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CoordinatorHome } from "@/components/dashboard/role-views/CoordinatorHome"
import { GestorHome } from "@/components/dashboard/role-views/GestorHome"
import { ApoyoHome } from "@/components/dashboard/role-views/ApoyoHome"
import { CLevelDashboard } from "@/components/dashboard/role-views/CLevelDashboard"
import { CEOHome } from "@/components/dashboard/role-views/CEOHome"
import { RoleSwitcher } from "@/components/dashboard/RoleSwitcher"
import { DashboardStats, RegionalReport, TCComplianceUser, UserRole } from "@/types"
import { useCurrentUser } from "@/hooks/useCurrentUser"
import { LoadingState } from "@/components/dashboard/LoadingState"
import { ProfileError } from "@/components/dashboard/ProfileError"
import { AlertCircle } from "lucide-react"
import { ProfileHero } from "@/components/dashboard/ProfileHero"
import { apiClient } from "@/lib/api-client"

export default function DashboardPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();
    const [effectiveRole, setEffectiveRole] = useState<UserRole | null>(null);
    const [stats, setStats] = useState<DashboardStats | null>(null);
    const [recentNews, setRecentNews] = useState<RegionalReport[]>([]);
    const [loading, setLoading] = useState(true);
    const [quickTitle, setQuickTitle] = useState('');
    const [isPublishing, setIsPublishing] = useState(false);
    const [tcCompliance, setTcCompliance] = useState<TCComplianceUser[]>([]);

    // Inicializar effectiveRole cuando el usuario cargue
    useEffect(() => {
        if (currentUser && !effectiveRole) {
            setEffectiveRole(currentUser.role);
        }
    }, [currentUser, effectiveRole]);

    useEffect(() => {
        if (!currentUser) return;

        const fetchData = async () => {
            try {
                const statsRes = await apiClient.get<DashboardStats>('/stats/dashboard');

                if (statsRes) {
                    setStats(statsRes);
                    setRecentNews(statsRes.recentNews || []);
                } else {
                    toast.error('Error al cargar estadísticas del dashboard');
                }

                // Obtener cumplimiento de T&C solo para roles ADMIN o GESTOR
                if (currentUser.role === 'ADMIN' || currentUser.role === 'GESTOR') {
                    const tcRes = await apiClient.get<TCComplianceUser[]>('/users/tc-compliance');
                    if (tcRes) {
                        setTcCompliance(tcRes);
                    }
                }
            } catch (error) {
                console.error('Error al obtener estadísticas del dashboard:', error);
                toast.error('Error de conectividad con el servidor');
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [currentUser]);

    const handleQuickPublish = async () => {
        if (!quickTitle.trim()) return;
        setIsPublishing(true);
        try {
            const response = await apiClient.post('/regional-reports', {
                category: 'OTHER',
                priority: 'HIGH',
                content: `COMUNICADO ADMINISTRATIVO: ${quickTitle}`,
                title: 'Aviso Central',
                regionId: null,
            });

            if (response) {
                const created = response as any;
                setRecentNews(prev => [created, ...prev.slice(0, 4)]);
                setQuickTitle('');
                toast.success("Comunicado Nacional publicado");
            }
        } catch (error) {
            toast.error("Error al publicar comunicado");
        } finally {
            setIsPublishing(false);
        }
    };

    const handleDeleteNews = async (id: string) => {
        try {
            await apiClient.delete(`/regional-reports/${id}`);
            setRecentNews(prev => prev.filter(n => n.id !== id));
            toast.error("Noticia eliminada");
        } catch (error) {
            toast.error("Error al eliminar");
        }
    };

    const handleRoleChange = (newRole: UserRole) => {
        setEffectiveRole(newRole);
        toast.info(`Vista cambiada a: ${newRole}`);
    };

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    return (
        <div className="space-y-10 animate-in fade-in duration-700 pb-20">
            {/* Brillo de fondo ambiental */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-40">
                <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-blue-500/10 blur-[120px] rounded-full" />
                <div className="absolute top-[20%] -right-[10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full" />
            </div>

            {currentUser.role === 'ADMIN' && (
                <RoleSwitcher currentRole={effectiveRole || currentUser.role} onRoleChange={handleRoleChange} />
            )}

            <ProfileHero user={currentUser} />

            {currentUser.role === 'ADMIN' && (
                <div className="relative z-10 flex justify-end">
                    <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-4 rounded-[2rem] border border-blue-100 dark:border-blue-900 shadow-xl flex items-center gap-4 transition-all hover:scale-105 duration-300">
                        <div className="h-10 w-10 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                            <Plus className="h-5 w-5" />
                        </div>
                        <div className="flex gap-2">
                            <Input
                                placeholder="Publicar aviso nacional..."
                                className="h-10 w-64 rounded-xl border-none bg-slate-50 dark:bg-slate-800 font-bold text-xs"
                                value={quickTitle}
                                onChange={(e) => setQuickTitle(e.target.value)}
                            />
                            <Button
                                className="h-10 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[10px]"
                                onClick={handleQuickPublish}
                                disabled={isPublishing || !quickTitle.trim()}
                            >
                                <Send className="h-3 w-3" />
                            </Button>
                        </div>
                    </div>
                </div>
            )}

            {loading ? (
                <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
                    <div className="h-12 w-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                    <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 animate-pulse">Sincronizando Inteligencia...</p>
                </div>
            ) : renderRoleContent(currentUser, effectiveRole || currentUser.role, stats, recentNews, tcCompliance, loading, handleDeleteNews)}
        </div>
    );
}

function renderRoleContent(
    currentUser: NonNullable<ReturnType<typeof useCurrentUser>['user']>,
    effectiveRole: UserRole,
    stats: DashboardStats | null,
    recentNews: RegionalReport[],
    tcCompliance: TCComplianceUser[],
    loading: boolean,
    handleDeleteNews: (id: string) => Promise<void>
) {
    switch (effectiveRole) {
        case 'COORDINATOR':
            return <CoordinatorHome stats={stats} recentNews={recentNews} user={{ id: currentUser.id, name: currentUser.full_name, role: currentUser.role, region: currentUser.region?.name || '' }} />;
        case 'GESTOR':
            return <GestorHome stats={stats} tcCompliance={tcCompliance} user={{ id: currentUser.id, name: currentUser.full_name || 'Gestor', role: currentUser.role, region: currentUser.region?.name }} />;
        case 'USER':
            return <GestorHome stats={stats} tcCompliance={tcCompliance} user={{ id: currentUser.id, name: currentUser.full_name || 'Gestor Operativo', role: currentUser.role, region: currentUser.region?.name }} />;
        case 'SUPPORT':
            return <ApoyoHome recentNews={recentNews} />;
        case 'ADMIN':
            return <CEOHome stats={stats} user={{ id: currentUser.id, name: currentUser.full_name, role: currentUser.role }} />;
        default:
            return (
                <>
                    <div className="space-y-4">
                        <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 pl-1">Resumen Ejecutivo</h3>
                        <div className="relative grid gap-6 md:grid-cols-2 lg:grid-cols-4 z-10">
                            {[
                                { title: "Informes Totales", value: stats?.totalReports || "0", trend: "Operativos", icon: FileText, color: "text-blue-600", bg: "bg-blue-50" },
                                { title: "Novedades Activas", value: stats?.activeNews || "0", trend: "Críticas", icon: ShieldAlert, color: "text-red-600", bg: "bg-red-50" },
                                { title: "Personal Operativo", value: stats?.totalUsers || "0", trend: "Sincronizado", icon: Users, color: "text-indigo-600", bg: "bg-indigo-50" },
                                { title: "Base Documental", value: stats?.totalDocuments || "0", trend: "Verificado", icon: BarChart3, color: "text-emerald-600", bg: "bg-emerald-50" }
                            ].map((stat, i) => (
                                <Card key={i} className="group relative overflow-hidden rounded-[2.5rem] border-none bg-white dark:bg-slate-900 shadow-xl transition-all duration-500 hover:-translate-y-1 hover:shadow-2xl">
                                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-8">
                                        <CardTitle className="text-[9px] font-black uppercase tracking-widest text-slate-400 font-sans">
                                            {stat.title}
                                        </CardTitle>
                                        <div className={`h-12 w-12 rounded-2xl ${stat.bg} dark:bg-slate-800 flex items-center justify-center transition-transform group-hover:scale-110`}>
                                            <stat.icon className={`h-6 w-6 ${stat.color}`} />
                                        </div>
                                    </CardHeader>
                                    <CardContent className="px-8 pb-8">
                                        <div className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter font-heading">
                                            {loading ? "..." : stat.value}
                                        </div>
                                        <div className="flex items-center gap-1.5 mt-2 text-[9px] font-black uppercase tracking-widest text-slate-400">
                                            <Activity className="h-3 w-3 text-blue-500 animate-pulse" />
                                            {stat.trend}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </div>

                    <div className="relative grid gap-8 md:grid-cols-2 lg:grid-cols-7 z-10">
                        <Card className="col-span-4 rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
                            <CardHeader className="p-10 pb-0 flex flex-row items-center justify-between">
                                <div>
                                    <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-600 mb-1">Inteligencia Operativa</h3>
                                    <CardTitle className="text-3xl font-black tracking-tighter uppercase text-slate-900 dark:text-white font-heading">
                                        Actividad <span className="text-slate-400">Global</span>
                                    </CardTitle>
                                </div>
                                <div className="h-14 w-14 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
                                    <TrendingUp className="h-7 w-7" />
                                </div>
                            </CardHeader>
                            <CardContent className="p-10 pt-6">
                                <ActivityChart />
                            </CardContent>
                        </Card>

                        <Card className="col-span-3 rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-2xl overflow-hidden flex flex-col">
                            <CardHeader className="p-10 pb-6">
                                <div className="flex items-center justify-between mb-2">
                                    <CardTitle className="text-2xl font-black tracking-tighter uppercase text-slate-900 dark:text-white font-heading">
                                        Centro de <span className="text-red-600">Alertas</span>
                                    </CardTitle>
                                    <ShieldCheck className="h-6 w-6 text-blue-600" />
                                </div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                    Novedades en tiempo real
                                </p>
                            </CardHeader>
                            <CardContent className="p-10 pt-0 flex-1">
                                <div className="space-y-4">
                                    {recentNews.length === 0 ? (
                                        <div className="text-center py-20 font-black text-slate-200 uppercase tracking-widest text-xs">Sin alertas activas</div>
                                    ) : recentNews.map((item: any) => (
                                        <div key={item.id} className="group/item flex items-center p-5 rounded-[2rem] bg-slate-50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 transition-all duration-500 border border-transparent hover:border-slate-100 dark:hover:border-slate-700 shadow-sm hover:shadow-xl">
                                            <div className="relative flex h-12 w-12 mr-5 shrink-0">
                                                <div className={`absolute inset-0 rounded-2xl ${item.priority === 'HIGH' ? 'bg-red-50' : 'bg-amber-50'} dark:bg-red-900/30 group-hover/item:scale-110 transition-transform duration-500`}></div>
                                                <div className={`relative h-full w-full flex items-center justify-center ${item.priority === 'HIGH' ? 'text-red-500' : 'text-amber-500'}`}>
                                                    <ShieldAlert className="h-6 w-6" />
                                                </div>
                                            </div>
                                            <div className="space-y-1 overflow-hidden">
                                                <p className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-tighter truncate">{item.content.split(': ')[0]}</p>
                                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                                    {item.region?.name || 'NACIONAL'} <span className="text-slate-200 mx-1">|</span> {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                </p>
                                            </div>
                                            <div className="ml-auto flex flex-col items-end gap-2">
                                                {currentUser.role === 'ADMIN' ? (
                                                    <div className="flex gap-1">
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="h-8 w-8 rounded-xl text-slate-300 hover:text-red-500 hover:bg-red-50 transition-all"
                                                            onClick={() => handleDeleteNews(item.id)}
                                                        >
                                                            <Trash2 className="h-4 w-4" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="h-8 w-8 rounded-xl text-slate-300 hover:text-green-500 hover:bg-green-50 transition-all"
                                                        >
                                                            <CheckCircle className="h-4 w-4" />
                                                        </Button>
                                                    </div>
                                                ) : (
                                                    <Badge variant="outline" className={`text-[8px] font-black uppercase tracking-widest rounded-lg ${item.priority === 'HIGH' ? 'border-red-100 bg-red-50 text-red-600' : 'border-amber-100 bg-amber-50 text-amber-600'}`}>
                                                        {item.priority}
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </>
            );
    }
}
