'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Bell, BellOff, X, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { createClient } from '@/utils/supabase/client';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';
const VAPID_PUBLIC_KEY = 'BEl62iUYgUivxIkv69yViEuiBIa-Ib37J8xYjEB6hvqRxYmjfIAjXbLNilO5Oy4Fj3qvnB2hhEAJmRYjqXhqE8s';

export function PushNotificationManager() {
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [isSupported, setIsSupported] = useState(false);
    const [loading, setLoading] = useState(true);
    const [showBanner, setShowBanner] = useState(false);

    useEffect(() => {
        if (typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window) {
            setIsSupported(true);
            checkSubscription();
        } else {
            setLoading(false);
        }
    }, []);

    const checkSubscription = async () => {
        try {
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            setIsSubscribed(!!subscription);

            // Si no está suscrito y no ha denegado permisos, mostrar banner sugerido
            if (!subscription && Notification.permission === 'default') {
                setShowBanner(true);
            }
        } catch (error) {
            console.error('Error checking push subscription', error);
        } finally {
            setLoading(false);
        }
    };

    const urlBase64ToUint8Array = (base64String: string) => {
        const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
        const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    };

    const subscribe = async () => {
        setLoading(true);
        try {
            const registration = await navigator.serviceWorker.ready;

            // Solicitar permiso explícito
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
                toast.error("Permiso de notificaciones denegado");
                return;
            }

            const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
            });

            // Enviar al backend
            const supabase = createClient();
            const { data: { session } } = await supabase.auth.getSession();

            const response = await fetch(`${API_URL}/notifications/subscribe`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session?.access_token}`
                },
                body: JSON.stringify(subscription)
            });

            if (response.ok) {
                setIsSubscribed(true);
                setShowBanner(false);
                toast.success("Notificaciones activadas correctamente");

                // Enviar notificación de prueba
                await fetch(`${API_URL}/notifications/test`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${session?.access_token}` }
                });
            } else {
                throw new Error("Error en el servidor");
            }
        } catch (error) {
            console.error('Error subscribing to push', error);
            toast.error("Error al activar notificaciones");
        } finally {
            setLoading(false);
        }
    };

    const unsubscribe = async () => {
        setLoading(true);
        try {
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            if (subscription) {
                await subscription.unsubscribe();

                const supabase = createClient();
                const { data: { session } } = await supabase.auth.getSession();

                await fetch(`${API_URL}/notifications/unsubscribe`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${session?.access_token}` }
                });
            }
            setIsSubscribed(false);
            toast.info("Notificaciones desactivadas");
        } catch (error) {
            console.error('Error unsubscribing', error);
            toast.error("Error al desactivar notificaciones");
        } finally {
            setLoading(false);
        }
    };

    if (!isSupported) return null;

    return (
        <>
            {/* Banner flotante discreto si no está suscrito */}
            {showBanner && (
                <div className="fixed bottom-6 right-6 z-[100] animate-in slide-in-from-bottom-10 fade-in duration-700">
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 max-w-sm">
                        <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                                <div className="h-10 w-10 rounded-2xl bg-blue-600/10 flex items-center justify-center text-blue-600">
                                    <Bell className="h-5 w-5" />
                                </div>
                                <div>
                                    <h4 className="text-sm font-black uppercase tracking-tight text-slate-900 dark:text-white">Activar Alertas</h4>
                                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Recibe novedades en tiempo real</p>
                                </div>
                            </div>
                            <button onClick={() => setShowBanner(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white">
                                <X className="h-5 w-5" />
                            </button>
                        </div>
                        <p className="text-xs text-slate-500 font-medium">
                            Mantente informado sobre alertas críticas de seguridad y clima en tu región directamente en tu dispositivo.
                        </p>
                        <Button
                            onClick={subscribe}
                            disabled={loading}
                            className="w-full h-12 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-[10px]"
                        >
                            {loading ? "Procesando..." : "Permitir Notificaciones"}
                        </Button>
                    </div>
                </div>
            )}

            {/* Selector en ajustes o perfil (opcional, podrías renderizarlo donde quieras) */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                    <div className={`h-10 w-10 rounded-2xl flex items-center justify-center transition-colors ${isSubscribed ? 'bg-emerald-500/10 text-emerald-600' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'}`}>
                        {isSubscribed ? <Bell className="h-5 w-5" /> : <BellOff className="h-5 w-5" />}
                    </div>
                    <div>
                        <p className="text-xs font-black uppercase tracking-widest text-slate-900 dark:text-white">Alertas Push</p>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">
                            {isSubscribed ? "Estado: Activo" : "Estado: Desactivado"}
                        </p>
                    </div>
                </div>
                <Button
                    size="sm"
                    variant={isSubscribed ? "outline" : "default"}
                    onClick={isSubscribed ? unsubscribe : subscribe}
                    disabled={loading}
                    className={`rounded-xl h-10 px-4 font-black uppercase tracking-widest text-[9px] ${isSubscribed ? 'border-red-200 text-red-600 hover:bg-red-50' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                >
                    {isSubscribed ? "Desactivar" : "Activar"}
                </Button>
            </div>
        </>
    );
}
