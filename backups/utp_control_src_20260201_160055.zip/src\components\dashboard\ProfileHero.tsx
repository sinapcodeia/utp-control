'use client';

import { Badge } from "@/components/ui/badge";
import { UserRole } from "@/types";
import { Shield, MapPin, Clock, Sparkles } from "lucide-react";

interface ProfileHeroProps {
    user: {
        full_name: string;
        role: string;
        region?: { name: string };
        municipality?: { name: string };
    };
}

export function ProfileHero({ user }: ProfileHeroProps) {
    const getGreeting = () => {
        const hour = new Date().getHours();
        if (hour < 12) return "Buenos días";
        if (hour < 18) return "Buenas tardes";
        return "Buenas noches";
    };

    const getRoleLabel = (role: string) => {
        switch (role) {
            case 'ADMIN': return 'Administrador Central';
            case 'COORDINATOR': return 'Coordinador Regional';
            case 'GESTOR': return 'Gestor de Campo';
            case 'USER': return 'Gestor Operativo';
            case 'SUPPORT': return 'Personal de Apoyo';
            default: return role;
        }
    };

    return (
        <div className="relative group overflow-hidden rounded-[3rem] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-2xl shadow-slate-200/50 dark:shadow-none transition-all duration-500 hover:shadow-blue-500/10">
            {/* Background Decorative Elements */}
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl group-hover:bg-blue-600/10 transition-all duration-700" />
            <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 bg-indigo-600/5 rounded-full blur-3xl group-hover:bg-indigo-600/10 transition-all duration-700" />

            <div className="relative z-10 p-6 md:p-8 flex flex-col md:flex-row items-center gap-6 md:gap-10">
                {/* Avatar / Initial Section */}
                <div className="relative shrink-0">
                    <div className="h-20 w-20 md:h-24 md:w-24 rounded-[1.5rem] bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white text-3xl md:text-4xl font-black shadow-2xl shadow-blue-500/30 rotate-3 group-hover:rotate-0 transition-transform duration-500">
                        {user.full_name.charAt(0)}
                    </div>
                </div>

                {/* Content Section */}
                <div className="flex-1 text-center md:text-left space-y-3">
                    <div className="space-y-0.5">
                        <div className="flex items-center justify-center md:justify-start gap-2 text-blue-600 dark:text-blue-400 font-bold uppercase tracking-[0.2em] text-[9px]">
                            <Sparkles className="h-3 w-3" />
                            <span>{getGreeting()}</span>
                        </div>
                        <h1 className="text-2xl md:text-4xl font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-tight">
                            {user.full_name || 'Agente'}
                        </h1>
                        <div className="flex items-center justify-center md:justify-start gap-1.5 text-[10px] font-black uppercase tracking-widest text-slate-500">
                            <Shield className="h-3 w-3 text-blue-500" />
                            <span>Perfil: {getRoleLabel(user.role)}</span>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
                        <Badge variant="outline" className="border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 px-3 py-1 rounded-lg font-bold uppercase tracking-widest text-[8px] flex items-center gap-1">
                            <MapPin className="h-2.5 w-2.5" />
                            {user.region?.name || 'Jurisdicción Nacional'}
                        </Badge>
                        {user.municipality && (
                            <Badge variant="outline" className="border-blue-100 bg-blue-50/30 text-blue-600 dark:border-blue-900/30 dark:bg-blue-900/10 px-3 py-1 rounded-lg font-bold uppercase tracking-widest text-[8px]">
                                {user.municipality.name}
                            </Badge>
                        )}
                    </div>
                </div>

                {/* Status / Meta Section */}
                <div className="shrink-0 w-full md:w-auto border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-800 pt-8 md:pt-0 md:pl-12 flex flex-row md:flex-col justify-around md:justify-center gap-6">
                    <div className="text-center md:text-left">
                        <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Estado</p>
                        <div className="flex items-center gap-2 justify-center md:justify-start">
                            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                            <span className="text-xs font-black uppercase text-slate-900 dark:text-white">Operativo</span>
                        </div>
                    </div>
                    <div className="text-center md:text-left">
                        <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Sincronización</p>
                        <div className="flex items-center gap-2 justify-center md:justify-start text-slate-500">
                            <Clock className="h-3 w-3" />
                            <span className="text-[10px] font-bold uppercase tracking-tighter">Hace 1m</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
