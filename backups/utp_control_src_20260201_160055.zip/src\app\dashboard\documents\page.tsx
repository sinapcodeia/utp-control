'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, FileText, MessageSquare, Clock, User, ArrowRight, Eye } from "lucide-react";
import Link from 'next/link';
import { Document } from "@/types";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";

export default function DocumentsPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();

    const [documents, setDocuments] = useState<Document[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);

    const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

    useEffect(() => {
        const fetchDocuments = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/documents`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });
                if (response.ok) {
                    const data: Document[] = await response.json();
                    setDocuments(data);
                } else {
                    toast.error('Error al cargar documentos');
                }
            } catch (error) {
                console.error('Error al obtener documentos:', error);
                toast.error('Error de conectividad con el servidor');
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchDocuments();
        }
    }, [API_URL, currentUser, supabase.auth]);

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    const filteredDocuments = documents.filter(doc =>
        (doc.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (doc.uploader?.fullName || '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                    <Badge variant="outline" className="rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em]">
                        Gestión Documental
                    </Badge>
                    <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                        Repositorio de <br /> <span className="text-blue-600">Documentos</span>
                    </h1>
                    <p className="text-slate-500 font-medium max-w-xl text-lg">
                        Documentación técnica e institucional con sistema de comentarios para trazabilidad operativa.
                    </p>
                </div>

                <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-4 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-xl flex items-center gap-4">
                    <div className="h-12 w-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white">
                        <FileText className="h-6 w-6" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Total Documentos</p>
                        <p className="text-2xl font-black text-slate-900 dark:text-white">{documents.length}</p>
                    </div>
                </div>
            </div>

            <div className="relative group">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-6 w-6 text-slate-400 group-focus-within:text-blue-600 transition-all duration-300" />
                <Input
                    placeholder="Buscar documentos por título o responsable..."
                    className="pl-16 h-18 rounded-[2rem] border-none bg-white/80 backdrop-blur-md shadow-2xl shadow-slate-200/50 focus:ring-[6px] focus:ring-blue-500/5 transition-all text-lg font-bold dark:bg-slate-900/80 dark:shadow-none dark:border dark:border-slate-800"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {loading ? (
                    Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="h-64 rounded-[2.5rem] bg-slate-100 dark:bg-slate-800 animate-pulse" />
                    ))
                ) : filteredDocuments.map((doc) => (
                    <Card key={doc.id} className="group relative overflow-hidden rounded-[2.5rem] border-none bg-white dark:bg-slate-900 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">
                        <CardHeader className="p-8 pb-4">
                            <div className="flex justify-between items-start mb-4">
                                <div className="h-14 w-14 rounded-2xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600">
                                    <FileText className="h-7 w-7" />
                                </div>
                                <Badge className="bg-slate-100 text-slate-500 border-none rounded-lg px-2 text-[8px] font-black uppercase tracking-widest">
                                    REV v1.0
                                </Badge>
                            </div>
                            <CardTitle className="text-xl font-black text-slate-900 group-hover:text-blue-600 transition-colors dark:text-white leading-tight">
                                {doc.title}
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-8 pt-0 space-y-6">
                            <div className="space-y-3">
                                <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    <User className="h-3 w-3 text-blue-500" />
                                    {doc.uploader?.fullName || 'Sistema'}
                                </div>
                                <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    <Clock className="h-3 w-3 text-blue-500" />
                                    {new Date(doc.createdAt).toLocaleDateString()}
                                </div>
                            </div>

                            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                                <div className="flex items-center gap-2">
                                    <MessageSquare className="h-4 w-4 text-blue-600" />
                                    <span className="text-xs font-black text-slate-600 dark:text-slate-300">
                                        {doc._count?.comments || 0} Comentarios
                                    </span>
                                </div>
                                <Link href={`/dashboard/documents/${doc.id}`}>
                                    <Button variant="ghost" size="icon" className="h-10 w-10 rounded-xl hover:bg-blue-600 hover:text-white transition-all">
                                        <ArrowRight className="h-4 w-4" />
                                    </Button>
                                </Link>
                            </div>

                            <Link href={`/dashboard/documents/${doc.id}`} className="block">
                                <Button className="w-full h-12 rounded-xl bg-slate-900 hover:bg-black text-white font-black uppercase tracking-widest text-[10px] gap-2">
                                    <Eye className="h-4 w-4" />
                                    Visualizar Documento
                                </Button>
                            </Link>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {!loading && filteredDocuments.length === 0 && (
                <div className="flex flex-col items-center justify-center py-40 bg-white/50 backdrop-blur-md rounded-[4rem] border border-dashed border-slate-200">
                    <Search className="h-20 w-20 text-slate-200 mb-6" />
                    <h3 className="text-2xl font-black text-slate-400 uppercase tracking-tighter">Sin documentos encontrados</h3>
                    <p className="text-slate-400 font-medium mt-2">Prueba con otros términos de búsqueda.</p>
                </div>
            )}
        </div>
    );
}
