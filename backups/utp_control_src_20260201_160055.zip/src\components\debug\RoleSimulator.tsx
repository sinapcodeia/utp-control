
'use client';

import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { AlertTriangle, Users, Shield, User, RefreshCw } from "lucide-react";
import { useEffect, useState } from 'react';
import { toast } from "sonner";

export function RoleSimulator() {
    // We intentionally peel off the 'real' user role check logic ourselves to avoid recursion if we used the simulated one here?
    // Actually useCurrentUser returns simulated one. We need to check if we are allowed to show this.
    // BUT: If permission logic inside useCurrentUser blocks 'ADMIN' check when simulated, we might lose this button!
    // FIX: The useCurrentUser hook implementation returns the simulated role. 
    // We need to know if the REAL user is admin. 
    // Since useCurrentUser mocks it, we might be hiding the simulator from ourselves if we simulate 'USER'!
    // 
    // SOLUTION: We trust the localStorage check here too or we rely on the fact that 
    // if we simulated 'USER', the permissions would hide this component. 
    // WAIT! If I simulate 'COORDINATOR', I lose ADMIN status. If this component only shows for ADMIN, it disappears!
    // 
    // CORRECT APPROACH: This component should ALWAYS render if:
    // 1. We are really ADMIN (requires checking non-simulated state? Tough without extra hook export).
    // 2. OR: We are currently in Simulation Mode (localStorage key exists).

    const checkIsActuallyAdminOrSimulating = () => {
        // This is a rough check. In a real app we'd export `realUser` from context.
        // For now, if 'dev_simulate_role' exists, we MUST show this to allow turning it off.
        if (typeof window !== 'undefined' && localStorage.getItem('dev_simulate_role')) return true;
        return false; // If not simulating, we rely on the parent to only render this for Admin.
    };

    const [isSimulating, setIsSimulating] = useState(false);
    const [currentRole, setCurrentRole] = useState<string>('ADMIN');

    useEffect(() => {
        const stored = localStorage.getItem('dev_simulate_role');
        if (stored) {
            setIsSimulating(true);
            setCurrentRole(stored);
        } else {
            setIsSimulating(false);
            setCurrentRole('ADMIN');
        }
    }, []);

    const handleSimulate = (role: string) => {
        if (role === 'OFF') {
            localStorage.removeItem('dev_simulate_role');
            toast.info("Simulación Desactivada", { description: "Volviendo a rol de Administrador Global." });
        } else {
            localStorage.setItem('dev_simulate_role', role);
            toast.warning("Simulación Activa", { description: `Interfaz ajustada a modo: ${role}` });
        }

        // Force reload to ensure all hooks/contexts refresh cleanly
        setTimeout(() => window.location.reload(), 500);
    };

    // If not simulating and probably not admin (this will be controlled by parent anyway), strict check:
    // Actually, asking parent component to render this conditionally is safer.

    return (
        <div className="px-4 py-2 mt-auto">
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button
                        variant={isSimulating ? "destructive" : "outline"}
                        className={`w-full justify-start gap-2 border-dashed ${isSimulating ? 'animate-pulse font-bold' : 'text-slate-400 border-slate-300'}`}
                    >
                        {isSimulating ? <AlertTriangle className="h-4 w-4" /> : <RefreshCw className="h-4 w-4" />}
                        <span className="truncate">
                            {isSimulating ? `Modo: ${currentRole}` : 'Simular Rol'}
                        </span>
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                        <div className="flex flex-col space-y-1">
                            <p className="text-sm font-medium leading-none">Developer Mode</p>
                            <p className="text-xs leading-none text-muted-foreground">
                                Vista previa de permisos
                            </p>
                        </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handleSimulate('OFF')} className="text-red-600 focus:text-red-600 focus:bg-red-50">
                        <Shield className="mr-2 h-4 w-4" />
                        <span>Desactivar (Soy Admin)</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handleSimulate('COORDINATOR')}>
                        <Users className="mr-2 h-4 w-4" />
                        <span>Coordinador (Regional)</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSimulate('GESTOR')}>
                        <User className="mr-2 h-4 w-4" />
                        <span>Gestor (Operativo)</span>
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>

            {isSimulating && (
                <p className="text-[9px] text-red-500 font-bold text-center mt-2 uppercase tracking-widest animate-pulse">
                    ⚠ Entorno Simulado
                </p>
            )}
        </div>
    );
}
