'use client';

import { Button } from "@/components/ui/button";
import { FileText, Mail, Share2, Download } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { createClient } from "@/utils/supabase/client";
import { toast } from "sonner";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

import { useCurrentUser } from "@/hooks/useCurrentUser";

export function ReportsView() {
    const { user: currentUser, supabase } = useCurrentUser();
    const [sharing, setSharing] = useState(false);
    const [lastAction, setLastAction] = useState<string | null>(null);

    // Wireframe 11: Generación de Informes
    return (
        <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 p-6 animate-in slide-in-from-right">
            <div className="mt-4 mb-8">
                <h1 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Informes</h1>
            </div>

            <div className="space-y-6">
                <div className="p-6 bg-blue-50 dark:bg-blue-900/10 rounded-[2rem] border border-blue-100 dark:border-blue-800">
                    <p className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-[0.2em] mb-2">Estado de Generación</p>
                    <p className="text-sm font-bold text-slate-600 dark:text-slate-400">Los informes se consolidan automáticamente cada 24 horas basándose en tus visitas sincronizadas.</p>
                </div>

                <div className="grid gap-4">
                    {[
                        { type: 'Diario', desc: 'Resumen de actividad de hoy' },
                        { type: 'Semanal', desc: 'Consolidado de la semana actual' },
                        { type: 'Mensual', desc: 'Reporte ejecutivo del mes' }
                    ].map((report) => (
                        <div key={report.type} className="group p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
                            <div className="flex items-center justify-between mb-4">
                                <div className="flex items-center gap-4">
                                    <div className="h-10 w-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center">
                                        <FileText className="h-5 w-5 text-slate-400" />
                                    </div>
                                    <div>
                                        <span className="block text-lg font-black text-slate-900 dark:text-white leading-tight">{report.type}</span>
                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{report.desc}</span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1">
                                    <Button
                                        onClick={async () => {
                                            try {
                                                const { data: { session } } = await supabase.auth.getSession();
                                                const token = session?.access_token;

                                                if (!token) {
                                                    toast.error("Sesión expirada. Por favor reingresa.");
                                                    return;
                                                }

                                                const res = await fetch(`${API_URL}/reports/${report.type.toLowerCase()}/pdf`, {
                                                    headers: { 'Authorization': `Bearer ${token}` }
                                                });
                                                if (!res.ok) throw new Error('Error generando PDF');
                                                const blob = await res.blob();
                                                const url = window.URL.createObjectURL(blob);
                                                const a = document.createElement('a');
                                                a.href = url;
                                                a.download = `Reporte_${report.type}_${new Date().toISOString().slice(0, 10)}.pdf`;
                                                document.body.appendChild(a);
                                                a.click();
                                                window.URL.revokeObjectURL(url);
                                                toast.success(`${report.type} descargado correctamente`);
                                            } catch (e) {
                                                console.error(e);
                                                toast.error('Error al descargar el reporte');
                                            }
                                        }}
                                        size="icon"
                                        variant="ghost"
                                        className="rounded-full text-emerald-600 hover:bg-emerald-50"
                                    >
                                        <Download className="h-5 w-5" />
                                    </Button>
                                    <Button
                                        onClick={() => {
                                            setLastAction(report.type);
                                            setSharing(true);
                                        }}
                                        size="icon"
                                        variant="ghost"
                                        className="rounded-full text-blue-600 hover:bg-blue-50"
                                    >
                                        <Share2 className="h-5 w-5" />
                                    </Button>
                                </div>
                            </div>
                            <Button
                                onClick={() => {
                                    setLastAction(report.type);
                                    setSharing(true);
                                }}
                                variant="outline"
                                className="w-full h-10 rounded-xl border-slate-100 dark:border-slate-800 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-600 transition-colors"
                            >
                                Preparar Documento
                            </Button>
                        </div>
                    ))}
                </div>
            </div>

            {/* Wireframe 12: Compartir Informe (Modal/Dialog Simulation) */}
            <Dialog open={sharing} onOpenChange={setSharing}>
                <DialogContent className="max-w-xs rounded-3xl p-6 bg-white dark:bg-slate-950 border-none shadow-2xl">
                    <DialogHeader className="text-center mb-6">
                        <DialogTitle className="text-xl font-black uppercase tracking-tight mb-1">Compartir informe</DialogTitle>
                    </DialogHeader>

                    <div className="space-y-3">
                        <Button
                            variant="outline"
                            className="w-full h-14 rounded-2xl justify-start pl-6 gap-4 border-2 border-slate-100 dark:border-slate-800 text-slate-600 font-bold"
                            onClick={() => {
                                const subject = encodeURIComponent(`Informe UTP Control - ${lastAction}`);
                                const body = encodeURIComponent(`Hola, adjunto el resumen del informe ${lastAction} generado desde la plataforma UTP Control.`);
                                window.open(`mailto:?subject=${subject}&body=${body}`);
                            }}
                        >
                            <Mail className="h-5 w-5" /> Correo electrónico
                        </Button>
                        <Button
                            variant="outline"
                            className="w-full h-14 rounded-2xl justify-start pl-6 gap-4 border-2 border-slate-100 dark:border-slate-800 text-slate-600 font-bold"
                            onClick={() => {
                                const text = encodeURIComponent(`Hola, te comparto el informe *${lastAction}* de la plataforma UTP Control.`);
                                window.open(`https://wa.me/?text=${text}`);
                            }}
                        >
                            <Share2 className="h-5 w-5" /> WhatsApp
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}
