'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Clock, AlertTriangle, Send, Camera, Map, Target, Zap } from "lucide-react"
import { Task, RegionalReport } from "@/types"

interface ApoyoHomeProps {
    recentNews: RegionalReport[];
}

export function ApoyoHome({ recentNews }: ApoyoHomeProps) {
    const mockTasks: Task[] = [
        { id: 1, title: 'Verificar Alerta Clima', area: 'Sector Norte', priority: 'High', due: 'Inmediato' },
        { id: 2, title: 'Enviar Registro Fotográfico', area: 'Km 45 - Vía Central', priority: 'Medium', due: '15 min' },
        { id: 3, title: 'Sincronizar Ubicación GPS', area: 'Base Operacional', priority: 'Low', due: 'Fin de turno' },
    ];

    return (
        <div className="space-y-8 animate-in slide-in-from-bottom-6 duration-700">
            {/* Operational Action Banner */}
            <div className="bg-slate-900 dark:bg-slate-950 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl border border-white/5">
                <div className="absolute right-0 top-0 p-8 opacity-10">
                    <Zap className="h-32 w-32 text-amber-400 animate-pulse" />
                </div>
                <div className="relative z-10">
                    <div className="flex items-center gap-2 text-amber-400 font-black uppercase tracking-[0.3em] text-[10px] mb-4">
                        <Target className="h-3 w-3" />
                        <span>Misión Activa</span>
                    </div>
                    <h2 className="text-3xl font-black uppercase tracking-tighter leading-none">
                        Panel de <span className="text-slate-400">Acción Inmediata</span>
                    </h2>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
                        <button className="flex items-center gap-3 p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all group">
                            <Send className="h-5 w-5 text-amber-400 group-hover:scale-110 transition-transform" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-white">Reportar</span>
                        </button>
                        <button className="flex items-center gap-3 p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all group">
                            <Camera className="h-5 w-5 text-blue-400 group-hover:scale-110 transition-transform" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-white">Evidencia</span>
                        </button>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Active Tasks list */}
                <Card className="rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-xl overflow-hidden">
                    <CardHeader className="p-8">
                        <div className="flex items-center gap-2">
                            <Target className="h-5 w-5 text-red-500" />
                            <CardTitle className="text-xl font-black uppercase tracking-tight">Tareas Prioritarias</CardTitle>
                        </div>
                    </CardHeader>
                    <CardContent className="p-8 pt-0 space-y-4">
                        {mockTasks.map(task => (
                            <div key={task.id} className="flex items-center justify-between p-5 rounded-[2rem] bg-slate-50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-800 transition-all border border-transparent hover:border-slate-100 dark:hover:border-slate-700">
                                <div className="space-y-1">
                                    <h4 className="text-xs font-black uppercase tracking-tight">{task.title}</h4>
                                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{task.area} • <span className="text-blue-500">{task.due}</span></p>
                                </div>
                                <div className={`h-8 w-8 rounded-full flex items-center justify-center ${task.priority === 'High' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}>
                                    <CheckCircle2 className="h-5 w-5" />
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                {/* Regional Health/Status */}
                <Card className="rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-xl overflow-hidden p-8 flex flex-col items-center justify-center text-center">
                    <div className="relative h-40 w-40 flex items-center justify-center">
                        <div className="absolute inset-0 rounded-full border-8 border-slate-50 dark:border-slate-800" />
                        <div className="absolute inset-0 rounded-full border-8 border-blue-600 border-t-transparent animate-spin duration-[3s]" />
                        <div className="text-3xl font-black text-slate-900 dark:text-white">85%</div>
                    </div>
                    <div className="mt-8 space-y-2">
                        <h4 className="text-lg font-black uppercase tracking-tight">Cumplimiento de Turno</h4>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Estás a 2 reportes de tu meta diaria</p>
                        <Badge className="bg-blue-600 mt-4 rounded-xl px-4">Elite Performer Badge</Badge>
                    </div>
                </Card>
            </div>
        </div>
    );
}

