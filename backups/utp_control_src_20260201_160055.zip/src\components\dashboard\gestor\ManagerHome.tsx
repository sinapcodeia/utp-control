'use client';

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlayCircle } from "lucide-react";

interface ManagerHomeProps {
    visits: any[];
    onStartRoute: () => void;
    userName?: string;
    regionName?: string;
    onStatClick?: (status: string) => void;
}

export function ManagerHome({ visits, onStartRoute, userName, regionName, onStatClick }: ManagerHomeProps) {
    const todayStr = new Date().toLocaleDateString('en-CA');
    const todayVisits = visits.filter(v => v.scheduledAt && v.scheduledAt.startsWith(todayStr));

    // Formatted date for display
    const formattedDate = new Date().toLocaleDateString('es-CO', {
        weekday: 'long',
        day: 'numeric',
        month: 'long'
    });

    // Total programadas (todas las del día)
    const totalProgramadas = todayVisits.length;

    const pendientes = todayVisits.filter(v => v.status === 'PENDING' && v.priority !== 'HIGH').length;
    const reprogramadas = todayVisits.filter(v => v.priority === 'HIGH' || v.status === 'CANCELLED').length;
    const completadas = todayVisits.filter(v => v.status === 'COMPLETED').length;

    // Calcular progreso
    const progress = totalProgramadas > 0 ? (completadas / totalProgramadas) * 100 : 0;

    return (
        <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 p-4 space-y-6">
            {/* 1. Header & Greeting */}
            <div className="mt-4">
                <h1 className="text-2xl font-black text-slate-900 dark:text-white mb-1">Buenos días, {userName || 'Gestor'}</h1>
                <div className="flex items-center gap-2">
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">{regionName || 'Jurisdicción Nacional'}</p>
                    <span className="h-1 w-1 rounded-full bg-slate-300" />
                    <p className="text-sm font-bold text-blue-600 uppercase tracking-widest">{formattedDate}</p>
                </div>
            </div>

            {/* 2. Stats Card "HOY" */}
            <Card className="rounded-3xl border-none shadow-xl bg-white dark:bg-slate-900 overflow-hidden">
                <CardContent className="p-8 space-y-8">
                    <h2 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">HOY</h2>

                    <div className="space-y-4">
                        <div
                            className="flex items-center gap-4 cursor-pointer hover:translate-x-1 transition-transform"
                            onClick={() => onStatClick?.('ALL')}
                        >
                            <div className="h-3 w-3 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                            <span className="text-lg font-bold text-slate-700 dark:text-slate-300">Programadas: {totalProgramadas}</span>
                        </div>
                        <div
                            className="flex items-center gap-4 cursor-pointer hover:translate-x-1 transition-transform"
                            onClick={() => onStatClick?.('PENDING')}
                        >
                            <div className="h-3 w-3 rounded-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]" />
                            <span className="text-lg font-bold text-slate-700 dark:text-slate-300">Pendientes: {pendientes}</span>
                        </div>
                        <div
                            className="flex items-center gap-4 cursor-pointer hover:translate-x-1 transition-transform"
                            onClick={() => onStatClick?.('HIGH')}
                        >
                            <div className="h-3 w-3 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
                            <span className="text-lg font-bold text-slate-700 dark:text-slate-300">Reprogramadas: {reprogramadas}</span>
                        </div>
                    </div>

                    <div className="space-y-3 pt-6 border-t border-slate-100 dark:border-slate-800">
                        <div className="flex justify-between items-center">
                            <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Progreso</span>
                            <span className="text-2xl font-black text-slate-900 dark:text-white">{Math.round(progress)}%</span>
                        </div>
                        {/* Visual bar mimicking ASCII block style requested but keeping it modern UI */}
                        <div className="flex gap-1 h-3 w-full">
                            {[...Array(10)].map((_, i) => (
                                <div
                                    key={i}
                                    className={`flex-1 rounded-sm ${i < progress / 10 ? 'bg-slate-900 dark:bg-white' : 'bg-slate-200 dark:bg-slate-800'}`}
                                />
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* 3. Primary Action CTA */}
            <div className="mt-auto pb-6">
                <Button
                    onClick={onStartRoute}
                    className="w-full h-16 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/30 text-lg font-black uppercase tracking-widest transition-all active:scale-[0.98]"
                >
                    Nueva Visita
                </Button>
            </div>
        </div>
    );
}
