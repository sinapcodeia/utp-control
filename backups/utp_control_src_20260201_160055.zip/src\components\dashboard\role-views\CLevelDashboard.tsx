'use client';

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DashboardStats } from "@/types";
import { TrendingUp, ShieldAlert, CheckCircle2, Map, ArrowRight } from "lucide-react";
import { useState } from "react";

interface CLevelDashboardProps {
    stats: DashboardStats | null;
}

export function CLevelDashboard({ stats }: CLevelDashboardProps) {
    const [period, setPeriod] = useState('Últimos 30 días');

    // Mocks for C-Level specific data
    const icoeGlobal = 82;
    const riesgoGlobal = 'MEDIO';
    const cumplimiento = 90;
    const cobertura = 76;

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-950 p-8 space-y-8 animate-in fade-in duration-700">
            {/* 1. Header Control Tower */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-200 dark:border-slate-800 pb-6">
                <div>
                    <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter uppercase">
                        Operación Territorial <span className="text-slate-400">— Vista Ejecutiva</span>
                    </h1>
                    <div className="flex items-center gap-4 mt-2">
                        <span className="text-sm font-bold text-slate-500 uppercase tracking-widest bg-slate-100 dark:bg-slate-900 px-3 py-1 rounded-full">
                            Periodo: {period}
                        </span>
                        <div className="flex items-center gap-2">
                            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                            <span className="text-xs font-bold text-green-600 uppercase tracking-widest">Última actualización: Hace 2 min</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* 2. Main KPI Grid (Answers: Is operation healthy?) */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* ICOE Global */}
                <Card className="rounded-[2.5rem] border-none shadow-xl bg-white dark:bg-slate-900">
                    <CardHeader className="pt-8 pb-0">
                        <div className="flex justify-between items-start">
                            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">ICOE Global</p>
                            <TrendingUp className="h-5 w-5 text-amber-500" />
                        </div>
                    </CardHeader>
                    <CardContent className="pt-2 pb-8">
                        <div className="flex items-baseline gap-2">
                            <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter">{icoeGlobal}%</h2>
                            <div className="h-3 w-3 rounded-full bg-amber-500" />
                        </div>
                        <p className="text-xs font-bold text-red-500 mt-2 flex items-center gap-1">
                            ↓ 4% vs mes anterior
                        </p>
                    </CardContent>
                </Card>

                {/* Riesgo Global */}
                <Card className="rounded-[2.5rem] border-none shadow-xl bg-white dark:bg-slate-900">
                    <CardHeader className="pt-8 pb-0">
                        <div className="flex justify-between items-start">
                            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Riesgo Global</p>
                            <ShieldAlert className="h-5 w-5 text-amber-500" />
                        </div>
                    </CardHeader>
                    <CardContent className="pt-2 pb-8">
                        <div className="flex items-baseline gap-2">
                            <h2 className="text-4xl font-black text-amber-500 tracking-tighter">{riesgoGlobal}</h2>
                        </div>
                        <p className="text-xs font-bold text-slate-400 mt-2">
                            Tendencia: ↑ Estable
                        </p>
                    </CardContent>
                </Card>

                {/* Cumplimiento */}
                <Card className="rounded-[2.5rem] border-none shadow-xl bg-white dark:bg-slate-900">
                    <CardHeader className="pt-8 pb-0">
                        <div className="flex justify-between items-start">
                            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Cumplimiento</p>
                            <CheckCircle2 className="h-5 w-5 text-green-500" />
                        </div>
                    </CardHeader>
                    <CardContent className="pt-2 pb-8">
                        <div className="flex items-baseline gap-2">
                            <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter">{cumplimiento}%</h2>
                            <div className="h-3 w-3 rounded-full bg-green-500" />
                        </div>
                        <p className="text-xs font-bold text-green-500 mt-2">
                            Ejecución Disciplinada
                        </p>
                    </CardContent>
                </Card>

                {/* Cobertura */}
                <Card className="rounded-[2.5rem] border-none shadow-xl bg-white dark:bg-slate-900">
                    <CardHeader className="pt-8 pb-0">
                        <div className="flex justify-between items-start">
                            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Cobertura</p>
                            <Map className="h-5 w-5 text-blue-500" />
                        </div>
                    </CardHeader>
                    <CardContent className="pt-2 pb-8">
                        <div className="flex items-baseline gap-2">
                            <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter">{cobertura}%</h2>
                            <div className="h-3 w-3 rounded-full bg-amber-500" />
                        </div>
                        <p className="text-xs font-bold text-slate-400 mt-2">
                            Alcance Real
                        </p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* 3. Strategic Trends & Intelligence */}
                <Card className="rounded-[2.5rem] border-none shadow-xl bg-white dark:bg-slate-900 p-8">
                    <div className="flex justify-between items-center mb-8">
                        <h3 className="text-lg font-black uppercase tracking-tight">Tendencia Operativa (ICOE)</h3>
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Últimos 6 Meses</span>
                    </div>

                    {/* Simplified Trend Visualization */}
                    <div className="h-48 flex items-end justify-between gap-4 px-4">
                        {[65, 70, 78, 85, 88, 82].map((val, i) => (
                            <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                                <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-t-2xl relative h-full overflow-hidden hover:bg-slate-200 transition-colors">
                                    <div
                                        className={`absolute bottom-0 w-full ${i === 5 ? 'bg-amber-500' : 'bg-blue-600'} transition-all duration-1000`}
                                        style={{ height: `${val}%` }}
                                    />
                                </div>
                                <span className="text-[10px] font-black text-slate-400 uppercase">Mes {i + 1}</span>
                            </div>
                        ))}
                    </div>
                </Card>

                {/* 4. Top Risks (Actionable) */}
                <Card className="rounded-[2.5rem] border-none shadow-xl bg-white dark:bg-slate-900 p-8">
                    <h3 className="text-lg font-black uppercase tracking-tight mb-8">Top Riesgos Estratégicos</h3>

                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/20 rounded-2xl border border-red-100 dark:border-red-900/50">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-white flex items-center justify-center text-xl shadow-sm">🛑</div>
                                <div>
                                    <p className="font-black text-slate-900 dark:text-white uppercase tracking-tight">Región Norte</p>
                                    <p className="text-xs text-red-600 font-bold uppercase tracking-widest">ICOE Crítico (-15%)</p>
                                </div>
                            </div>
                            <ArrowRight className="text-red-400" />
                        </div>

                        <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/20 rounded-2xl border border-red-100 dark:border-red-900/50">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-white flex items-center justify-center text-xl shadow-sm">📍</div>
                                <div>
                                    <p className="font-black text-slate-900 dark:text-white uppercase tracking-tight">Municipio X</p>
                                    <p className="text-xs text-red-600 font-bold uppercase tracking-widest">Alerta de Seguridad</p>
                                </div>
                            </div>
                            <ArrowRight className="text-red-400" />
                        </div>

                        <div className="flex items-center justify-between p-4 bg-amber-50 dark:bg-amber-900/20 rounded-2xl border border-amber-100 dark:border-amber-900/50">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-white flex items-center justify-center text-xl shadow-sm">⚠️</div>
                                <div>
                                    <p className="font-black text-slate-900 dark:text-white uppercase tracking-tight">Saturación Recursos</p>
                                    <p className="text-xs text-amber-600 font-bold uppercase tracking-widest">Riesgo Operativo</p>
                                </div>
                            </div>
                            <ArrowRight className="text-amber-400" />
                        </div>
                    </div>
                </Card>
            </div>

            {/* 5. C-Level Recommendations (AI Engine Mock) */}
            <div className="bg-slate-900 dark:bg-blue-950 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-12 opacity-5 scale-150 transform group-hover:scale-125 transition-transform duration-1000">
                    <TrendingUp className="w-64 h-64 text-white" />
                </div>

                <h3 className="text-white text-xl font-black uppercase tracking-tight mb-6 relative z-10 flex items-center gap-3">
                    <span className="bg-blue-600 text-xs px-2 py-1 rounded-md">AI ENGINE</span>
                    Recomendaciones Ejecutivas
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
                    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:bg-white/15 transition-colors cursor-pointer">
                        <p className="text-blue-300 text-xs font-black uppercase tracking-widest mb-2">Prioridad Alta</p>
                        <p className="text-white font-bold leading-relaxed">
                            "Reasignar recursos senior a <span className="text-white border-b-2 border-white/30">Región Norte</span> por 2 semanas para recuperar ICOE."
                        </p>
                    </div>
                    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:bg-white/15 transition-colors cursor-pointer">
                        <p className="text-amber-300 text-xs font-black uppercase tracking-widest mb-2">Auditoría</p>
                        <p className="text-white font-bold leading-relaxed">
                            "Iniciar auditoría puntual en <span className="text-white border-b-2 border-white/30">Municipio X</span> debido a anomalías en reportes de visitas."
                        </p>
                    </div>
                    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:bg-white/15 transition-colors cursor-pointer">
                        <p className="text-green-300 text-xs font-black uppercase tracking-widest mb-2">Oportunidad</p>
                        <p className="text-white font-bold leading-relaxed">
                            "Refuerzo operativo temporal en zona Sur podría incrementar cobertura al 80%."
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
