'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Phone, MoreHorizontal, UserCircle2, Filter } from "lucide-react";

interface TeamMember {
    id: string;
    name: string;
    role: string;
    status: 'active' | 'inactive' | 'break';
    municipality: string;
    lastActive: string;
    visitsCompleted: number;
    visitsAssigned: number;
}

interface TeamHierarchyProps {
    members: TeamMember[];
    onMemberSelect: (member: TeamMember) => void;
}

export function TeamHierarchy({ members, onMemberSelect }: TeamHierarchyProps) {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedMunicipality, setSelectedMunicipality] = useState<string>('Todos');

    const municipalities = ['Todos', ...Array.from(new Set(members.map(m => m.municipality)))];

    const filteredMembers = members.filter(m => {
        const matchesSearch = m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            m.role.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesMunicipality = selectedMunicipality === 'Todos' || m.municipality === selectedMunicipality;
        return matchesSearch && matchesMunicipality;
    });

    return (
        <Card className="rounded-[2.5rem] border-none bg-white dark:bg-slate-900 shadow-xl overflow-hidden">
            <CardHeader className="p-8 border-b border-slate-50 dark:border-slate-800">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                        <CardTitle className="text-2xl font-black uppercase tracking-tight">Fuerza Operativa</CardTitle>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Gestión de equipo en territorio</p>
                    </div>

                    <div className="flex items-center gap-3">
                        <div className="relative group">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                            <Input
                                placeholder="Buscar gestor..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10 h-12 w-64 rounded-2xl border-slate-100 bg-slate-50 focus:ring-2 focus:ring-blue-500/20 transition-all dark:bg-slate-800 dark:border-slate-700"
                            />
                        </div>
                        <Button variant="outline" size="icon" className="h-12 w-12 rounded-2xl border-slate-100 hover:bg-slate-50 dark:border-slate-700">
                            <Filter className="h-4 w-4 text-slate-500" />
                        </Button>
                    </div>
                </div>

                {/* Filtros de Municipio */}
                <div className="flex gap-2 mt-6 overflow-x-auto pb-2 scrollbar-hide">
                    {municipalities.map(m => (
                        <button
                            key={m}
                            onClick={() => setSelectedMunicipality(m)}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${selectedMunicipality === m
                                ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/20 dark:bg-white dark:text-slate-900'
                                : 'bg-slate-50 text-slate-500 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-400'
                                }`}
                        >
                            {m}
                        </button>
                    ))}
                </div>
            </CardHeader>

            <CardContent className="p-0">
                <div className="overflow-x-auto">
                    {municipalities.map(mun => {
                        const munMembers = filteredMembers.filter(m => m.municipality === mun || (mun === 'Todos'));
                        if (munMembers.length === 0) return null;
                        if (mun === 'Todos' && selectedMunicipality !== 'Todos') return null;

                        return (
                            <div key={mun} className="border-b border-slate-100 dark:border-slate-800 last:border-0">
                                <div className="bg-slate-50/50 dark:bg-slate-800/30 px-8 py-3 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <MapPin className="h-4 w-4 text-blue-500" />
                                        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
                                            {mun} ({munMembers.length})
                                        </span>
                                    </div>
                                    <Badge variant="outline" className="text-[8px] font-bold border-slate-200">
                                        {Math.round(munMembers.reduce((acc, m) => acc + (m.visitsCompleted / m.visitsAssigned), 0) / munMembers.length * 100)}% Cumplimiento
                                    </Badge>
                                </div>
                                <table className="w-full">
                                    <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                                        {munMembers.map(member => (
                                            <tr
                                                key={member.id}
                                                onClick={() => onMemberSelect(member)}
                                                className="group hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors cursor-pointer"
                                            >
                                                <td className="py-4 px-8 w-1/3">
                                                    <div className="flex items-center gap-4">
                                                        <div className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 dark:bg-slate-800 group-hover:bg-white transition-colors">
                                                            <UserCircle2 className="h-6 w-6" />
                                                        </div>
                                                        <div>
                                                            <p className="text-sm font-bold text-slate-900 dark:text-white">{member.name}</p>
                                                            <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wide">{member.role}</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="py-4 px-8">
                                                    <Badge className={`border-none rounded-lg px-2.5 py-1 text-[10px] font-black uppercase tracking-widest ${member.status === 'active' ? 'bg-green-100 text-green-600' :
                                                        member.status === 'break' ? 'bg-amber-100 text-amber-600' :
                                                            'bg-slate-100 text-slate-400'
                                                        }`}>
                                                        {member.status === 'active' ? 'En Campo' : member.status === 'break' ? 'En Pausa' : 'Inactivo'}
                                                    </Badge>
                                                </td>
                                                <td className="py-4 px-8">
                                                    <div className="flex items-center gap-3">
                                                        <div className="flex-1 h-1.5 w-24 bg-slate-100 rounded-full overflow-hidden dark:bg-slate-800">
                                                            <div
                                                                className={`h-full rounded-full transition-all duration-1000 ${(member.visitsCompleted / member.visitsAssigned) > 0.8 ? 'bg-green-500' :
                                                                        (member.visitsCompleted / member.visitsAssigned) > 0.4 ? 'bg-amber-500' : 'bg-red-500'
                                                                    }`}
                                                                style={{ width: `${(member.visitsCompleted / member.visitsAssigned) * 100}%` }}
                                                            />
                                                        </div>
                                                        <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400">
                                                            {member.visitsCompleted}/{member.visitsAssigned}
                                                        </span>
                                                    </div>
                                                </td>
                                                <td className="py-4 px-8 text-right">
                                                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-white transition-all">
                                                        <MoreHorizontal className="h-4 w-4" />
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}
