'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar, MapPin, User, Clock, CheckCircle2, AlertCircle, ChevronLeft, ChevronRight, Plus, Edit3, Trash2, Navigation, FileText } from "lucide-react";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";

import { apiClient } from "@/lib/api-client";

interface Visit {
    id: string;
    fullName: string;
    addressText: string;
    citizenId?: string;
    phone?: string;
    scheduledAt: string;
    status: string;
    priority: string;
    region?: { name: string };
    municipality?: { name: string };
    assignedTo?: { fullName: string };
}

export default function VisitsPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();
    const [visits, setVisits] = useState<Visit[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [selectedVisit, setSelectedVisit] = useState<Visit | null>(null);
    const [isRescheduleOpen, setIsRescheduleOpen] = useState(false);
    const [newScheduledDate, setNewScheduledDate] = useState('');
    const [newScheduledTime, setNewScheduledTime] = useState('');
    const [currentMonth, setCurrentMonth] = useState(new Date());

    // Cargar visitas
    useEffect(() => {
        const fetchVisits = async () => {
            try {
                setLoading(true);
                const { data: { session } } = await supabase.auth.getSession();
                if (!session?.access_token) return;

                const response = await apiClient.get<any[]>('/territory/my-visits');
                if (response) {
                    setVisits(response);
                }
            } catch (error) {
                console.error('Error fetching visits:', error);
                toast.error('Error al cargar visitas');
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchVisits();
        }
    }, [currentUser, supabase.auth]);

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    const handleReschedule = async () => {
        if (!selectedVisit || !newScheduledDate || !newScheduledTime) {
            toast.error('Por favor selecciona fecha y hora');
            return;
        }

        try {
            const { data: { session } } = await supabase.auth.getSession();
            if (!session?.access_token) return;

            const scheduledAt = new Date(`${newScheduledDate}T${newScheduledTime}`);
            const now = new Date();

            // Validar que la fecha no sea en el pasado
            if (scheduledAt < now) {
                toast.error('❌ No se puede programar en el pasado', {
                    description: 'Por favor selecciona una fecha y hora futura'
                });
                return;
            }

            const response = await apiClient.patch(
                `/territory/visits/${selectedVisit.id}`,
                { scheduledAt: scheduledAt.toISOString() }
            );

            if (response) {
                const updated = response as any;
                setVisits(prev => prev.map(v => v.id === updated.id ? updated : v));
                setIsRescheduleOpen(false);
                setSelectedVisit(null);
                toast.success('✅ Visita reagendada exitosamente', {
                    description: `Nueva fecha: ${scheduledAt.toLocaleString('es-ES')}`
                });
            } else {
                throw new Error('Error al reagendar');
            }
        } catch (error) {
            console.error('Error rescheduling visit:', error);
            toast.error('Error al reagendar la visita');
        }
    };

    const openRescheduleDialog = (visit: Visit) => {
        setSelectedVisit(visit);
        const date = new Date(visit.scheduledAt);
        setNewScheduledDate(date.toISOString().split('T')[0]);
        setNewScheduledTime(date.toTimeString().slice(0, 5));
        setIsRescheduleOpen(true);
    };

    // Filtrar visitas por fecha seleccionada y ordenar cronológicamente
    const visitsForSelectedDate = visits.filter(v => {
        const visitDate = new Date(v.scheduledAt);
        return visitDate.toDateString() === selectedDate.toDateString();
    }).sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime());

    // Obtener visitas por día del mes actual
    const getVisitsForDay = (day: number) => {
        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
        return visits.filter(v => {
            const visitDate = new Date(v.scheduledAt);
            return visitDate.toDateString() === date.toDateString();
        });
    };

    // Generar días del calendario
    const getDaysInMonth = () => {
        const year = currentMonth.getFullYear();
        const month = currentMonth.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        const days = [];
        // Días vacíos al inicio
        for (let i = 0; i < firstDay; i++) {
            days.push(null);
        }
        // Días del mes
        for (let i = 1; i <= daysInMonth; i++) {
            days.push(i);
        }
        return days;
    };

    const nextMonth = () => {
        setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
    };

    const prevMonth = () => {
        setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
    };

    const todayVisits = visits.filter(v => {
        const visitDate = new Date(v.scheduledAt);
        const today = new Date();
        return visitDate.toDateString() === today.toDateString();
    });

    const upcomingVisits = visits.filter(v => {
        const visitDate = new Date(v.scheduledAt);
        const today = new Date();
        return visitDate > today;
    }).slice(0, 5);

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="space-y-3">
                    <Badge variant="outline" className="rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em]">
                        Gestión de Campo
                    </Badge>
                    <div className="flex items-center">
                        <Button
                            variant="ghost"
                            onClick={() => window.history.back()}
                            className="h-12 w-12 rounded-2xl mr-4 bg-white dark:bg-slate-800 shadow-sm border border-slate-100 dark:border-slate-800 hover:bg-slate-50"
                        >
                            <ChevronLeft className="h-6 w-6 text-slate-600" />
                        </Button>
                        <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9]">
                            Mis <span className="text-blue-600">Visitas</span>
                        </h1>
                    </div>
                    <p className="text-slate-500 font-medium max-w-xl text-lg">
                        Agenda y gestiona tus visitas de campo con precisión operativa.
                    </p>
                </div>

                <div className="flex flex-col gap-4">
                    {/* Botón Ver Reportes */}
                    <Button
                        onClick={() => window.location.href = '/dashboard/visits/reports'}
                        className="h-14 rounded-2xl bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-purple-500/20"
                    >
                        <FileText className="h-4 w-4 mr-2" />
                        Ver Reportes
                    </Button>

                    {/* Stats Cards */}
                    <div className="flex gap-4">
                        <Card className="rounded-[2rem] border-none bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-2xl shadow-blue-500/30">
                            <CardContent className="p-6">
                                <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Hoy</p>
                                <p className="text-4xl font-black">{todayVisits.length}</p>
                            </CardContent>
                        </Card>
                        <Card className="rounded-[2rem] border-none bg-white dark:bg-slate-900 shadow-xl">
                            <CardContent className="p-6">
                                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Próximas</p>
                                <p className="text-4xl font-black text-slate-900 dark:text-white">{upcomingVisits.length}</p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Calendario */}
                <Card className="lg:col-span-2 rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
                    <CardHeader className="p-8 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-800">
                        <div className="flex items-center justify-between">
                            <CardTitle className="text-2xl font-black uppercase tracking-tighter text-slate-900 dark:text-white">
                                {currentMonth.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
                            </CardTitle>
                            <div className="flex gap-2">
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={prevMonth}
                                    className="h-10 w-10 rounded-xl hover:bg-white dark:hover:bg-slate-700"
                                >
                                    <ChevronLeft className="h-5 w-5" />
                                </Button>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={nextMonth}
                                    className="h-10 w-10 rounded-xl hover:bg-white dark:hover:bg-slate-700"
                                >
                                    <ChevronRight className="h-5 w-5" />
                                </Button>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="p-8">
                        {/* Días de la semana */}
                        <div className="grid grid-cols-7 gap-2 mb-4">
                            {['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map(day => (
                                <div key={day} className="text-center text-[10px] font-black uppercase tracking-widest text-slate-400 py-2">
                                    {day}
                                </div>
                            ))}
                        </div>

                        {/* Días del mes */}
                        <div className="grid grid-cols-7 gap-2">
                            {getDaysInMonth().map((day, index) => {
                                if (day === null) {
                                    return <div key={`empty-${index}`} className="aspect-square" />;
                                }

                                const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                                const dayVisits = getVisitsForDay(day);
                                const isToday = date.toDateString() === new Date().toDateString();
                                const isSelected = date.toDateString() === selectedDate.toDateString();

                                return (
                                    <button
                                        key={day}
                                        onClick={() => setSelectedDate(date)}
                                        className={`aspect-square rounded-2xl p-2 transition-all duration-300 relative group ${isSelected
                                            ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30 scale-105'
                                            : isToday
                                                ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 font-bold ring-2 ring-blue-600/20'
                                                : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                                            }`}
                                    >
                                        <span className={`text-sm font-bold ${isSelected ? 'text-white' : ''}`}>{day}</span>
                                        {dayVisits.length > 0 && (
                                            <div className={`absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5`}>
                                                {dayVisits.slice(0, 3).map((_, i) => (
                                                    <div
                                                        key={i}
                                                        className={`h-1 w-1 rounded-full ${isSelected ? 'bg-white' : 'bg-blue-600'
                                                            }`}
                                                    />
                                                ))}
                                            </div>
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                    </CardContent>
                </Card>

                {/* Lista de visitas del día seleccionado */}
                <Card className="rounded-[3rem] border-none bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
                    <CardHeader className="p-8 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-800">
                        <CardTitle className="text-xl font-black uppercase tracking-tighter text-slate-900 dark:text-white">
                            {selectedDate.toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}
                        </CardTitle>
                        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">
                            {visitsForSelectedDate.length} {visitsForSelectedDate.length === 1 ? 'visita' : 'visitas'}
                        </p>
                    </CardHeader>
                    <CardContent className="p-6 space-y-3 max-h-[600px] overflow-y-auto">
                        {loading ? (
                            <div className="flex items-center justify-center py-12">
                                <div className="h-8 w-8 rounded-full border-4 border-blue-600 border-t-transparent animate-spin" />
                            </div>
                        ) : visitsForSelectedDate.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-12 text-center">
                                <Calendar className="h-16 w-16 text-slate-200 dark:text-slate-700 mb-4" />
                                <p className="text-sm font-bold text-slate-400">Sin visitas programadas</p>
                            </div>
                        ) : (
                            visitsForSelectedDate.map(visit => (
                                <Card key={visit.id} className="rounded-2xl border border-slate-100 dark:border-slate-800 hover:shadow-lg transition-all duration-300 overflow-hidden group">
                                    <CardContent className="p-4 space-y-3">
                                        <div className="flex items-start justify-between">
                                            <div className="flex-1">
                                                <h3 className="font-black text-slate-900 dark:text-white text-sm">{visit.fullName}</h3>
                                                <div className="flex items-center gap-2 mt-1">
                                                    <Clock className="h-3 w-3 text-blue-600" />
                                                    <span className="text-xs font-bold text-slate-500">
                                                        {new Date(visit.scheduledAt).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                                                    </span>
                                                </div>
                                            </div>
                                            <Badge className={`text-[8px] font-black uppercase tracking-widest ${visit.priority === 'HIGH' ? 'bg-red-500' :
                                                visit.priority === 'MEDIUM' ? 'bg-amber-500' : 'bg-blue-500'
                                                }`}>
                                                {visit.priority}
                                            </Badge>
                                        </div>

                                        <div className="flex items-start gap-2">
                                            <MapPin className="h-3 w-3 text-slate-400 mt-0.5 flex-shrink-0" />
                                            <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">{visit.addressText}</p>
                                        </div>

                                        <div className="flex gap-2 pt-2">
                                            <Button
                                                size="sm"
                                                onClick={() => openRescheduleDialog(visit)}
                                                className="flex-1 h-9 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[9px] tracking-widest"
                                            >
                                                <Clock className="h-3 w-3 mr-1" />
                                                Reagendar
                                            </Button>
                                            <Button
                                                size="sm"
                                                variant="outline"
                                                className="h-9 w-9 rounded-xl border-slate-200 hover:bg-slate-50"
                                            >
                                                <Navigation className="h-3 w-3" />
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))
                        )}
                    </CardContent>
                </Card>
            </div>

            {/* Dialog de Reagendar - Experiencia 360 */}
            <Dialog open={isRescheduleOpen} onOpenChange={setIsRescheduleOpen}>
                <DialogContent className="sm:max-w-[500px] rounded-[3rem] border-none bg-white dark:bg-slate-950 p-0 overflow-hidden shadow-2xl">
                    <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-10 text-white relative overflow-hidden">
                        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
                        <div className="absolute -left-8 -bottom-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
                        <DialogHeader className="relative z-10">
                            <div className="h-16 w-16 rounded-[2rem] bg-white/20 backdrop-blur-md flex items-center justify-center mb-4 shadow-xl">
                                <Calendar className="h-8 w-8 text-white" />
                            </div>
                            <DialogTitle className="text-3xl font-black uppercase tracking-tighter leading-none mb-2">
                                Reagendar<br />
                                <span className="opacity-70">Visita</span>
                            </DialogTitle>
                            <DialogDescription className="text-blue-100 font-medium">
                                Selecciona la nueva fecha y hora para esta visita de campo.
                            </DialogDescription>
                        </DialogHeader>
                    </div>

                    <div className="p-10 space-y-6">
                        {selectedVisit && (
                            <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-[2rem] space-y-2">
                                <p className="text-xs font-black uppercase tracking-widest text-slate-400">Visitando a</p>
                                <p className="text-lg font-black text-slate-900 dark:text-white">{selectedVisit.fullName}</p>
                                <div className="flex items-center gap-2 text-slate-500">
                                    <MapPin className="h-4 w-4" />
                                    <p className="text-sm font-medium">{selectedVisit.addressText}</p>
                                </div>
                            </div>
                        )}

                        <div className="space-y-4">
                            <div className="space-y-2">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nueva Fecha</Label>
                                <Input
                                    type="date"
                                    value={newScheduledDate}
                                    onChange={(e) => setNewScheduledDate(e.target.value)}
                                    className="h-14 rounded-2xl bg-slate-50 dark:bg-slate-900 border-none font-bold px-6"
                                />
                            </div>

                            <div className="space-y-2">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nueva Hora</Label>
                                <Input
                                    type="time"
                                    value={newScheduledTime}
                                    onChange={(e) => setNewScheduledTime(e.target.value)}
                                    className="h-14 rounded-2xl bg-slate-50 dark:bg-slate-900 border-none font-bold px-6"
                                />
                            </div>
                        </div>

                        <DialogFooter className="gap-3">
                            <Button
                                variant="ghost"
                                onClick={() => setIsRescheduleOpen(false)}
                                className="flex-1 h-14 rounded-2xl font-black uppercase tracking-widest text-xs text-slate-400 hover:text-slate-600"
                            >
                                Cancelar
                            </Button>
                            <Button
                                onClick={handleReschedule}
                                className="flex-1 h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20"
                            >
                                <CheckCircle2 className="h-4 w-4 mr-2" />
                                Confirmar
                            </Button>
                        </DialogFooter>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}
