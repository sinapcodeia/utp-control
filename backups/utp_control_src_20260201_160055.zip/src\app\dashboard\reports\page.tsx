'use client';

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileDown, Filter, Plus, Search, CheckCircle2, Clock, AlertCircle, FileEdit, Trash2, Eye, FileText, Download, Briefcase } from "lucide-react";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import Link from 'next/link';
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";
import { AutomatedReportGenerator } from "@/components/dashboard/AutomatedReportGenerator";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

export default function ReportsPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();

    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [reports, setReports] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [newReport, setNewReport] = useState({ title: '', type: 'General' });

    // Obtener desde la API
    useEffect(() => {
        const fetchReports = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();

                if (!session?.access_token) {
                    console.error("No hay sesión activa");
                    toast.error("Sesión no encontrada. Por favor, inicia sesión nuevamente.");
                    setLoading(false);
                    return;
                }

                const response = await fetch(`${API_URL}/reports`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });

                if (response.status === 401) {
                    console.error("Error de autenticación (401)");
                    toast.error("Sesión expirada. Por favor, recarga la página.");
                    setLoading(false);
                    return;
                }

                if (!response.ok) {
                    console.error(`Error HTTP ${response.status}`);
                    toast.error(`Error al cargar informes (${response.status})`);
                    setLoading(false);
                    return;
                }

                const data = await response.json();
                setReports(data.map((r: any) => ({
                    id: r.code,
                    dbId: r.id,
                    title: `${r.type} - Informe`,
                    type: r.type,
                    date: new Date(r.generatedAt).toISOString().split('T')[0],
                    author: r.generatedBy?.fullName || 'Sistema',
                    status: 'Aprobado',
                    url: r.url
                })));
            } catch (error) {
                console.error("Error al obtener informes:", error);
                toast.error("Error al conectar con la bóveda de informes");
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchReports();
        }
    }, [currentUser, supabase.auth]);

    // Mostrar loading mientras se carga el usuario o el perfil
    if (userLoading || profileLoading) {
        return <LoadingState />;
    }

    // Manejar caso de perfil no encontrado
    if (!currentUser) {
        return <ProfileError />;
    }

    const handleDeleteReport = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if (confirm('¿Estás seguro de que deseas eliminar este informe oficial? Esta acción no se puede deshacer.')) {
            const updated = reports.filter(r => r.id !== id);
            setReports(updated);
        }
    };

    const handleViewReport = (id: string) => {
        window.location.href = `/dashboard/reports/${id}`;
    };

    const handleDownload = (report: any, e: React.MouseEvent) => {
        e.stopPropagation();
        const content = `
            SISTEMA DE CONTROL REGIONAL - UTP
            ----------------------------------
            DOCUMENTO OFICIAL: ${report.id}
            ESTADO: ${report.status.toUpperCase()}
            
            DETALLES TÉCNICOS:
            - TÍTULO: ${report.title}
            - CATEGORÍA: ${report.type}
            - FECHA REGISTRO: ${report.date}
            - AUTOR RESPONSABLE: ${report.author}
        `.trim();
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `REPORTE_${report.id}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleDownloadAttachment = (report: any, e: React.MouseEvent) => {
        e.stopPropagation();
        if (!report.url) return;
        window.open(report.url, '_blank');
        toast.success("Abriendo documento PDF");
    };

    const handleCreateReport = async () => {
        if (!currentUser.region_id) {
            toast.error("El usuario no tiene una región asignada");
            return;
        }
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const response = await fetch(`${API_URL}/reports/generate`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session?.access_token}`
                },
                body: JSON.stringify({
                    type: newReport.type.toUpperCase(),
                    format: 'PDF',
                    regionId: currentUser.region_id,
                    filters: { title: newReport.title }
                })
            });

            if (response.ok) {
                const report = await response.json();
                toast.success("Informe generado exitosamente");
                setIsDialogOpen(false);
                setNewReport({ title: '', type: 'General' });
                setTimeout(() => {
                    window.location.href = `/dashboard/reports/${report.id}`;
                }, 500);
            }
        } catch (error) {
            console.error("Error generating report:", error);
            toast.error("Error al generar el documento oficial");
        }
    };

    return (
        <div className="space-y-6" suppressHydrationWarning>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="space-y-1">
                    <h2 className="text-3xl font-bold tracking-tighter text-slate-900 dark:text-slate-50">Gestión de Informes</h2>
                    <p className="text-sm font-medium text-slate-500/80">
                        Genera, visualiza y descarga los informes oficiales del sistema regional.
                    </p>
                </div>

                <div className="flex items-center gap-4">
                    <Link href="/dashboard/reports/archive">
                        <Button variant="outline" className="rounded-2xl border-blue-200 bg-blue-50/30 text-blue-700 font-black uppercase text-[10px] tracking-widest hover:bg-blue-100 h-10 px-6">
                            <Briefcase className="mr-2 h-4 w-4" /> Ver Bóveda Histórica
                        </Button>
                    </Link>

                    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                        <DialogTrigger asChild>
                            <Button className="gap-2 h-10 px-6 font-bold uppercase tracking-widest text-[10px] rounded-xl">
                                <Plus className="h-4 w-4" />
                                Generar Informe
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[480px] rounded-[2rem] border-none bg-white dark:bg-slate-950 p-0 overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] animate-slide-in">
                            <div className="relative">
                                <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-blue-600/5 to-transparent pointer-events-none" />
                                <DialogHeader className="p-8 pt-10 text-center space-y-2">
                                    <div className="mx-auto h-12 w-12 rounded-2xl bg-blue-600/10 flex items-center justify-center mb-2">
                                        <Plus className="h-6 w-6 text-blue-600" />
                                    </div>
                                    <DialogTitle className="text-2xl font-black tracking-tighter uppercase text-slate-900 dark:text-slate-50">
                                        Nuevo Informe Oficial
                                    </DialogTitle>
                                    <DialogDescription className="text-sm font-medium text-slate-500 max-w-[280px] mx-auto">
                                        Genera un nuevo registro documentado con trazabilidad centralizada.
                                    </DialogDescription>
                                </DialogHeader>

                                <div className="px-8 pb-8 space-y-6">
                                    <div className="space-y-3">
                                        <Label htmlFor="title" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                            Título del Informe
                                        </Label>
                                        <Input
                                            id="title"
                                            value={newReport.title}
                                            onChange={(e) => setNewReport({ ...newReport, title: e.target.value })}
                                            className="h-12 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-semibold px-4 placeholder:text-slate-300 dark:bg-slate-900 dark:border-slate-800"
                                            placeholder="Ej: Reporte Mensual de Incidencias..."
                                        />
                                    </div>

                                    <div className="space-y-3">
                                        <Label htmlFor="type" className="text-[11px] font-black uppercase tracking-[0.2em] text-blue-600/80 pl-1">
                                            Categoría / Tipo
                                        </Label>
                                        <Select
                                            onValueChange={(val) => setNewReport({ ...newReport, type: val })}
                                            defaultValue={newReport.type}
                                        >
                                            <SelectTrigger className="h-12 rounded-2xl border-slate-200/60 bg-white shadow-sm focus:ring-4 focus:ring-blue-500/10 transition-all font-semibold px-4 dark:bg-slate-900 dark:border-slate-800">
                                                <SelectValue placeholder="Selecciona un tipo" />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border-slate-200 bg-white dark:bg-slate-900 shadow-2xl p-1 z-[100]">
                                                <SelectItem value="General" className="rounded-xl py-3 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">General</SelectItem>
                                                <SelectItem value="Regional" className="rounded-xl py-3 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Regional</SelectItem>
                                                <SelectItem value="Alert" className="rounded-xl py-3 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Seguridad</SelectItem>
                                                <SelectItem value="Audit" className="rounded-xl py-3 font-bold focus:bg-blue-50 focus:text-blue-700 dark:focus:bg-blue-900/40">Auditoría</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <DialogFooter className="pt-4 flex flex-col gap-3">
                                        <Button
                                            type="submit"
                                            onClick={handleCreateReport}
                                            className="w-full h-14 rounded-2xl font-black uppercase tracking-widest text-xs shadow-[0_12px_24px_-8px_rgba(37,99,235,0.4)] hover:shadow-[0_16px_32px_-8px_rgba(37,99,235,0.5)] transition-all bg-blue-600 hover:bg-blue-700"
                                        >
                                            Generar y Continuar
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            onClick={() => setIsDialogOpen(false)}
                                            className="w-full h-10 rounded-xl text-xs font-bold text-slate-400 hover:text-slate-600 uppercase tracking-widest"
                                        >
                                            Cancelar
                                        </Button>
                                    </DialogFooter>
                                </div>
                            </div>
                        </DialogContent>
                    </Dialog>
                </div>
            </div>

            {/* Automated Report Generator Widget */}
            <AutomatedReportGenerator />

            <div className="flex items-center gap-3">
                <div className="relative flex-1 group">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
                    <input
                        type="text"
                        placeholder="Buscar por código, título o autor..."
                        className="w-full rounded-xl border border-slate-200/60 bg-white/50 px-10 py-2.5 text-sm outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 backdrop-blur-sm transition-all dark:border-slate-800/60 dark:bg-slate-950/50"
                    />
                </div>
                <Button variant="outline" size="icon" className="rounded-xl border-slate-200 hover:bg-slate-50">
                    <Filter className="h-4 w-4" />
                </Button>
            </div>

            <Card className="premium-card overflow-hidden border-none bg-white/40 dark:bg-slate-950/40 shadow-xl">
                <CardContent className="p-0">
                    <div className="relative w-full overflow-auto">
                        <table className="w-full caption-bottom text-sm">
                            <thead>
                                <tr className="border-b border-slate-100 dark:border-slate-800/50 bg-slate-50/30 dark:bg-slate-900/20">
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400">Código</th>
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400">Título</th>
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400">Tipo</th>
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400">Fecha</th>
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400">Autor</th>
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400">Estado</th>
                                    <th className="h-12 px-6 align-middle font-bold text-slate-900 uppercase tracking-widest text-[10px] dark:text-slate-400 text-right">Acciones</th>
                                </tr>
                            </thead>
                            <tbody className="[&_tr:last-child]:border-0 font-medium">
                                {reports.map((report) => (
                                    <tr
                                        key={report.id}
                                        onClick={() => handleViewReport(report.id)}
                                        className="border-b border-slate-100 dark:border-slate-800 transition-all hover:bg-blue-50/30 dark:hover:bg-blue-900/10 cursor-pointer group"
                                    >
                                        <td className="px-6 py-4 align-middle font-mono font-medium text-[11px] text-slate-400 group-hover:text-blue-600 transition-colors">{report.id}</td>
                                        <td className="px-6 py-4 align-middle font-bold text-slate-900 dark:text-slate-100 italic flex items-center gap-2">
                                            {report.title}
                                            {report.author === currentUser.full_name && (
                                                <span className="h-1.5 w-1.5 rounded-full bg-blue-500" title="Tu informe" />
                                            )}
                                        </td>
                                        <td className="px-6 py-4 align-middle">
                                            <span className="inline-flex items-center rounded-lg border border-slate-200 bg-slate-50/50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-600 dark:border-slate-800 dark:bg-slate-900/50 dark:text-slate-400">{report.type}</span>
                                        </td>
                                        <td className="px-6 py-4 align-middle text-slate-500 tabular-nums text-xs">{report.date}</td>
                                        <td className="px-6 py-4 align-middle font-medium text-slate-700 dark:text-slate-300">{report.author}</td>
                                        <td className="px-6 py-4 align-middle">
                                            <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                                <CheckCircle2 className="h-3 w-3" />
                                                Aprobado
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 align-middle text-right">
                                            <div className="flex items-center justify-end gap-1">
                                                <Button
                                                    variant="ghost" size="icon" className="h-8 w-8 text-slate-400"
                                                    onClick={(e) => { e.stopPropagation(); handleViewReport(report.id); }}
                                                >
                                                    <Eye className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-900"
                                                    onClick={(e) => handleDownload(report, e)}
                                                >
                                                    <FileDown className="h-4 w-4" />
                                                </Button>
                                                <Button
                                                    variant="ghost" size="icon" className="h-8 w-8 text-red-400"
                                                    onClick={(e) => handleDeleteReport(report.id, e)}
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {loading && (
                                    <tr>
                                        <td colSpan={7} className="px-6 py-10 text-center font-bold text-slate-300 uppercase tracking-widest text-xs animate-pulse">Sincronizando Bóveda...</td>
                                    </tr>
                                )}
                                {!loading && reports.length === 0 && (
                                    <tr>
                                        <td colSpan={7} className="px-6 py-10 text-center font-bold text-slate-300 uppercase tracking-widest text-xs">No hay informes recientes en el buzón</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}


