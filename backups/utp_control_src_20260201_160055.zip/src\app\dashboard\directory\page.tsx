
'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
    Search,
    MessageSquare,
    Phone,
    Mail,
    MapPin,
    UserCircle2,
    Edit3,
    ShieldCheck,
    Briefcase,
    X,
    Command,
    ArrowUpRight
} from "lucide-react";
import { toast } from "sonner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LoadingState } from "@/components/dashboard/LoadingState";
import { ProfileError } from "@/components/dashboard/ProfileError";


export default function DirectoryPage() {
    const { user: currentUser, loading: userLoading, profileLoading, supabase } = useCurrentUser();

    const [users, setUsers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedRegion, setSelectedRegion] = useState('Todas');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const searchInputRef = useRef<HTMLInputElement>(null);
    const searchContainerRef = useRef<HTMLDivElement>(null);

    const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3001';

    // Cierra las sugerencias al hacer clic fuera
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                const response = await fetch(`${API_URL}/users`, {
                    headers: {
                        'Authorization': `Bearer ${session?.access_token}`
                    }
                });
                if (response.ok) {
                    const data = await response.json();
                    // Ordenar alfabéticamente por defecto
                    const sortedData = data.sort((a: any, b: any) => a.fullName.localeCompare(b.fullName));

                    setUsers(sortedData.map((u: any) => ({
                        id: u.id,
                        name: u.fullName,
                        role: u.role,
                        region: u.region?.name || 'Nacional',
                        email: u.email,
                        phone: u.phone || 'N/A',
                        whatsapp: u.phone?.replace(/\D/g, '') || '',
                        avatar: null,
                        isAdmin: u.role === 'ADMIN'
                    })));
                }
            } catch (error) {
                console.error("Error fetching users:", error);
                toast.error("Error al conectar con el directorio");
            } finally {
                setLoading(false);
            }
        };

        if (currentUser) {
            fetchUsers();
        }
    }, [API_URL, currentUser, supabase.auth]);

    const handleAction = (type: string, value: string) => {
        if (type === 'whatsapp') {
            if (!value) {
                toast.error("Número de WhatsApp no disponible");
                return;
            }
            window.open(`https://wa.me/${value}`, '_blank');
        } else if (type === 'call') {
            if (value === 'N/A') {
                toast.error("Número de teléfono no disponible");
                return;
            }
            window.location.href = `tel:${value}`;
        } else if (type === 'email') {
            window.location.href = `mailto:${value}`;
        }
    };

    const regions = ['Todas', 'Zona Norte', 'Zona Sur', 'Central', 'Zona Este', 'Nacional'];

    // Filtrado principal
    const filteredUsers = users.filter(user => {
        const matchesSearch = searchTerm === '' ||
            user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesRegion = selectedRegion === 'Todas' || user.region === selectedRegion;

        return matchesSearch && matchesRegion;
    });

    // Sugerencias para la barra de búsqueda (limitadas a 5)
    const suggestions = searchTerm
        ? users.filter(u => u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.role.toLowerCase().includes(searchTerm.toLowerCase())).slice(0, 5)
        : [];

    if (userLoading || profileLoading) return <LoadingState />;
    if (!currentUser) return <ProfileError />;

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-20">
            {/* Brillo de fondo */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-blue-500/5 blur-[120px] rounded-full" />
                <div className="absolute top-[20%] -right-[10%] w-[30%] h-[30%] bg-purple-500/5 blur-[120px] rounded-full" />
            </div>

            {/* Encabezado */}
            <div className="relative flex flex-col gap-2">
                <Badge variant="outline" className="w-fit rounded-full border-blue-100 bg-blue-50/50 text-blue-700 px-4 py-1 font-bold text-[10px] uppercase tracking-[0.2em] mb-2 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-400">
                    Conectividad Regional
                </Badge>
                <h1 className="text-5xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-[0.9] font-heading">
                    Directorio <span className="text-blue-600">Corporativo</span>
                </h1>
                <p className="text-slate-500 font-medium max-w-xl text-lg mt-2 font-sans">
                    Ecosistema de comunicaciones integradas. Conecta con el equipo mediante enlaces seguros.
                </p>
            </div>

            {/* Barra de Herramientas (Búsqueda + Filtros) */}
            <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between relative z-20">

                {/* Barra de Búsqueda Predictiva */}
                <div ref={searchContainerRef} className="relative w-full lg:w-[450px] group">
                    <div className="relative">
                        <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                        <Input
                            ref={searchInputRef}
                            placeholder="Buscar compañero..."
                            className="pl-14 h-16 rounded-[2rem] border-slate-200/60 bg-white/80 backdrop-blur-xl shadow-lg shadow-slate-200/20 focus:ring-4 focus:ring-blue-500/10 transition-all text-lg font-medium dark:bg-slate-900/80 dark:border-slate-800 dark:shadow-none"
                            value={searchTerm}
                            onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setShowSuggestions(true);
                            }}
                            onFocus={() => setShowSuggestions(true)}
                        />
                        {searchTerm && (
                            <button
                                onClick={() => setSearchTerm('')}
                                className="absolute right-5 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-slate-100 text-slate-400 transition-colors"
                            >
                                <X className="h-4 w-4" />
                            </button>
                        )}
                    </div>

                    {/* Menú Flotante de Sugerencias */}
                    {showSuggestions && searchTerm && suggestions.length > 0 && (
                        <div className="absolute top-full left-0 right-0 mt-3 p-2 bg-white/90 backdrop-blur-xl rounded-[2rem] border border-slate-100 shadow-2xl shadow-blue-900/10 z-50 animate-in slide-in-from-top-2 duration-200 dark:bg-slate-900/90 dark:border-slate-800">
                            <div className="px-4 py-2 text-[10px] font-black uppercase tracking-widest text-slate-400">
                                Sugerencias Rápidas
                            </div>
                            {suggestions.map(user => (
                                <div
                                    key={user.id}
                                    onClick={() => {
                                        setSearchTerm(user.name);
                                        setShowSuggestions(false);
                                    }}
                                    className="flex items-center gap-3 p-3 rounded-2xl hover:bg-blue-50 cursor-pointer transition-colors group/item dark:hover:bg-slate-800"
                                >
                                    <div className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 group-hover/item:bg-blue-100 group-hover/item:text-blue-600 transition-colors dark:bg-slate-800">
                                        <UserCircle2 className="h-5 w-5" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-slate-900 dark:text-white">{user.name}</p>
                                        <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wide">{user.role}</p>
                                    </div>
                                    <div className="ml-auto opacity-0 group-hover/item:opacity-100 transition-opacity">
                                        <ArrowUpRight className="h-4 w-4 text-blue-400" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Filtros de Región */}
                <div className="flex gap-2 overflow-x-auto pb-2 lg:pb-0 scrollbar-hide w-full lg:w-auto mask-linear-fade">
                    {regions.map(region => {
                        const isSelected = selectedRegion === region;
                        return (
                            <button
                                key={region}
                                onClick={() => setSelectedRegion(region)}
                                className={`relative px-6 h-12 rounded-full text-xs font-black uppercase tracking-wider transition-all duration-300 whitespace-nowrap ${isSelected
                                    ? "bg-slate-900 text-white shadow-lg shadow-slate-900/20 scale-105"
                                    : "bg-white text-slate-500 hover:bg-slate-50 border border-slate-200/50 hover:border-slate-300 dark:bg-slate-900/50 dark:border-slate-800 dark:text-slate-400"
                                    }`}
                            >
                                {region}
                                {isSelected && (
                                    <span className="absolute -top-1 -right-1 h-3 w-3 bg-blue-500 rounded-full animate-pulse" />
                                )}
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* Resultados */}
            <div className="space-y-4">
                <div className="flex items-center justify-between px-2">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
                        {filteredUsers.length} Contactos Encontrados
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {loading ? (
                        Array.from({ length: 6 }).map((_, i) => (
                            <div key={i} className="h-48 rounded-[2.5rem] bg-slate-100 dark:bg-slate-800 animate-pulse" />
                        ))
                    ) : filteredUsers.map(user => (
                        <Card
                            key={user.id}
                            className="group relative overflow-hidden rounded-[2.5rem] border-none bg-white shadow-xl shadow-slate-200/40 hover:shadow-2xl hover:shadow-blue-900/5 transition-all duration-500 hover:-translate-y-1 dark:bg-slate-900 dark:shadow-none"
                        >
                            <CardContent className="p-8">
                                <div className="flex items-start justify-between mb-6">
                                    <div className="flex items-center gap-4">
                                        <div className="h-16 w-16 rounded-[1.2rem] bg-slate-50 flex items-center justify-center text-slate-300 group-hover:scale-110 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all duration-500 dark:bg-slate-800">
                                            <UserCircle2 className="h-8 w-8" />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-black text-slate-900 dark:text-white leading-tight font-heading">
                                                {user.name}
                                            </h3>
                                            <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest mt-1">
                                                {user.role}
                                            </p>
                                        </div>
                                    </div>
                                    {user.isAdmin && (
                                        <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-600" title="Administrador">
                                            <ShieldCheck className="h-4 w-4" />
                                        </div>
                                    )}
                                </div>

                                <div className="space-y-3 mb-8">
                                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50/50 hover:bg-slate-50 transition-colors group/info dark:bg-slate-800/50">
                                        <MapPin className="h-4 w-4 text-slate-400 group-hover/info:text-blue-500 transition-colors" />
                                        <span className="text-xs font-bold text-slate-600 dark:text-slate-300">{user.region}</span>
                                    </div>
                                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50/50 hover:bg-slate-50 transition-colors group/info dark:bg-slate-800/50">
                                        <Mail className="h-4 w-4 text-slate-400 group-hover/info:text-blue-500 transition-colors" />
                                        <span className="text-xs font-medium text-slate-500 truncate dark:text-slate-400">{user.email}</span>
                                    </div>
                                </div>

                                <div className="flex gap-2">
                                    <Button
                                        className="flex-1 h-12 rounded-2xl bg-slate-900 hover:bg-black text-white font-bold text-[10px] uppercase tracking-widest shadow-lg shadow-slate-900/20"
                                        onClick={() => handleAction('whatsapp', user.whatsapp)}
                                    >
                                        <MessageSquare className="h-3.5 w-3.5 mr-2" />
                                        Chat
                                    </Button>
                                    <Button
                                        variant="outline"
                                        className="h-12 w-12 rounded-2xl border-slate-200 hover:border-blue-200 hover:bg-blue-50 hover:text-blue-600 transition-all dark:border-slate-800"
                                        onClick={() => handleAction('call', user.phone)}
                                    >
                                        <Phone className="h-4 w-4" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {filteredUsers.length === 0 && !loading && (
                    <div className="flex flex-col items-center justify-center py-20 opacity-50">
                        <Search className="h-16 w-16 text-slate-300 mb-4" />
                        <p className="text-sm font-black uppercase tracking-widest text-slate-400">No se encontraron contactos</p>
                    </div>
                )}
            </div>
        </div>
    );
}





